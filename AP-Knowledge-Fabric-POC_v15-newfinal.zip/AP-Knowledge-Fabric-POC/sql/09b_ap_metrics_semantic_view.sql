-- =====================================================================
-- 09b SEMANTIC VIEW over the AP reporting views (Cortex Analyst): AP METRICS
--   Lets the agent answer business metric questions with SQL on the governed reporting layer:
--   open / overdue amount, aging, item counts, weighted paid / offered terms, on-time payment,
--   USD at month-end and monthly-average rates. Runs with the caller's role, so masking still applies.
-- =====================================================================
USE WAREHOUSE {{WAREHOUSE}};

CREATE OR REPLACE SEMANTIC VIEW {{DATABASE}}.{{KF}}.{{METRICS_VIEW}}

TABLES (
  open_items AS {{DATABASE}}.{{REPORTING}}.VW_AP_OPEN_ITEMS
    WITH SYNONYMS ('open items', 'open invoices', 'AP aging', 'payables', 'open AP')
    COMMENT = 'Open (unpaid) vendor items with aging, one row per open vendor line item, as of the last datamart load.',
  payment_terms AS {{DATABASE}}.{{REPORTING}}.VW_AP_PAYMENT_TERMS
    WITH SYNONYMS ('payment terms', 'paid items', 'payments', 'all AP items')
    COMMENT = 'All vendor line items (open and paid) with payment terms metrics: days to pay, offered terms, weighted numerators and denominators, USD at month-end and monthly-average rates.',
  ap_details AS {{DATABASE}}.{{REPORTING}}.VW_FIN_AP_INV_DETAILS
    WITH SYNONYMS ('AP details', 'AP global details', 'DM_FIN_AP_GBL_DETAILS', 'invoice details', 'AP datamart')
    COMMENT = 'AP global details (datamart DM_FIN_AP_GBL_DETAILS via VW_FIN_AP_INV_DETAILS): one row per AP line with USD ME amounts, aging bands, days late, AWPT / AWPOT weights.',
  vendors AS {{DATABASE}}.{{REPORTING}}.VW_AP_VENDOR PRIMARY KEY (VENDOR_ID)
    WITH SYNONYMS ('vendors', 'suppliers')
    COMMENT = 'Vendor list (tax ID and bank account masked for business users).'
)

RELATIONSHIPS (
  open_items_to_vendors AS open_items (VENDOR_ID) REFERENCES vendors,
  payment_terms_to_vendors AS payment_terms (VENDOR_ID) REFERENCES vendors
)

FACTS (
  open_items.oi_open_amount_usd AS OPEN_AMOUNT_USD COMMENT = 'Open amount in USD of the item',
  open_items.oi_open_amount_local AS OPEN_AMOUNT_LOCAL COMMENT = 'Open amount in local currency of the item',
  open_items.oi_days_past_due AS DAYS_PAST_DUE COMMENT = 'Days past due of the item (as-of date - net due date)',
  payment_terms.pt_amount_usd_me AS AMOUNT_USD_ME COMMENT = 'Amount in USD at the month-end rate',
  payment_terms.pt_amount_usd_ma AS AMOUNT_USD_MA COMMENT = 'Amount in USD at the monthly-average rate',
  payment_terms.pt_days_to_pay AS DAYS_TO_PAY COMMENT = 'Days from baseline date to payment',
  payment_terms.pt_days_offered_terms AS DAYS_OFFERED_TERMS COMMENT = 'Payment term days agreed with the vendor',
  payment_terms.pt_paid_terms_numerator AS PAID_TERMS_NUMERATOR COMMENT = 'Weighted paid terms numerator',
  payment_terms.pt_paid_terms_denominator AS PAID_TERMS_DENOMINATOR COMMENT = 'Weighted paid terms denominator',
  payment_terms.pt_offered_terms_numerator AS OFFERED_TERMS_NUMERATOR COMMENT = 'Weighted offered terms numerator',
  payment_terms.pt_offered_terms_denominator AS OFFERED_TERMS_DENOMINATOR COMMENT = 'Weighted offered terms denominator',
  ap_details.d_amt_usd_me AS AMT_USD_ME COMMENT = 'Amount in USD at month-end rate (sign flipped for disbursements)',
  ap_details.d_amt_doc AS AMT_DOC COMMENT = 'Amount in document currency',
  ap_details.d_days_late AS DAYS_LATE COMMENT = 'Days an unpaid item is past its net due date',
  ap_details.d_weighted_act_payment AS WEIGHTED_ACT_PAYMENT COMMENT = 'AWPT numerator: days to pay x AMT_USD_ME',
  ap_details.d_awpt_denominator AS AWPT_DENOMINATOR COMMENT = 'AWPT denominator',
  ap_details.d_weighted_payment_terms AS WEIGHTED_PAYMENT_TERMS_USD_ME COMMENT = 'AWPOT numerator: days offered terms x AMT_USD_ME',
  ap_details.d_awpot_denominator AS AWPOT_DENOMINATOR COMMENT = 'AWPOT denominator'
)

DIMENSIONS (
  open_items.oi_as_of_date AS AS_OF_DATE COMMENT = 'Date the aging was calculated',
  open_items.oi_company_code AS COMPANY_CODE WITH SYNONYMS = ('entity', 'legal entity') COMMENT = 'Company code',
  open_items.oi_company_name AS COMPANY_NAME COMMENT = 'Company name',
  open_items.oi_vendor_id AS VENDOR_ID COMMENT = 'Vendor ID',
  open_items.oi_vendor_name AS VENDOR_NAME COMMENT = 'Vendor or one-time payee name (one-time payee names masked)',
  open_items.oi_is_one_time_vendor AS IS_ONE_TIME_VENDOR COMMENT = 'TRUE for one-time vendors',
  open_items.oi_vendor_country AS VENDOR_COUNTRY WITH SYNONYMS = ('country', 'supplier country') COMMENT = 'Vendor country',
  open_items.oi_document_number AS DOCUMENT_NUMBER COMMENT = 'Accounting document number',
  open_items.oi_document_type AS DOCUMENT_TYPE COMMENT = 'Vendor invoice or vendor credit memo'
    SAMPLE_VALUES ('Vendor invoice', 'Vendor credit memo'),
  open_items.oi_invoice_reference AS INVOICE_REFERENCE COMMENT = 'Vendor invoice number',
  open_items.oi_net_due_date AS NET_DUE_DATE COMMENT = 'Net due date',
  open_items.oi_aging_bucket AS AGING_BUCKET WITH SYNONYMS = ('bucket', 'aging band')
    COMMENT = 'Aging bucket; sort by oi_aging_bucket_order'
    SAMPLE_VALUES ('Not yet due', '1-30', '31-60', '61-90', '91-180', 'Over 180'),
  open_items.oi_aging_bucket_order AS AGING_BUCKET_ORDER COMMENT = 'Sort order of the aging bucket',
  open_items.oi_is_overdue AS IS_OVERDUE COMMENT = 'TRUE when days past due > 0',
  open_items.oi_payment_block AS PAYMENT_BLOCK COMMENT = 'Payment block; A = blocked for payment',
  open_items.oi_local_currency AS LOCAL_CURRENCY COMMENT = 'Local currency',

  payment_terms.pt_company_code AS COMPANY_CODE COMMENT = 'Company code',
  payment_terms.pt_company_name AS COMPANY_NAME COMMENT = 'Company name',
  payment_terms.pt_vendor_id AS VENDOR_ID COMMENT = 'Vendor ID',
  payment_terms.pt_is_one_time_vendor AS IS_ONE_TIME_VENDOR COMMENT = 'TRUE for one-time vendors',
  payment_terms.pt_vendor_country AS VENDOR_COUNTRY COMMENT = 'Vendor country',
  payment_terms.pt_document_number AS DOCUMENT_NUMBER COMMENT = 'Accounting document number',
  payment_terms.pt_document_type AS DOCUMENT_TYPE COMMENT = 'Vendor invoice or vendor credit memo',
  payment_terms.pt_posting_date AS POSTING_DATE COMMENT = 'Posting date',
  payment_terms.pt_posting_month AS POSTING_MONTH WITH SYNONYMS = ('month', 'period') COMMENT = 'Posting month (first day of the month)',
  payment_terms.pt_payment_terms AS PAYMENT_TERMS COMMENT = 'Payment terms key',
  payment_terms.pt_net_due_date AS NET_DUE_DATE COMMENT = 'Net due date',
  payment_terms.pt_clearing_date AS CLEARING_DATE WITH SYNONYMS = ('payment date') COMMENT = 'Date the item was paid',
  payment_terms.pt_is_paid AS IS_PAID COMMENT = 'TRUE when the item is paid',
  payment_terms.pt_is_paid_on_time AS IS_PAID_ON_TIME COMMENT = 'TRUE when paid on or before the net due date',
  payment_terms.pt_local_currency AS LOCAL_CURRENCY COMMENT = 'Local currency',

  ap_details.d_company_code AS COMPANY_CODE COMMENT = 'Company code',
  ap_details.d_source_system AS SOURCE_SYSTEM COMMENT = 'Source SAP system' SAMPLE_VALUES ('ARP900', 'AEP900'),
  ap_details.d_vendor_sk AS VENDOR_SK COMMENT = 'Vendor number',
  ap_details.d_vendor_name AS VENDOR_NAME COMMENT = 'Vendor name',
  ap_details.d_vendor_country_name AS VENDOR_COUNTRY_NAME COMMENT = 'Vendor country',
  ap_details.d_current_status AS CURRENT_STATUS COMMENT = 'Paid or Unpaid' SAMPLE_VALUES ('Paid', 'Unpaid'),
  ap_details.d_open_close_flag AS OPEN_CLOSE_FLAG COMMENT = 'OPEN or CLOSE' SAMPLE_VALUES ('OPEN', 'CLOSE'),
  ap_details.d_aging_flag AS AGING_FLAG COMMENT = 'Aging band by days late' SAMPLE_VALUES ('CURRENT', '1-30', '31-60', '60-90', '91-120', '121-150', '151-180', '181-360', '361+'),
  ap_details.d_metric_type AS METRIC_TYPE COMMENT = 'DISBURSEMENTS for paid items, otherwise the AP spend type',
  ap_details.d_fiscal_year AS FISCAL_YEAR COMMENT = 'Fiscal year',
  ap_details.d_posting_fiscal_period AS POSTING_FISCAL_PERIOD COMMENT = 'Posting fiscal period',
  ap_details.d_doc_type_description AS DOC_TYPE_DESCRIPTION COMMENT = 'Document type description',

  vendors.v_vendor_id AS VENDOR_ID COMMENT = 'Vendor ID',
  vendors.v_vendor_name AS VENDOR_NAME COMMENT = 'Vendor name',
  vendors.v_vendor_country AS VENDOR_COUNTRY COMMENT = 'Vendor master country',
  vendors.v_vendor_city AS VENDOR_CITY COMMENT = 'Vendor city',
  vendors.v_is_one_time_vendor AS IS_ONE_TIME_VENDOR COMMENT = 'TRUE for the one-time vendor account',
  vendors.v_is_deleted AS IS_DELETED COMMENT = 'TRUE when the vendor is marked for deletion'
)

METRICS (
  open_items.total_open_amount_usd AS SUM(OPEN_AMOUNT_USD)
    WITH SYNONYMS = ('open amount', 'AP balance', 'outstanding amount', 'total payables') COMMENT = 'Total open AP amount in USD',
  open_items.overdue_amount_usd AS SUM(IFF(IS_OVERDUE, OPEN_AMOUNT_USD, 0))
    WITH SYNONYMS = ('overdue amount', 'past due amount') COMMENT = 'Open amount in USD of items past their net due date',
  open_items.overdue_share AS DIV0(SUM(IFF(IS_OVERDUE, OPEN_AMOUNT_USD, 0)), SUM(OPEN_AMOUNT_USD))
    WITH SYNONYMS = ('overdue percentage', 'percent overdue') COMMENT = 'Share (0-1) of the open amount that is overdue',
  open_items.open_item_count AS COUNT(DOCUMENT_NUMBER) WITH SYNONYMS = ('number of open items', 'open invoice count') COMMENT = 'Number of open items',
  open_items.overdue_item_count AS COUNT_IF(IS_OVERDUE) COMMENT = 'Number of overdue items',
  open_items.blocked_amount_usd AS SUM(IFF(PAYMENT_BLOCK = 'A', OPEN_AMOUNT_USD, 0)) COMMENT = 'Open amount in USD blocked for payment',
  open_items.avg_days_past_due AS AVG(IFF(DAYS_PAST_DUE > 0, DAYS_PAST_DUE, NULL)) COMMENT = 'Average days past due of overdue items',
  open_items.weighted_avg_days_past_due AS DIV0(SUM(IFF(DAYS_PAST_DUE > 0, DAYS_PAST_DUE * OPEN_AMOUNT_USD, 0)), SUM(IFF(DAYS_PAST_DUE > 0, OPEN_AMOUNT_USD, 0)))
    COMMENT = 'Amount-weighted average days past due of overdue items',

  payment_terms.weighted_avg_paid_terms AS DIV0(SUM(PAID_TERMS_NUMERATOR), SUM(PAID_TERMS_DENOMINATOR))
    WITH SYNONYMS = ('WAPT', 'AWPT', 'average weighted paid terms', 'weighted paid terms', 'actual payment days')
    COMMENT = 'Weighted average paid terms in days = SUM(paid terms numerator) / SUM(paid terms denominator)',
  payment_terms.weighted_avg_offered_terms AS DIV0(SUM(OFFERED_TERMS_NUMERATOR), SUM(OFFERED_TERMS_DENOMINATOR))
    WITH SYNONYMS = ('average weighted offered terms', 'weighted payment terms', 'average weighted terms')
    COMMENT = 'Weighted average offered (agreed) terms in days = SUM(offered terms numerator) / SUM(offered terms denominator)',
  payment_terms.paid_terms_gap AS DIV0(SUM(PAID_TERMS_NUMERATOR), SUM(PAID_TERMS_DENOMINATOR)) - DIV0(SUM(OFFERED_TERMS_NUMERATOR), SUM(OFFERED_TERMS_DENOMINATOR))
    COMMENT = 'Weighted paid terms minus weighted offered terms in days (positive = paid later than agreed). Draft KPI.',
  payment_terms.on_time_payment_rate AS DIV0(COUNT_IF(IS_PAID_ON_TIME), COUNT_IF(IS_PAID))
    WITH SYNONYMS = ('on-time payment', 'OTP', 'payment compliance') COMMENT = 'Share (0-1) of paid items paid on or before the net due date',
  payment_terms.avg_days_to_pay AS AVG(DAYS_TO_PAY) COMMENT = 'Simple average days to pay of paid items',
  payment_terms.amount_usd_month_end AS SUM(AMOUNT_USD_ME) WITH SYNONYMS = ('USD ME', 'amount at month-end rate') COMMENT = 'Amount in USD at month-end rates',
  payment_terms.amount_usd_monthly_avg AS SUM(AMOUNT_USD_MA) WITH SYNONYMS = ('USD MA', 'amount at average rate') COMMENT = 'Amount in USD at monthly-average rates',
  payment_terms.paid_amount_usd AS SUM(IFF(IS_PAID, AMOUNT_USD_MA, 0)) WITH SYNONYMS = ('paid amount', 'payments made') COMMENT = 'Paid amount in USD (monthly-average rate)',
  payment_terms.item_count AS COUNT(DOCUMENT_NUMBER) COMMENT = 'Number of vendor line items (open and paid)',

  ap_details.total_amt_usd_me AS SUM(AMT_USD_ME) WITH SYNONYMS = ('AMT_USD_ME total', 'USD ME amount') COMMENT = 'Total AMT_USD_ME',
  ap_details.past_due_amt_usd_me AS SUM(PAST_DUE_AMT_USD_ME) WITH SYNONYMS = ('past due amount') COMMENT = 'Past due amount in USD (ME)',
  ap_details.current_amt_usd_me AS SUM(CURRENT_AMT_USD_ME) COMMENT = 'Current (not yet due) amount in USD (ME)',
  ap_details.aging_1_30_amt AS SUM(AGING_1_30_DAYS_AMT_USD_ME) COMMENT = 'Aging 1-30 days amount USD ME',
  ap_details.aging_31_60_amt AS SUM(AGING_31_60_DAYS_AMT_USD_ME) COMMENT = 'Aging 31-60 days amount USD ME',
  ap_details.aging_61_90_amt AS SUM(AGING_61_90_DAYS_AMT_USD_ME) COMMENT = 'Aging 61-90 days amount USD ME',
  ap_details.over_180_amt AS SUM(OVER_180_DAYS_AMT_USD_ME) COMMENT = 'Over 180 days amount USD ME',
  ap_details.awpt AS DIV0(SUM(WEIGHTED_ACT_PAYMENT), SUM(AWPT_DENOMINATOR))
    WITH SYNONYMS = ('AWPT', 'average weighted paid terms') COMMENT = 'Average weighted paid terms = SUM(WEIGHTED_ACT_PAYMENT) / SUM(AWPT_DENOMINATOR)',
  ap_details.awpot AS DIV0(SUM(WEIGHTED_PAYMENT_TERMS_USD_ME), SUM(AWPOT_DENOMINATOR))
    WITH SYNONYMS = ('AWPOT', 'average weighted PO terms') COMMENT = 'Average weighted PO terms = SUM(WEIGHTED_PAYMENT_TERMS_USD_ME) / SUM(AWPOT_DENOMINATOR)',
  ap_details.ap_line_count AS COUNT(ACCOUNTING_DOC) COMMENT = 'Number of AP lines',

  vendors.vendor_count AS COUNT(VENDOR_ID) WITH SYNONYMS = ('number of vendors') COMMENT = 'Number of vendors'
)

COMMENT = 'AP business metrics on the governed reporting views: open and overdue amounts, aging, payment terms (weighted paid / offered terms, on-time payment), USD at month-end and monthly-average rates. Synthetic POC data.'

AI_SQL_GENERATION 'Use open_items for open / overdue amounts and aging (one as-of date: the last datamart load); use payment_terms for payment behaviour, paid items, payment terms and USD at month-end (ME) or monthly-average (MA) rates. Order aging buckets by oi_aging_bucket_order. Show amounts rounded to 2 decimals and shares as percentages with 1 decimal. Never try to unmask or guess masked values.'

AI_VERIFIED_QUERIES (
  vq_aging_by_bucket AS (
    QUESTION 'What is the open AP amount by aging bucket?'
    VERIFIED_AT 1794614400
    ONBOARDING_QUESTION TRUE
    SQL 'SELECT oi_aging_bucket, oi_aging_bucket_order, COUNT(oi_document_number) AS open_items, ROUND(SUM(oi_open_amount_usd), 2) AS open_amount_usd FROM open_items GROUP BY oi_aging_bucket, oi_aging_bucket_order ORDER BY oi_aging_bucket_order'
  ),
  vq_overdue_by_country AS (
    QUESTION 'What is the overdue amount by vendor country?'
    VERIFIED_AT 1794614400
    ONBOARDING_QUESTION TRUE
    SQL 'SELECT oi_vendor_country, ROUND(SUM(oi_open_amount_usd), 2) AS overdue_amount_usd, COUNT(oi_document_number) AS overdue_items FROM open_items WHERE oi_is_overdue GROUP BY oi_vendor_country ORDER BY overdue_amount_usd DESC'
  ),
  vq_weighted_terms_by_company AS (
    QUESTION 'What are the weighted average paid terms and offered terms by company code?'
    VERIFIED_AT 1794614400
    ONBOARDING_QUESTION TRUE
    SQL 'SELECT pt_company_code, pt_company_name, ROUND(DIV0(SUM(pt_paid_terms_numerator), SUM(pt_paid_terms_denominator)), 1) AS weighted_avg_paid_terms_days, ROUND(DIV0(SUM(pt_offered_terms_numerator), SUM(pt_offered_terms_denominator)), 1) AS weighted_avg_offered_terms_days FROM payment_terms GROUP BY pt_company_code, pt_company_name ORDER BY pt_company_code'
  ),
  vq_top_vendors_open AS (
    QUESTION 'Which 10 vendors have the highest open AP amount?'
    VERIFIED_AT 1794614400
    SQL 'SELECT oi_vendor_id, oi_vendor_name, oi_vendor_country, ROUND(SUM(oi_open_amount_usd), 2) AS open_amount_usd FROM open_items GROUP BY oi_vendor_id, oi_vendor_name, oi_vendor_country ORDER BY open_amount_usd DESC LIMIT 10'
  ),
  vq_awpt_by_company AS (
    QUESTION 'What are AWPT and AWPOT by company code?'
    VERIFIED_AT 1794614400
    ONBOARDING_QUESTION TRUE
    SQL 'SELECT d_company_code, ROUND(DIV0(SUM(d_weighted_act_payment), SUM(d_awpt_denominator)), 1) AS awpt_days, ROUND(DIV0(SUM(d_weighted_payment_terms), SUM(d_awpot_denominator)), 1) AS awpot_days FROM ap_details GROUP BY d_company_code ORDER BY d_company_code'
  ),
  vq_usd_me_ma_by_month AS (
    QUESTION 'Show the AP amount in USD at month-end and monthly-average rates by posting month'
    VERIFIED_AT 1794614400
    SQL 'SELECT pt_posting_month, ROUND(SUM(pt_amount_usd_me), 2) AS amount_usd_me, ROUND(SUM(pt_amount_usd_ma), 2) AS amount_usd_ma FROM payment_terms GROUP BY pt_posting_month ORDER BY pt_posting_month'
  )
);

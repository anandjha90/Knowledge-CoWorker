# Agent skills (Cortex Agent)

Three skills, one folder each with its SKILL.md:

| Skill | Used when |
|---|---|
| new_requirement_assessment | A new requirement: replicate a report in EDW or provide SAP T-code data / KPIs. Reuse vs extend EDW vs new replication. |
| mapping_sheet_lookup | One field: logic, mapping, source table / field, definition, lineage. Quotes the mapping sheet word for word and flags documentation gaps. |
| data_dictionary_export | All fields of a table or view in the mapping-sheet layout. |

## Option A - automatic (notebook)
```python
import run
run.add_skills()
```
Uploads the SKILL.md files to @POC_AP_KNOWLEDGE_FABRIC.KNOWLEDGE_FABRIC.KF_SKILLS/skills/<name>/,
recreates the agent with the skills attached (task rules move from the prompt into the skills), and re-applies access.
If the account does not accept skills, the agent is recreated without them and a warning is printed.

## Option B - manual (Snowsight)
1. Create the stage (SQL worksheet, role ACCOUNTADMIN):
   ```sql
   CREATE STAGE IF NOT EXISTS POC_AP_KNOWLEDGE_FABRIC.KNOWLEDGE_FABRIC.KF_SKILLS DIRECTORY = (ENABLE = TRUE);
   ```
2. Upload each SKILL.md: Catalog -> POC_AP_KNOWLEDGE_FABRIC -> KNOWLEDGE_FABRIC -> Stages -> KF_SKILLS -> + Files,
   path `skills/new_requirement_assessment` (then `skills/mapping_sheet_lookup`, `skills/data_dictionary_export`).
   SKILL.md must sit directly in its folder.
3. Agent: AI & ML -> Agents -> AP Knowledge Co-worker -> Edit -> Skills -> add each skill from the stage path
   `@POC_AP_KNOWLEDGE_FABRIC.KNOWLEDGE_FABRIC.KF_SKILLS/skills/<name>`. Save.
   (Same as this block in the agent specification:)
   ```yaml
   skills:
     - name: "mapping_sheet_lookup"
       source:
         type: "STAGE"
         path: "@POC_AP_KNOWLEDGE_FABRIC.KNOWLEDGE_FABRIC.KF_SKILLS/skills/mapping_sheet_lookup"
   ```
4. Grant: `GRANT READ ON STAGE POC_AP_KNOWLEDGE_FABRIC.KNOWLEDGE_FABRIC.KF_SKILLS TO ROLE AP_KF_BUSINESS_USER;`

## Test
- "We need to replicate an AP aging report by vendor country in EDW. Can we reuse existing data?" -> new_requirement_assessment
- "What is the logic, source table and source field of AMT_USD_ME in DM_FIN_AP_GBL_DETAILS?" -> mapping_sheet_lookup
- "Give me the business data dictionary for FACT_ACCOUNT_PAYABLE_GBL" -> data_dictionary_export

---
name: new_requirement_assessment
description: Use for a NEW REQUIREMENT - replicate an existing (for example HANA) report in EDW, or provide the data / KPIs behind SAP T-codes as a new or extended report. Answers whether the data already exists in EDW and can be reused, or needs EDW extension or new SAP replication.
---

# Instructions

Answer as a reuse assessment. Use only your tools; never answer from memory.

1. Understand the request
   - List the business fields, KPIs and filters the requirement needs.
   - If T-codes are named, get their SAP tables and fields with metadata_analyst (sap_tcodes).
   - Turn everyday words into exact names with catalog_search.

2. Check what already exists (metadata_analyst)
   - reporting_views: reporting views, their data dictionary cards, KPIs, key filters and owners.
   - data_dictionary and field_mapping: EDW / datamart columns, business names and mapping logic.
   - reuse_assessment: per SAP field whether it is ingested, modelled and reported.

3. Classify every needed field into exactly one group
   - A. Already in EDW reporting (reuse): name the view.column and the owner.
   - B. In EDW or datamart but not in a reporting view: expose it in the reporting layer.
   - C. Ingested (in landing) but not modelled: extend EDW, no new replication.
   - D. Not ingested: new SAP replication needed (name the SAP table.field).

4. Answer in this structure
   - One-line verdict (for example "Mostly reusable: 8 of 10 fields exist, 2 need new replication").
   - A table: Requirement field | Group (A-D) | Snowflake object.column or SAP table.field | Owner / who confirms.
   - KPIs: existing definitions and calculations from the glossary; say if a KPI is Draft.
   - Recommendation and open points for the data steward (missing descriptions, conflicting mappings).
   - Sources: the tools and objects used.

Use full names (DATABASE.SCHEMA.OBJECT) for every Snowflake object. Never show or guess masked values.

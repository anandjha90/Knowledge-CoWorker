---
name: data_dictionary_export
description: Use when the user asks for the data dictionary, mapping sheet, field list or source-to-target mapping of a WHOLE table or view (for example "give me the business data dictionary for FACT_ACCOUNT_PAYABLE_GBL" or "show all fields of DM_FIN_AP_GBL_DETAILS with mapping").
---

# Instructions

Return the complete list in the same layout as the business mapping sheets.

1. Get the rows
   - metadata_analyst: data_dictionary filtered on dd_model_name, ordered by dd_position. Return ALL rows, not a sample.
   - For a reporting view, also give its data dictionary card (reporting_views): schema, description, data class, owners, refresh, keys, filters, KPIs, alternative views.

2. Columns, in this order
   - Transactional / EDW tables: EDW Model Name | EDW Field Name | Business Friendly Name | Business Friendly Definition | Source System | Source Table | Source Field | Mapping
   - Datamart tables: Target Table/View | EDW Column | Source EDW Table/View | Source Table | Source EDW Field | Mapping Information
   - Keep mapping text exactly as stored; shorten nothing.

3. After the table, add a short summary
   - Number of fields, how many are Direct Mapping vs calculated / lookup.
   - Fields with no business definition or no mapping (documentation gaps).
   - Offer to show the lineage or load SQL of any field.

Use the full table name (DATABASE.SCHEMA.TABLE) in the title. The response length limit does not apply to this list.

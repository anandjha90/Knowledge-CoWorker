-- =====================================================================
-- 07b AP METRICS + EXCEL-STYLE VIEWS
--   {{EDW}}.DIM_CURRENCY_RATE_MONTHLY     synthetic month-end (ME) and monthly-average (MA) USD rates
--   {{DATAMART}}.DM_AP_PAYMENT_TERMS   one row per vendor line item (open and paid) with calculated metrics:
--                                     USD at ME / MA rate, days to pay, weighted paid / offered terms
--                                     numerators and denominators (conditional CASE logic, like a mapping sheet)
--   {{REPORTING}}.VW_AP_PAYMENT_TERMS  reporting view for BI and the metrics semantic view
--   KF_FIELD_MAPPING / KF_GLOSSARY    new mapping rows (lineage) and KPI definitions
--   KF_S2T_MAPPING_SHEET              the mapping sheet in the usual Excel layout (source-to-target)
--   KF_BUSINESS_DATA_DICTIONARY       the business data dictionary in the usual Excel layout
-- Synthetic data and generic names only.
-- =====================================================================
USE WAREHOUSE {{WAREHOUSE}};
USE SCHEMA {{DATABASE}}.{{DATAMART}};

-- ---------------------------------------------------------------------
-- 1. Monthly USD rates (synthetic): month-end rate and monthly-average rate per currency
-- ---------------------------------------------------------------------
CREATE OR REPLACE TABLE {{DATABASE}}.{{EDW}}.DIM_CURRENCY_RATE_MONTHLY (
  CURRENCY          VARCHAR(5)   COMMENT 'Currency: local currency of a company code.',
  RATE_MONTH        DATE         COMMENT 'Rate month: first day of the month the rates apply to.',
  USD_RATE_ME       NUMBER(12,6) COMMENT 'USD rate month-end: synthetic month-end rate (1 local unit = rate USD).',
  USD_RATE_MA       NUMBER(12,6) COMMENT 'USD rate monthly average: synthetic average rate of the month (1 local unit = rate USD).',
  EDW_LOAD_TS       TIMESTAMP_NTZ COMMENT 'EDW load time: when the row was written.',
  PRIMARY KEY (CURRENCY, RATE_MONTH)
) COMMENT = 'Monthly USD exchange rates (synthetic). Source: DIM_COMPANY_CODE base rate with a small monthly variation. Grain: one row per currency and month.';

INSERT INTO {{DATABASE}}.{{EDW}}.DIM_CURRENCY_RATE_MONTHLY
WITH months AS (
  SELECT DISTINCT DATE_TRUNC('month', POSTING_DATE) AS RATE_MONTH
  FROM {{DATABASE}}.{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL
  UNION
  SELECT DISTINCT DATE_TRUNC('month', CLEARING_DATE)
  FROM {{DATABASE}}.{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL WHERE CLEARING_DATE IS NOT NULL
),
currencies AS (
  SELECT LOCAL_CURRENCY AS CURRENCY, MAX(USD_EXCHANGE_RATE) AS BASE_RATE
  FROM {{DATABASE}}.{{EDW}}.DIM_COMPANY_CODE GROUP BY LOCAL_CURRENCY
)
SELECT c.CURRENCY, m.RATE_MONTH,
       ROUND(c.BASE_RATE * IFF(c.CURRENCY = 'USD', 1, 1 + 0.03 * SIN(MONTH(m.RATE_MONTH) + YEAR(m.RATE_MONTH))), 6),
       ROUND(c.BASE_RATE * IFF(c.CURRENCY = 'USD', 1, 1 + 0.02 * SIN(MONTH(m.RATE_MONTH) + YEAR(m.RATE_MONTH) - 0.5)), 6),
       CURRENT_TIMESTAMP()
FROM currencies c CROSS JOIN months m
WHERE m.RATE_MONTH IS NOT NULL;

-- ---------------------------------------------------------------------
-- 2. Payment terms metrics (datamart)
-- ---------------------------------------------------------------------
CREATE OR REPLACE TABLE {{DATABASE}}.{{DATAMART}}.DM_AP_PAYMENT_TERMS (
  AP_LINE_ID                VARCHAR(30)  COMMENT 'AP line ID: company code-document number-fiscal year-line item.',
  COMPANY_CODE              VARCHAR(4)   COMMENT 'Company code: legal entity of the invoice.',
  COMPANY_NAME              VARCHAR(50)  COMMENT 'Company name: name of the company code.',
  VENDOR_ID                 VARCHAR(10)  COMMENT 'Vendor ID: vendor account of the invoice.',
  IS_ONE_TIME_VENDOR        BOOLEAN      COMMENT 'One-time vendor flag: TRUE for invoices posted to the one-time vendor account.',
  VENDOR_COUNTRY_NAME       VARCHAR(50)  COMMENT 'Vendor country: payee country for one-time vendors, otherwise the vendor master country.',
  DOCUMENT_NUMBER           VARCHAR(10)  COMMENT 'Document number: accounting document number.',
  DOCUMENT_TYPE_DESC        VARCHAR(30)  COMMENT 'Document type: vendor invoice or vendor credit memo.',
  POSTING_DATE              DATE         COMMENT 'Posting date: date posted in the ledger.',
  POSTING_MONTH             DATE         COMMENT 'Posting month: first day of the posting month.',
  BASELINE_DATE             DATE         COMMENT 'Baseline date: start date for the payment terms.',
  PAYMENT_TERMS             VARCHAR(4)   COMMENT 'Payment terms: payment terms key.',
  DAYS_OFFERED_TERMS        NUMBER(3)    COMMENT 'Days offered terms: payment term days agreed with the vendor.',
  NET_DUE_DATE              DATE         COMMENT 'Net due date: baseline date + payment term days.',
  CLEARING_DATE             DATE         COMMENT 'Clearing date: date the item was paid. Empty = not paid yet.',
  IS_PAID                   BOOLEAN      COMMENT 'Paid flag: TRUE when the item is cleared.',
  DAYS_TO_PAY               NUMBER(6)    COMMENT 'Days to pay: clearing date - document date (from the EDW fact). Empty when not paid.',
  IS_PAID_ON_TIME           BOOLEAN      COMMENT 'Paid on time flag: TRUE when paid on or before the net due date. Empty when not paid.',
  DEBIT_CREDIT_INDICATOR    VARCHAR(1)   COMMENT 'Debit/credit indicator: H = credit (invoice), S = debit (credit memo).',
  AMOUNT_LOCAL              NUMBER(15,2) COMMENT 'Amount (local currency): signed amount; invoices positive, credit memos negative.',
  LOCAL_CURRENCY            VARCHAR(5)   COMMENT 'Local currency: company code currency.',
  AMOUNT_USD_ME             NUMBER(15,2) COMMENT 'Amount USD (month-end rate): local amount x month-end USD rate of the posting month.',
  AMOUNT_USD_MA             NUMBER(15,2) COMMENT 'Amount USD (monthly average rate): local amount x monthly-average USD rate of the posting month.',
  PAID_TERMS_NUMERATOR      NUMBER(18,2) COMMENT 'Weighted paid terms numerator: paid terms denominator x days to pay.',
  PAID_TERMS_DENOMINATOR    NUMBER(18,2) COMMENT 'Weighted paid terms denominator: USD amount (monthly-average rate) of paid items, sign by debit/credit; 0 when not paid.',
  OFFERED_TERMS_NUMERATOR   NUMBER(18,2) COMMENT 'Weighted offered terms numerator: offered terms denominator x days offered terms.',
  OFFERED_TERMS_DENOMINATOR NUMBER(18,2) COMMENT 'Weighted offered terms denominator: USD amount (monthly-average rate), sign by debit/credit; 0 when no payment terms.',
  DM_LOAD_TS                TIMESTAMP_NTZ COMMENT 'Datamart load time: when the row was written.',
  PRIMARY KEY (AP_LINE_ID)
) COMMENT = 'AP payment terms metrics. Source: {{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL (open and paid items) + DIM_VENDOR + DIM_COMPANY_CODE + DIM_CURRENCY_RATE_MONTHLY. Grain: one row per vendor line item.';

CREATE OR REPLACE PROCEDURE {{DATABASE}}.{{DATAMART}}.LOAD_AP_PAYMENT_TERMS()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Loads the AP payment terms metrics (weighted paid / offered terms, USD at month-end and monthly-average rates) from the EDW.'
EXECUTE AS OWNER
AS
$$
BEGIN
  INSERT OVERWRITE INTO {{DATABASE}}.{{DATAMART}}.DM_AP_PAYMENT_TERMS
  WITH base AS (
    SELECT f.AP_LINE_ID, f.COMPANY_CODE, c.COMPANY_NAME, f.VENDOR_ID, v.IS_ONE_TIME_VENDOR,
           IFF(v.IS_ONE_TIME_VENDOR, f.ONE_TIME_VENDOR_COUNTRY_NAME, v.VENDOR_COUNTRY_NAME) AS VENDOR_COUNTRY_NAME,
           f.DOCUMENT_NUMBER, f.DOCUMENT_TYPE_DESC, f.POSTING_DATE, DATE_TRUNC('month', f.POSTING_DATE) AS POSTING_MONTH,
           f.BASELINE_DATE, f.PAYMENT_TERMS, f.PAYMENT_TERMS_DAYS AS DAYS_OFFERED_TERMS, f.NET_DUE_DATE, f.CLEARING_DATE,
           f.CLEARING_DATE IS NOT NULL AS IS_PAID,
           IFF(f.CLEARING_DATE IS NULL, NULL, f.DAYS_TO_PAY) AS DAYS_TO_PAY,
           IFF(f.CLEARING_DATE IS NULL, NULL, f.CLEARING_DATE <= f.NET_DUE_DATE) AS IS_PAID_ON_TIME,
           f.DEBIT_CREDIT_INDICATOR, f.AMOUNT_LOCAL, f.LOCAL_CURRENCY,
           ROUND(f.AMOUNT_LOCAL * COALESCE(r.USD_RATE_ME, c.USD_EXCHANGE_RATE), 2) AS AMOUNT_USD_ME,
           ROUND(f.AMOUNT_LOCAL * COALESCE(r.USD_RATE_MA, c.USD_EXCHANGE_RATE), 2) AS AMOUNT_USD_MA
    FROM {{DATABASE}}.{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL f
    JOIN {{DATABASE}}.{{EDW}}.DIM_COMPANY_CODE c ON c.COMPANY_CODE = f.COMPANY_CODE
    JOIN {{DATABASE}}.{{EDW}}.DIM_VENDOR v ON v.VENDOR_ID = f.VENDOR_ID
    LEFT JOIN {{DATABASE}}.{{EDW}}.DIM_CURRENCY_RATE_MONTHLY r
      ON r.CURRENCY = f.LOCAL_CURRENCY AND r.RATE_MONTH = DATE_TRUNC('month', f.POSTING_DATE)
  ),
  weights AS (
    SELECT b.*,
           CASE WHEN b.DAYS_TO_PAY IS NULL THEN 0
                WHEN b.DEBIT_CREDIT_INDICATOR = 'S' THEN -1 * ABS(b.AMOUNT_USD_MA)
                ELSE ABS(b.AMOUNT_USD_MA) END AS PAID_DENOMINATOR,
           CASE WHEN b.DAYS_OFFERED_TERMS IS NULL THEN 0
                WHEN b.DEBIT_CREDIT_INDICATOR = 'S' THEN -1 * ABS(b.AMOUNT_USD_MA)
                ELSE ABS(b.AMOUNT_USD_MA) END AS OFFERED_DENOMINATOR
    FROM base b
  )
  SELECT AP_LINE_ID, COMPANY_CODE, COMPANY_NAME, VENDOR_ID, IS_ONE_TIME_VENDOR, VENDOR_COUNTRY_NAME,
         DOCUMENT_NUMBER, DOCUMENT_TYPE_DESC, POSTING_DATE, POSTING_MONTH, BASELINE_DATE, PAYMENT_TERMS,
         DAYS_OFFERED_TERMS, NET_DUE_DATE, CLEARING_DATE, IS_PAID, DAYS_TO_PAY, IS_PAID_ON_TIME,
         DEBIT_CREDIT_INDICATOR, AMOUNT_LOCAL, LOCAL_CURRENCY, AMOUNT_USD_ME, AMOUNT_USD_MA,
         ROUND(PAID_DENOMINATOR * COALESCE(DAYS_TO_PAY, 0), 2),
         PAID_DENOMINATOR,
         ROUND(OFFERED_DENOMINATOR * COALESCE(DAYS_OFFERED_TERMS, 0), 2),
         OFFERED_DENOMINATOR,
         CURRENT_TIMESTAMP()
  FROM weights;

  RETURN 'AP payment terms metrics loaded';
END;
$$;

CALL {{DATABASE}}.{{DATAMART}}.LOAD_AP_PAYMENT_TERMS();

-- Reporting view (rename only, no logic)
CREATE OR REPLACE VIEW {{DATABASE}}.{{REPORTING}}.VW_AP_PAYMENT_TERMS (
  COMPANY_CODE              COMMENT 'Company code: legal entity of the invoice.',
  COMPANY_NAME              COMMENT 'Company name: name of the company code.',
  VENDOR_ID                 COMMENT 'Vendor ID: vendor account of the invoice.',
  IS_ONE_TIME_VENDOR        COMMENT 'One-time vendor flag: TRUE for invoices posted to the one-time vendor account.',
  VENDOR_COUNTRY            COMMENT 'Vendor country: payee country for one-time vendors, otherwise the vendor master country.',
  DOCUMENT_NUMBER           COMMENT 'Document number: accounting document number.',
  DOCUMENT_TYPE             COMMENT 'Document type: vendor invoice or vendor credit memo.',
  POSTING_DATE              COMMENT 'Posting date: date posted in the ledger.',
  POSTING_MONTH             COMMENT 'Posting month: first day of the posting month.',
  PAYMENT_TERMS             COMMENT 'Payment terms: payment terms key.',
  DAYS_OFFERED_TERMS        COMMENT 'Days offered terms: payment term days agreed with the vendor.',
  NET_DUE_DATE              COMMENT 'Net due date: baseline date + payment term days.',
  CLEARING_DATE             COMMENT 'Clearing date: date the item was paid. Empty = not paid yet.',
  IS_PAID                   COMMENT 'Paid flag: TRUE when the item is cleared.',
  DAYS_TO_PAY               COMMENT 'Days to pay: clearing date - document date (paid items).',
  IS_PAID_ON_TIME           COMMENT 'Paid on time flag: TRUE when paid on or before the net due date.',
  AMOUNT_LOCAL              COMMENT 'Amount (local currency): signed amount in company code currency.',
  LOCAL_CURRENCY            COMMENT 'Local currency: company code currency.',
  AMOUNT_USD_ME             COMMENT 'Amount USD (month-end rate): amount converted at the month-end rate.',
  AMOUNT_USD_MA             COMMENT 'Amount USD (monthly average rate): amount converted at the monthly-average rate.',
  PAID_TERMS_NUMERATOR      COMMENT 'Weighted paid terms numerator: USD amount x days to pay (paid items).',
  PAID_TERMS_DENOMINATOR    COMMENT 'Weighted paid terms denominator: USD amount of paid items.',
  OFFERED_TERMS_NUMERATOR   COMMENT 'Weighted offered terms numerator: USD amount x days offered terms.',
  OFFERED_TERMS_DENOMINATOR COMMENT 'Weighted offered terms denominator: USD amount of items with payment terms.'
)
COMMENT = 'AP payment terms metrics for BI: weighted paid / offered terms, on-time payment, USD at month-end and monthly-average rates. Reads {{DATAMART}}.DM_AP_PAYMENT_TERMS only (rename, no logic).'
AS
SELECT COMPANY_CODE, COMPANY_NAME, VENDOR_ID, IS_ONE_TIME_VENDOR, VENDOR_COUNTRY_NAME, DOCUMENT_NUMBER,
       DOCUMENT_TYPE_DESC, POSTING_DATE, POSTING_MONTH, PAYMENT_TERMS, DAYS_OFFERED_TERMS, NET_DUE_DATE,
       CLEARING_DATE, IS_PAID, DAYS_TO_PAY, IS_PAID_ON_TIME, AMOUNT_LOCAL, LOCAL_CURRENCY, AMOUNT_USD_ME,
       AMOUNT_USD_MA, PAID_TERMS_NUMERATOR, PAID_TERMS_DENOMINATOR, OFFERED_TERMS_NUMERATOR, OFFERED_TERMS_DENOMINATOR
FROM {{DATABASE}}.{{DATAMART}}.DM_AP_PAYMENT_TERMS;

-- Governance tags (owner, domain etc. are inherited from the schema)
ALTER TABLE {{DATABASE}}.{{EDW}}.DIM_CURRENCY_RATE_MONTHLY SET TAG {{DATABASE}}.{{GOVERNANCE}}.DATA_CLASS = 'Reference data';
ALTER TABLE {{DATABASE}}.{{DATAMART}}.DM_AP_PAYMENT_TERMS SET TAG {{DATABASE}}.{{GOVERNANCE}}.DATA_CLASS = 'Transaction data';
ALTER VIEW {{DATABASE}}.{{REPORTING}}.VW_AP_PAYMENT_TERMS SET TAG {{DATABASE}}.{{GOVERNANCE}}.DATA_CLASS = 'Transaction data';
ALTER VIEW {{DATABASE}}.{{REPORTING}}.VW_AP_PAYMENT_TERMS MODIFY COLUMN COMPANY_CODE SET TAG {{DATABASE}}.{{GOVERNANCE}}.KEY_ROLE = 'Business key';
ALTER VIEW {{DATABASE}}.{{REPORTING}}.VW_AP_PAYMENT_TERMS MODIFY COLUMN DOCUMENT_NUMBER SET TAG {{DATABASE}}.{{GOVERNANCE}}.KEY_ROLE = 'Business key';

-- Refresh: runs right after the EDW load (all tasks of one graph live in the EDW schema)
ALTER TASK {{DATABASE}}.{{EDW}}.TASK_LOAD_EDW SUSPEND;
CREATE OR REPLACE TASK {{DATABASE}}.{{EDW}}.TASK_LOAD_AP_PAYMENT_TERMS
  WAREHOUSE = {{WAREHOUSE}}
  COMMENT = 'Runs right after TASK_LOAD_EDW (daily, about 02:15 UTC). Refreshes: DIM_CURRENCY_RATE_MONTHLY,DM_AP_PAYMENT_TERMS'
  AFTER {{DATABASE}}.{{EDW}}.TASK_LOAD_EDW
AS
  CALL {{DATABASE}}.{{DATAMART}}.LOAD_AP_PAYMENT_TERMS();

-- ---------------------------------------------------------------------
-- 3. Mapping sheet rows (feed the lineage) and KPI definitions
-- ---------------------------------------------------------------------
DELETE FROM {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING
WHERE TARGET_OBJECT IN ('{{REPORTING}}.VW_AP_PAYMENT_TERMS', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', '{{EDW}}.DIM_CURRENCY_RATE_MONTHLY');

INSERT INTO {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING (TARGET_LAYER, TARGET_OBJECT, TARGET_COLUMN, SOURCE_OBJECT, SOURCE_COLUMN, MAPPING_TYPE, TRANSFORMATION_RULE, MAPPING_SOURCE)
SELECT column1, column2, column3, column4, column5, column6, column7, 'Mapping sheet v1.1, payment terms metrics' FROM VALUES
-- Reporting <- Datamart
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'COMPANY_CODE', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'COMPANY_CODE', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'COMPANY_NAME', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'COMPANY_NAME', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'VENDOR_ID', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'VENDOR_ID', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'IS_ONE_TIME_VENDOR', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'IS_ONE_TIME_VENDOR', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'VENDOR_COUNTRY', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'VENDOR_COUNTRY_NAME', 'Renamed', 'Renamed only: VENDOR_COUNTRY_NAME is exposed as VENDOR_COUNTRY.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'DOCUMENT_NUMBER', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DOCUMENT_NUMBER', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'DOCUMENT_TYPE', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DOCUMENT_TYPE_DESC', 'Renamed', 'Renamed only: DOCUMENT_TYPE_DESC is exposed as DOCUMENT_TYPE.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'POSTING_DATE', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'POSTING_DATE', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'POSTING_MONTH', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'POSTING_MONTH', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'PAYMENT_TERMS', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAYMENT_TERMS', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'DAYS_OFFERED_TERMS', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DAYS_OFFERED_TERMS', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'NET_DUE_DATE', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'NET_DUE_DATE', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'CLEARING_DATE', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'CLEARING_DATE', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'IS_PAID', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'IS_PAID', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'DAYS_TO_PAY', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DAYS_TO_PAY', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'IS_PAID_ON_TIME', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'IS_PAID_ON_TIME', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'AMOUNT_LOCAL', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_LOCAL', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'LOCAL_CURRENCY', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'LOCAL_CURRENCY', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'AMOUNT_USD_ME', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_USD_ME', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'AMOUNT_USD_MA', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_USD_MA', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'PAID_TERMS_NUMERATOR', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAID_TERMS_NUMERATOR', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'PAID_TERMS_DENOMINATOR', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAID_TERMS_DENOMINATOR', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'OFFERED_TERMS_NUMERATOR', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'OFFERED_TERMS_NUMERATOR', 'Direct', 'Passed through.'),
('Reporting', '{{REPORTING}}.VW_AP_PAYMENT_TERMS', 'OFFERED_TERMS_DENOMINATOR', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'OFFERED_TERMS_DENOMINATOR', 'Direct', 'Passed through.'),
-- Datamart <- EDW
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'COMPANY_CODE', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'COMPANY_CODE', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'COMPANY_NAME', '{{EDW}}.DIM_COMPANY_CODE', 'COMPANY_NAME', 'Lookup', 'Join with DIM_COMPANY_CODE on COMPANY_CODE.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'VENDOR_ID', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'VENDOR_ID', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'IS_ONE_TIME_VENDOR', '{{EDW}}.DIM_VENDOR', 'IS_ONE_TIME_VENDOR', 'Lookup', 'Join with DIM_VENDOR on VENDOR_ID.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'VENDOR_COUNTRY_NAME', '{{EDW}}.DIM_VENDOR', 'VENDOR_COUNTRY_NAME', 'Conditional', 'IFF(IS_ONE_TIME_VENDOR, FACT.ONE_TIME_VENDOR_COUNTRY_NAME, DIM_VENDOR.VENDOR_COUNTRY_NAME): regular vendors take the vendor master country.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'VENDOR_COUNTRY_NAME', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'ONE_TIME_VENDOR_COUNTRY_NAME', 'Conditional', 'One-time vendors take the payee country of the invoice (from SAP_BSEC).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DOCUMENT_NUMBER', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'DOCUMENT_NUMBER', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DOCUMENT_TYPE_DESC', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'DOCUMENT_TYPE_DESC', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'POSTING_DATE', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'POSTING_DATE', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'POSTING_MONTH', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'POSTING_DATE', 'Derived', 'DATE_TRUNC(month, POSTING_DATE).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAYMENT_TERMS', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'PAYMENT_TERMS', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DAYS_OFFERED_TERMS', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'PAYMENT_TERMS_DAYS', 'Renamed', 'Renamed: PAYMENT_TERMS_DAYS is exposed as DAYS_OFFERED_TERMS.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'NET_DUE_DATE', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'NET_DUE_DATE', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'CLEARING_DATE', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'CLEARING_DATE', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'IS_PAID', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'CLEARING_DATE', 'Derived', 'CLEARING_DATE IS NOT NULL.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DAYS_TO_PAY', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'DAYS_TO_PAY', 'Conditional', 'IFF(FACT.CLEARING_DATE IS NULL, NULL, FACT.DAYS_TO_PAY) AS DAYS_TO_PAY: paid items only.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DAYS_TO_PAY', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'CLEARING_DATE', 'Conditional', 'Empty for unpaid items (CLEARING_DATE IS NULL).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'IS_PAID_ON_TIME', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'CLEARING_DATE', 'Derived', 'IFF(CLEARING_DATE IS NULL, NULL, CLEARING_DATE <= NET_DUE_DATE).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'IS_PAID_ON_TIME', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'NET_DUE_DATE', 'Derived', 'Compared with the clearing date.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'DEBIT_CREDIT_INDICATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'DEBIT_CREDIT_INDICATOR', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_LOCAL', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'AMOUNT_LOCAL', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'LOCAL_CURRENCY', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'LOCAL_CURRENCY', 'Direct', 'Passed through.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_USD_ME', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'AMOUNT_LOCAL', 'Derived', 'ROUND(AMOUNT_LOCAL x USD_RATE_ME, 2); rate of the posting month, fallback to the company code base rate.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_USD_ME', '{{EDW}}.DIM_CURRENCY_RATE_MONTHLY', 'USD_RATE_ME', 'Lookup', 'Join with DIM_CURRENCY_RATE_MONTHLY on LOCAL_CURRENCY = CURRENCY and posting month = RATE_MONTH.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_USD_MA', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'AMOUNT_LOCAL', 'Derived', 'ROUND(AMOUNT_LOCAL x USD_RATE_MA, 2); rate of the posting month, fallback to the company code base rate.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'AMOUNT_USD_MA', '{{EDW}}.DIM_CURRENCY_RATE_MONTHLY', 'USD_RATE_MA', 'Lookup', 'Join with DIM_CURRENCY_RATE_MONTHLY on LOCAL_CURRENCY = CURRENCY and posting month = RATE_MONTH.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAID_TERMS_DENOMINATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'DEBIT_CREDIT_INDICATOR', 'Conditional', 'CASE WHEN DAYS_TO_PAY IS NULL THEN 0 WHEN DEBIT_CREDIT_INDICATOR = ''S'' THEN -1 * ABS(AMOUNT_USD_MA) ELSE ABS(AMOUNT_USD_MA) END. Only paid items count; credit memos reduce the weight.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAID_TERMS_DENOMINATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'AMOUNT_LOCAL', 'Conditional', 'Weight = USD amount at monthly-average rate (AMOUNT_USD_MA).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAID_TERMS_NUMERATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'CLEARING_DATE', 'Derived', 'PAID_TERMS_DENOMINATOR x COALESCE(DAYS_TO_PAY, 0). Weighted average paid terms = SUM(numerator) / SUM(denominator).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'PAID_TERMS_NUMERATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'AMOUNT_LOCAL', 'Derived', 'Through PAID_TERMS_DENOMINATOR (USD amount, sign by debit/credit).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'OFFERED_TERMS_DENOMINATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'PAYMENT_TERMS_DAYS', 'Conditional', 'CASE WHEN DAYS_OFFERED_TERMS IS NULL THEN 0 WHEN DEBIT_CREDIT_INDICATOR = ''S'' THEN -1 * ABS(AMOUNT_USD_MA) ELSE ABS(AMOUNT_USD_MA) END.'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'OFFERED_TERMS_DENOMINATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'AMOUNT_LOCAL', 'Conditional', 'Weight = USD amount at monthly-average rate (AMOUNT_USD_MA).'),
('Datamart', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'OFFERED_TERMS_NUMERATOR', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL', 'PAYMENT_TERMS_DAYS', 'Derived', 'OFFERED_TERMS_DENOMINATOR x COALESCE(DAYS_OFFERED_TERMS, 0). Weighted average offered terms = SUM(numerator) / SUM(denominator).'),
-- EDW rate table
('EDW', '{{EDW}}.DIM_CURRENCY_RATE_MONTHLY', 'USD_RATE_ME', '{{EDW}}.DIM_COMPANY_CODE', 'USD_EXCHANGE_RATE', 'Derived', 'Synthetic: base rate x (1 + 3% seasonal variation) per month. In production: SAP exchange rate table, rate type month-end.'),
('EDW', '{{EDW}}.DIM_CURRENCY_RATE_MONTHLY', 'USD_RATE_MA', '{{EDW}}.DIM_COMPANY_CODE', 'USD_EXCHANGE_RATE', 'Derived', 'Synthetic: base rate x (1 + 2% seasonal variation) per month. In production: SAP exchange rate table, rate type monthly average.');

DELETE FROM {{DATABASE}}.{{KF}}.KF_GLOSSARY
WHERE TERM IN ('Weighted Average Paid Terms', 'Weighted Average Offered Terms', 'Paid Terms Gap', 'On-time Payment Rate',
               'Amount USD (Month-End Rate)', 'Amount USD (Monthly Average Rate)', 'Days to Pay');

INSERT INTO {{DATABASE}}.{{KF}}.KF_GLOSSARY (TERM, DEFINITION, CALCULATION, IMPLEMENTED_IN, SYNONYMS, OWNER, STATUS, APPROVED_ON, SOURCE_DOCUMENT, TERM_TYPE)
SELECT column1, column2, column3, column4, column5, 'AP Finance Data Owner (role)', column6, TRY_TO_DATE(column7), 'Mapping sheet v1.1, payment terms metrics', column8 FROM VALUES
('Weighted Average Paid Terms', 'Average number of days the company actually takes to pay, weighted by the USD amount of each paid item.',
 'SUM(PAID_TERMS_NUMERATOR) / SUM(PAID_TERMS_DENOMINATOR); numerator = USD amount x days to pay, denominator = USD amount of paid items (credit memos negative).',
 '{{DATAMART}}.DM_AP_PAYMENT_TERMS.PAID_TERMS_NUMERATOR', 'WAPT, AWPT, average weighted paid terms, actual payment days', 'Approved', '2025-06-30', 'KPI'),
('Weighted Average Offered Terms', 'Average payment term days agreed with vendors, weighted by the USD amount of each item.',
 'SUM(OFFERED_TERMS_NUMERATOR) / SUM(OFFERED_TERMS_DENOMINATOR); numerator = USD amount x payment term days.',
 '{{DATAMART}}.DM_AP_PAYMENT_TERMS.OFFERED_TERMS_NUMERATOR', 'weighted payment terms, average weighted terms, contractual terms', 'Approved', '2025-06-30', 'KPI'),
('Paid Terms Gap', 'How many days later (positive) or earlier (negative) than the agreed terms the company pays, on a weighted basis.',
 'Weighted Average Paid Terms - Weighted Average Offered Terms.', '{{DATAMART}}.DM_AP_PAYMENT_TERMS', 'terms gap, payment delay, early payment days', 'Draft', NULL, 'KPI'),
('On-time Payment Rate', 'Share of paid items paid on or before the net due date.',
 'COUNT_IF(IS_PAID_ON_TIME) / COUNT_IF(IS_PAID).', '{{DATAMART}}.DM_AP_PAYMENT_TERMS.IS_PAID_ON_TIME', 'on-time payment %, OTP, payment compliance', 'Approved', '2025-06-30', 'KPI'),
('Amount USD (Month-End Rate)', 'Amount converted to US dollars at the month-end rate of the posting month.',
 'AMOUNT_LOCAL x USD_RATE_ME (DIM_CURRENCY_RATE_MONTHLY, posting month).', '{{DATAMART}}.DM_AP_PAYMENT_TERMS.AMOUNT_USD_ME', 'USD ME, month-end USD amount', 'Approved', '2025-06-30', 'KPI'),
('Amount USD (Monthly Average Rate)', 'Amount converted to US dollars at the monthly-average rate of the posting month.',
 'AMOUNT_LOCAL x USD_RATE_MA (DIM_CURRENCY_RATE_MONTHLY, posting month).', '{{DATAMART}}.DM_AP_PAYMENT_TERMS.AMOUNT_USD_MA', 'USD MA, average-rate USD amount', 'Approved', '2025-06-30', 'KPI'),
('Days to Pay', 'Number of days between the document date and the payment (clearing) date of an item; for unpaid items, days since the document date (EDW fact).',
 'CASE WHEN CLEARING_DATE IS NULL THEN DATEDIFF(day, DOCUMENT_DATE, CURRENT_DATE()) ELSE DATEDIFF(day, DOCUMENT_DATE, CLEARING_DATE) END; the payment terms datamart keeps paid items only.', '{{EDW}}.FACT_ACCOUNTS_PAYABLE_GLOBAL.DAYS_TO_PAY', 'payment days, days to settle', 'Approved', '2025-06-30', 'Business term');

-- ---------------------------------------------------------------------
-- Load scripts: the actual SQL of every load procedure (where the logic lives), readable by the agent
-- ---------------------------------------------------------------------
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_LOAD_SCRIPTS (
  SCRIPT_NAME     VARCHAR COMMENT 'Load procedure name.',
  PROCEDURE_NAME  VARCHAR COMMENT 'Fully qualified procedure.',
  TARGET_LAYER    VARCHAR COMMENT 'Layer the procedure loads.',
  TARGET_OBJECTS  VARCHAR COMMENT 'Tables the procedure writes.',
  SOURCE_OBJECTS  VARCHAR COMMENT 'Tables the procedure reads.',
  SCHEDULED_BY    VARCHAR COMMENT 'Snowflake task that runs it.',
  SCRIPT_SQL      VARCHAR COMMENT 'Full SQL (DDL) of the procedure, read with GET_DDL.',
  CAPTURED_AT     TIMESTAMP_LTZ COMMENT 'When the script was captured.'
) COMMENT = 'Load scripts (DML) of the AP model with their full SQL: where the transformation logic is implemented.';

INSERT INTO {{DATABASE}}.{{KF}}.KF_LOAD_SCRIPTS
SELECT 'LOAD_EDW', '{{DATABASE}}.{{EDW}}.LOAD_EDW()', 'EDW', 'DIM_COMPANY_CODE, DIM_VENDOR, FACT_ACCOUNTS_PAYABLE_GLOBAL',
       'SAP_BSEG, SAP_BKPF, SAP_BSEC, SAP_T001, SAP_T005T, SAP_TCURX, SAP_T003T, SAP_LFA1, SAP_LFBK', 'TASK_LOAD_EDW',
       GET_DDL('PROCEDURE', '{{DATABASE}}.{{EDW}}.LOAD_EDW()'), CURRENT_TIMESTAMP();
INSERT INTO {{DATABASE}}.{{KF}}.KF_LOAD_SCRIPTS
SELECT 'LOAD_AP_DATAMART', '{{DATABASE}}.{{DATAMART}}.LOAD_AP_DATAMART()', 'Datamart', 'DM_AP_OPEN_ITEMS, DM_AP_AGING_SUMMARY, DM_AP_VENDOR',
       'FACT_ACCOUNTS_PAYABLE_GLOBAL, DIM_VENDOR, DIM_COMPANY_CODE, AP_AGING_BUCKETS', 'TASK_LOAD_AP_DATAMART',
       GET_DDL('PROCEDURE', '{{DATABASE}}.{{DATAMART}}.LOAD_AP_DATAMART()'), CURRENT_TIMESTAMP();
INSERT INTO {{DATABASE}}.{{KF}}.KF_LOAD_SCRIPTS
SELECT 'LOAD_AP_PAYMENT_TERMS', '{{DATABASE}}.{{DATAMART}}.LOAD_AP_PAYMENT_TERMS()', 'Datamart', 'DM_AP_PAYMENT_TERMS',
       'FACT_ACCOUNTS_PAYABLE_GLOBAL, DIM_VENDOR, DIM_COMPANY_CODE, DIM_CURRENCY_RATE_MONTHLY', 'TASK_LOAD_AP_PAYMENT_TERMS',
       GET_DDL('PROCEDURE', '{{DATABASE}}.{{DATAMART}}.LOAD_AP_PAYMENT_TERMS()'), CURRENT_TIMESTAMP();

-- Rebuild the knowledge layer so the new objects, columns, lineage and KPIs are in the catalog
CALL {{DATABASE}}.{{KF}}.REFRESH_KNOWLEDGE_FABRIC(FALSE);

-- ---------------------------------------------------------------------
-- 4. Excel-style views: the mapping sheet and the business data dictionary in the usual spreadsheet layout
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_S2T_MAPPING_SHEET (
  S_NO                  COMMENT 'Row number.',
  TARGET_TABLE_VIEW     COMMENT 'Target table or view (SCHEMA.OBJECT).',
  EDW_COLUMN            COMMENT 'Target column.',
  SOURCE_EDW_TABLE_VIEW COMMENT 'Source table or view (SCHEMA.OBJECT); Calculated when the value is derived.',
  SOURCE_TABLE          COMMENT 'Source table or view name.',
  SOURCE_EDW_FIELD      COMMENT 'Source column.',
  MAPPING_TYPE          COMMENT 'Direct, Renamed, Lookup, Derived, Conditional or Aggregated.',
  MAPPING_INFORMATION   COMMENT 'Mapping information: join, rule or calculation.',
  TARGET_LAYER          COMMENT 'Layer of the target object.'
)
COMMENT = 'Source-to-target mapping sheet in the usual Excel layout (one row per target column and source column). Reads KF_FIELD_MAPPING.'
AS
SELECT ROW_NUMBER() OVER (ORDER BY CASE TARGET_LAYER WHEN 'Reporting' THEN 1 WHEN 'Datamart' THEN 2 WHEN 'EDW' THEN 3 ELSE 4 END,
                                   TARGET_OBJECT, TARGET_COLUMN, SOURCE_OBJECT, SOURCE_COLUMN),
       TARGET_OBJECT, TARGET_COLUMN,
       IFF(MAPPING_TYPE IN ('Derived', 'Conditional', 'Aggregated'), 'Calculated', SOURCE_OBJECT),
       SPLIT_PART(SOURCE_OBJECT, '.', 2), SOURCE_COLUMN, MAPPING_TYPE, TRANSFORMATION_RULE, TARGET_LAYER
FROM {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING;

-- Mapping workbook rows as delivered (filled by 07c_client_model.sql)
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET (
  SHEET VARCHAR COMMENT 'Workbook sheet the row comes from.', SHEET_ROW NUMBER COMMENT 'Row number in the sheet.',
  LAYER VARCHAR, SCHEMA_NAME VARCHAR, MODEL_NAME VARCHAR COMMENT 'Table / view name.', FIELD_NAME VARCHAR COMMENT 'Column name.',
  BUSINESS_NAME VARCHAR, DEFINITION VARCHAR, SOURCE_SYSTEM VARCHAR,
  SOURCE_EDW_TABLE VARCHAR COMMENT 'Source EDW table / view (datamart sheet).', SOURCE_TABLE VARCHAR, SOURCE_FIELD VARCHAR,
  MAPPING VARCHAR COMMENT 'Mapping / mapping information exactly as in the sheet.'
) COMMENT = 'AP FACT and AP DM mapping sheets exactly as delivered, one row per field.';

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_BUSINESS_DATA_DICTIONARY (
  EDW_MODEL_NAME               COMMENT 'EDW model name: table or view name.',
  EDW_FIELD_NAME               COMMENT 'EDW field name: column name.',
  BUSINESS_FRIENDLY_NAME       COMMENT 'Business friendly name of the field.',
  BUSINESS_FRIENDLY_DEFINITION COMMENT 'Business friendly definition of the field.',
  SOURCE_SYSTEM                COMMENT 'Source system of the data.',
  SOURCE_TABLE                 COMMENT 'SAP source table(s) at the start of the lineage.',
  SOURCE_FIELD                 COMMENT 'SAP source field(s) at the start of the lineage.',
  MAPPING                      COMMENT 'Mapping: Direct Mapping, or the rule / calculation that produces the field.',
  DATA_TYPE                    COMMENT 'Data type with length.',
  DATA_LAYER                   COMMENT 'Landing, EDW, Datamart or Reporting.',
  SCHEMA_NAME                  COMMENT 'Schema of the table or view.',
  IS_MASKED                    COMMENT 'TRUE when values are masked for business users.',
  COLUMN_POSITION              COMMENT 'Position of the column in the table.',
  SOURCE_EDW_TABLE_VIEW        COMMENT 'Source EDW table or view (one step upstream).'
)
COMMENT = 'Business data dictionary in the usual Excel layout: per field the business name, definition, source system, SAP source table and field, and mapping rule. Reads KF_COLUMNS and KF_FIELD_MAPPING (walked back to the SAP landing tables).'
AS
WITH RECURSIVE walk (COLUMN_KEY, SRC_OBJECT, SRC_COLUMN, DEPTH) AS (
  SELECT TARGET_OBJECT || '.' || TARGET_COLUMN, SOURCE_OBJECT, SOURCE_COLUMN, 1
  FROM {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING
  UNION ALL
  SELECT w.COLUMN_KEY, m.SOURCE_OBJECT, m.SOURCE_COLUMN, w.DEPTH + 1
  FROM walk w
  JOIN {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING m ON m.TARGET_OBJECT = w.SRC_OBJECT AND m.TARGET_COLUMN = w.SRC_COLUMN
  WHERE w.DEPTH < 6
),
sap_origins AS (
  SELECT COLUMN_KEY,
         LISTAGG(DISTINCT REPLACE(SPLIT_PART(SRC_OBJECT, '.', 2), 'SAP_', ''), ', ') AS SOURCE_TABLE,
         LISTAGG(DISTINCT SRC_COLUMN, ', ') AS SOURCE_FIELD
  FROM walk WHERE SRC_OBJECT LIKE '{{LANDING}}.%' GROUP BY COLUMN_KEY
),
rules AS (
  SELECT TARGET_OBJECT || '.' || TARGET_COLUMN AS COLUMN_KEY,
         IFF(BOOLAND_AGG(MAPPING_TYPE = 'Direct'), 'Direct Mapping',
             LISTAGG(DISTINCT TRANSFORMATION_RULE, ' | ')) AS MAPPING,
         LISTAGG(DISTINCT SOURCE_OBJECT, ', ') AS SOURCE_OBJECTS
  FROM {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING GROUP BY 1
)
SELECT c.OBJECT_NAME, c.COLUMN_NAME, c.BUSINESS_NAME,
       COALESCE(NULLIF(TRIM(REGEXP_REPLACE(c.DESCRIPTION, '^[^:]{1,60}:', '')), ''), c.DESCRIPTION,
                'No description yet. AI draft: ' || c.AI_SUGGESTED_DESCRIPTION),
       'SAP ECC (synthetic)',
       COALESCE(o.SOURCE_TABLE, IFF(c.DATA_LAYER = 'Landing', REPLACE(c.OBJECT_NAME, 'SAP_', ''), NULL)),
       COALESCE(o.SOURCE_FIELD, IFF(c.DATA_LAYER = 'Landing', c.COLUMN_NAME, NULL)),
       COALESCE(r.MAPPING, IFF(c.DATA_LAYER = 'Landing', 'Replicated from SAP as is', 'Load metadata (no source field)')),
       c.DATA_TYPE_FULL, c.DATA_LAYER, c.SCHEMA_NAME, c.IS_MASKED, c.ORDINAL_POSITION, r.SOURCE_OBJECTS
FROM {{DATABASE}}.{{KF}}.KF_COLUMNS c
LEFT JOIN sap_origins o ON o.COLUMN_KEY = c.COLUMN_KEY
LEFT JOIN rules r ON r.COLUMN_KEY = c.COLUMN_KEY
WHERE c.OBJECT_NAME NOT IN (SELECT DISTINCT MODEL_NAME FROM {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET)
UNION ALL
-- Objects documented in the mapping workbook: exactly as in the sheet
SELECT e.MODEL_NAME, e.FIELD_NAME, e.BUSINESS_NAME, e.DEFINITION, e.SOURCE_SYSTEM, e.SOURCE_TABLE, e.SOURCE_FIELD, e.MAPPING,
       k.DATA_TYPE_FULL, e.LAYER, e.SCHEMA_NAME, k.IS_MASKED, e.SHEET_ROW, NULLIF(e.SOURCE_EDW_TABLE, '')
FROM {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET e
LEFT JOIN {{DATABASE}}.{{KF}}.KF_COLUMNS k ON k.OBJECT_NAME = e.MODEL_NAME AND k.COLUMN_NAME = e.FIELD_NAME AND k.SCHEMA_NAME = e.SCHEMA_NAME;

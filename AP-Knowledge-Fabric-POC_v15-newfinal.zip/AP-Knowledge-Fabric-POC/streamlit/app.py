# AP Knowledge Co-worker - Streamlit in Snowflake app (v15: client demo feedback, v3 layout)
# Three views: Business ontology (entities, relationships, domains), Technical lineage (process context,
# expandable lineage graph, column lineage) and Reports and export (5 reports as CSV, Excel, print / PDF).
# Side panel: Answer / Business definition / Relationships / Business-to-technical drill down, the agent chat,
# and Draft & Approve. Every answer shows which metadata source it used (Snowflake Metadata, Uploaded Excel,
# Uploaded Word Document, Business Glossary). Reads live from Snowflake; synthetic POC data.
import hashlib
import html
import io
import json
import re
import zipfile
from datetime import datetime

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
from snowflake.snowpark.context import get_active_session

# Names (kept in sync with config.py by run.add_app(); edit here if you deploy the file by hand)
DB = "POC_AP_KNOWLEDGE_FABRIC"            # config.DATABASE
KF_SCHEMA = "KNOWLEDGE_FABRIC"            # config.KF
EDW = "CORP_TRAN"                         # config.EDW
DATAMART = "CORP_DM_FIN"                  # config.DATAMART
REPORTING = "CORP_REPORT"                 # config.REPORTING
LANDING = "SRC_SAPECC_ARP"                # config.LANDING
AGENT_NAME = "AP_KNOWLEDGE_COWORKER"      # config.AGENT
AI_MODEL = "claude-sonnet-4-5"            # config.AI_MODEL
POWER_ROLE = "AP_KF_POWER_USER"           # config.POWER_ROLE
BUSINESS_ROLE = "AP_KF_BUSINESS_USER"     # config.BUSINESS_ROLE
DOCS_SEARCH = "KF_DOCS_SEARCH_SVC"        # config.DOCS_SEARCH
KF = DB + "." + KF_SCHEMA
AGENT = KF + "." + AGENT_NAME
FACT = "FACT_ACCOUNT_PAYABLE_GBL"
DM = "DM_FIN_AP_GBL_DETAILS"
VIEWS = ["VW_FIN_AP_CLOSING_BALANCE", "VW_FIN_AP_VENDOR_PAYMENT", "VW_FIN_AP_INV_DETAILS"]
ENGINEER = "Data Engineer"
ARCHITECT = "Data Architect"
OWNER = "Functional Owner"          # finance business owner: approves descriptions in Draft & Approve
ROLES = [ENGINEER, ARCHITECT, OWNER]
VIEW_NAMES = ["Business ontology", "Technical lineage", "Reports and export"]

# Short questions from the v3 demo; the persona test questions come from KF_PERSONA_QUESTIONS (11b)
QUICK = {
    ENGINEER: ["Which tables hold AP Document?", "Which SAP tables feed the AP fact table?", "Where does AMT_DOC come from?",
               "How is aging calculated?", "Does vendor country exist?", "Which reporting views use this model?"],
    ARCHITECT: ["Which tables hold AP Document?", "How are Vendor and Invoice related?", "Which reporting views use this model?",
                "How complete is the metadata?"],
    OWNER: ["What is a Vendor?", "How are Vendor and Invoice related?", "What AP data is available?",
            "Which reporting views use this model?", "How complete is the metadata?", "Who owns this model?"],
}
ATTR_LIST = [
    ("EDW database and schema", "In which EDW schema (and database, if stated) does {o} live?"),
    ("Table and view names", "Which tables and views are involved in {o}?"),
    ("Column and field names", "What are the column and field names for {o}?"),
    ("Data type and maximum length", "What are the data type and maximum length of {o}?"),
    ("Primary and business keys", "What are the primary and business keys of {o}?"),
    ("Business-friendly name", "What is the business-friendly name of {o}?"),
    ("Business-friendly description", "How would you describe {o} in business terms?"),
    ("Technical description", "What is the technical description of {o}?"),
    ("Model / table description", "What does the table that holds {o} represent?"),
    ("Transactional or master data", "Is {o} transactional or master data?"),
    ("Transformation and business rules", "Which transformation and business rules apply to {o}?"),
    ("Data lineage", "What is the data lineage of {o}?"),
    ("Source-to-target mapping", "What is the source-to-target mapping for {o}?"),
    ("Existing KPI definitions", "Which existing KPIs use {o}, and how are they defined?"),
    ("Portfolio and domain", "Which portfolio or domain does {o} belong to?"),
]
SRC_CLASS = {"Snowflake Metadata": "sf", "Uploaded Excel": "xls", "Uploaded Word Document": "doc",
             "Business Glossary": "glo", "Project documents": "pdf", "Draft & Approve": "apv"}
TOOL_SOURCES = {"metadata_analyst": ["Snowflake Metadata", "Uploaded Excel"],
                "ontology_analyst": ["Business Glossary", "Uploaded Excel", "Snowflake Metadata"],
                "ap_metrics_analyst": ["Snowflake Metadata"], "catalog_search": ["Snowflake Metadata"],
                "document_search": ["Project documents"]}
REPORTS = {
    "sttm": ("Source-to-target mapping: " + DM, "KF_RPT_SOURCE_TO_TARGET",
             {"ROW_NO": "#", "TARGET_TABLE": "Target table", "TARGET_COLUMN": "Target column", "SOURCE_OBJECT": "Source object",
              "SOURCE_FIELD": "Source field", "TRANSFORMATION_TYPE": "Transformation type", "TRANSFORMATION_RULE": "Transformation / rule",
              "SAP_ORIGIN": "SAP origin", "BUSINESS_DEFINITION": "Business definition", "DEFINITION_STATUS": "Definition status",
              "SNOWFLAKE_DATA_TYPE": "Data type (Snowflake)", "IN_SNOWFLAKE": "In Snowflake", "METADATA_SOURCE": "Metadata source",
              "CITATION": "Citation"}, ["Uploaded Excel", "Snowflake Metadata"]),
    "lineage": ("Column-level lineage: SAP to data mart to reporting views", "KF_RPT_COLUMN_LINEAGE",
                {"MART_COLUMN": "Mart column", "SAP_SOURCE": "SAP source", "FACT_FIELD": "Fact field",
                 "CALCULATION_INPUTS": "Calculation inputs", "JOIN_KEYS": "Join keys", "REPORTING_VIEWS": "Reporting views",
                 "TRANSFORMATION_TYPE": "Transformation type", "IN_SNOWFLAKE": "In Snowflake", "EVIDENCE": "Evidence",
                 "METHOD_NOTE": "Method note"}, ["Uploaded Excel", "Snowflake Metadata"]),
    "entity": ("Business entity to technical object map", "KF_RPT_ENTITY_OBJECT_MAP",
               {"ENTITY": "Entity", "ENTITY_TYPE": "Type", "DOMAINS": "Domains",
                "BUSINESS_DEFINITION": "Business definition (sample glossary)", "DEFINITION_STATUS": "Definition status",
                "EDW_OBJECTS": "EDW objects", "SAP_TABLES": "SAP tables", "SNOWFLAKE_OBJECTS": "Snowflake objects",
                "FACT_FIELDS": "Fact fields", "MART_COLUMNS": "Mart columns", "STATUS": "Status", "OWNER_ROLE": "Owner (role)"},
               ["Uploaded Excel", "Business Glossary", "Snowflake Metadata"]),
    "rel": ("Business entity relationships", "KF_RPT_ENTITY_RELATIONSHIPS",
            {"FROM_ENTITY": "From", "RELATIONSHIP": "Relationship", "TO_ENTITY": "To", "DOMAIN": "Domain",
             "EVIDENCE": "Evidence", "DETAIL": "Detail", "EVIDENCE_ROWS": "Evidence rows"}, ["Uploaded Excel", "Business Glossary"]),
    "source": ("Metadata source transparency and completeness", "KF_RPT_METADATA_SOURCES",
               {"SECTION": "Section", "ITEM": "Item", "STATUS_COVERAGE": "Status / coverage", "DETAIL": "Detail"},
               ["Snowflake Metadata", "Uploaded Excel", "Uploaded Word Document", "Business Glossary"]),
}
FRIENDLY = {"FACT_ACCOUNT_PAYABLE_GBL": "AP transactions", "DIM_VENDOR_GEN": "Vendor master (general)",
            "DIM_VENDOR_COMPANY": "Vendor master (company)", "DIM_ENTITY": "Legal entity", "VW_DIM_ORG": "Organization",
            "TV_TIME_FISCAL_DAY": "Fiscal calendar", "TV_DIM_COUNTRY": "Country", "FACT_PURCHASE_ORDER": "Purchase orders",
            "TV_XREF_OS_TRANSFORMATIONS": "Reference mapping", "TV_XREF_VENDOR_MPO": "Vendor reference mapping",
            "Calculated": "Calculated in the mart", "BSEG": "AP line items", "BKPF": "Document header", "BSET": "Tax data",
            "RSEG": "Invoice items", "EKKO": "PO header", "EKPO": "PO items", "LFB1": "Vendor company data",
            "KNB1": "Customer company data", "MARA": "Material master", "SKAT": "GL account text", "T003T": "Document type text",
            "PAYR": "Payments", "VW_FIN_AP_CLOSING_BALANCE": "Closing balance report",
            "VW_FIN_AP_VENDOR_PAYMENT": "Vendor payment report", "VW_FIN_AP_INV_DETAILS": "Invoice details report"}

# HTML/JS for the two interactive graphs (rendered with st.components.v1.html, no external libraries).
# Business ontology: drag nodes, hover to focus, click to inspect, domain pills, type filters, search, reset layout.
# Technical lineage: click a node to expand or collapse, expand all / collapse, highlighted path for a column.

ONTOLOGY_HTML = r"""<!doctype html><html><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{margin:0;font:13px/1.45 -apple-system,"Segoe UI",Arial,sans-serif;background:#0B1B2B;color:#E6EEF5}
#wrap{padding:12px 14px 10px;background:#0B1B2B;border-radius:10px}
.top{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
.ttl b{font-size:15px}.ttl span{color:#9FB3C8;font-size:12px}
input{background:#13263A;border:1px solid #2A4360;color:#E6EEF5;border-radius:6px;padding:6px 9px;font-size:12px;width:200px}
button{background:#fff;color:#0070AD;border:1px solid #0070AD;border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
.pills{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}
.pill{border:1px solid #2A4360;background:#13263A;color:#D6E2EE;border-radius:999px;padding:3px 12px;font-size:12px;cursor:pointer;user-select:none}
.pill small{color:#8FA3B8;font-size:10px;margin-left:3px}.pill.on{background:#12ABDB;color:#04121F;border-color:#12ABDB;font-weight:600}
.pill.on small{color:#04121F}.pill.off{opacity:.45}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px;vertical-align:-1px}
#stage{position:relative;display:flex;gap:0;margin-top:10px;border:1px solid #1E3550;border-radius:8px;background:radial-gradient(#13263A 1px,transparent 1px) 0 0/18px 18px,#0D2033}
#g{display:block;flex:1 1 auto;min-width:0;width:100%;height:440px}
#insp{flex:0 0 250px;margin:8px;max-height:424px;overflow:auto;background:#0F2236F2;border:1px solid #2A4360;border-radius:8px;padding:10px 12px;display:none;font-size:12px}
#insp h4{margin:0 0 4px;font-size:14px}#insp .x{float:right;cursor:pointer;color:#8FA3B8}
.tag{display:inline-block;font-size:10.5px;border-radius:9px;padding:0 7px;margin:0 4px 4px 0;background:#1E3550;color:#CFE0EF}
.tag.ok{background:#0F3D2B;color:#6EE7B7}.tag.dr{background:#3D2A08;color:#FBBF24}.tag.no{background:#3D1414;color:#FCA5A5}
.sec{color:#8FA3B8;font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;margin:8px 0 3px}
.row{padding:2px 0;border-bottom:1px dashed #1E3550}.mono{font-family:ui-monospace,Menlo,monospace;font-size:11.5px}
.legend{display:flex;flex-wrap:wrap;gap:14px;margin-top:9px;color:#B7C7D7;font-size:11.5px;align-items:center}
.note{margin-top:7px;color:#B7C7D7;font-size:12px}
</style></head><body><div id="wrap">
<div class="top"><div class="ttl"><b>Business ontology</b> <span>· drag nodes, click to inspect, hover to focus</span></div>
<div><input id="q" placeholder="Search objects…"> <button id="reset">Reset layout</button></div></div>
<div class="pills" id="doms"></div><div class="pills" id="types"></div>
<div id="stage"><svg id="g" viewBox="40 20 710 440"></svg><div id="insp"></div></div>
<div class="legend">
<span><svg width="34" height="8"><line x1="0" y1="4" x2="34" y2="4" stroke="#B7C7D7" stroke-width="1.6"/></svg> Supported by workbook</span>
<span><svg width="34" height="8"><line x1="0" y1="4" x2="34" y2="4" stroke="#B7C7D7" stroke-width="1.6" stroke-dasharray="5 4"/></svg> Proposed</span>
<span><svg width="14" height="14"><circle cx="7" cy="7" r="6" fill="none" stroke="#B7C7D7" stroke-dasharray="2 2"/></svg> Shared across domains</span>
<span><span class="dot" style="background:#E5484D"></span>No tables in workbook</span>
<span><span class="dot" style="background:#3DD68C"></span>Objects found in Snowflake</span></div>
<div class="note" id="note"></div></div>
<script>
const D=__DATA__;
const TC={"Master data":"#12ABDB","Transaction":"#F5A623","Reference":"#9AA9B8","Report":"#A78BFA"};
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const E={};D.entities.forEach(e=>E[e.id]=e);
let dom=D.domain||'ap',sel=D.selected||'',hov='',q='',drag=null;const types=new Set(Object.keys(TC));const pos={};
const svg=document.getElementById('g'),insp=document.getElementById('insp');
function inDom(e){return dom==='ent'||e.doms.indexOf(dom)>-1}
function visible(){return D.entities.filter(e=>inDom(e)&&types.has(e.t))}
function seed(){const p={};D.entities.filter(inDom).forEach(e=>p[e.id]={x:e.x,y:e.y});if(dom!=='ap')force(p);return p}
function layout(){if(!pos[dom])pos[dom]=seed();return pos[dom]}
function force(p){const ids=Object.keys(p);const rel=D.rels.filter(r=>p[r.a]&&p[r.b]);
 ids.forEach((id,i)=>{p[id].x+=((i*37)%23)-11;p[id].y+=((i*53)%19)-9});
 for(let it=0;it<500;it++){const f={};ids.forEach(id=>f[id]={x:0,y:0});
  for(let i=0;i<ids.length;i++)for(let j=i+1;j<ids.length;j++){const a=p[ids[i]],b=p[ids[j]];const dx=a.x-b.x,dy=a.y-b.y;const d2=dx*dx+dy*dy+1;const d=Math.sqrt(d2);const k=22000/d2;
   f[ids[i]].x+=k*dx/d;f[ids[i]].y+=k*dy/d;f[ids[j]].x-=k*dx/d;f[ids[j]].y-=k*dy/d}
  rel.forEach(r=>{const a=p[r.a],b=p[r.b];const dx=b.x-a.x,dy=b.y-a.y;const d=Math.sqrt(dx*dx+dy*dy)+.01;const k=(d-150)*.04;
   f[r.a].x+=k*dx/d;f[r.a].y+=k*dy/d;f[r.b].x-=k*dx/d;f[r.b].y-=k*dy/d});
  const t=Math.max(.15,1-it/500)*6;
  ids.forEach(id=>{f[id].x+=(360-p[id].x)*.006;f[id].y+=(235-p[id].y)*.008;
   p[id].x+=Math.max(-t,Math.min(t,f[id].x));p[id].y+=Math.max(-t,Math.min(t,f[id].y));
   p[id].x=Math.max(75,Math.min(715,p[id].x));p[id].y=Math.max(50,Math.min(415,p[id].y))})}}
function render(){const p=layout(),vis=visible(),ids=new Set(vis.map(e=>e.id));
 const rels=D.rels.filter(r=>ids.has(r.a)&&ids.has(r.b));
 let s='<defs>'+['#7F95AB','#F5A623'].map((c,i)=>'<marker id="m'+i+'" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0L10,5L0,10z" fill="'+c+'"/></marker>').join('')+'</defs>';
 rels.forEach(r=>{const a=p[r.a],b=p[r.b];const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,R=27;
  const x1=a.x+dx/d*R,y1=a.y+dy/d*R,x2=b.x-dx/d*(R+2),y2=b.y-dy/d*(R+2),mx=(x1+x2)/2,my=(y1+y2)/2;
  s+='<g class="e" data-a="'+r.a+'" data-b="'+r.b+'"><line x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'" stroke="#7F95AB" stroke-width="1.3"'+(r.style==='dashed'?' stroke-dasharray="5 4"':'')+' marker-end="url(#m0)"><title>'+esc(r.l+': '+r.detail)+'</title></line>'+
   '<text x="'+mx+'" y="'+(my-4)+'" font-size="9" fill="#A9BBCC" text-anchor="middle">'+esc(r.l)+'</text></g>'});
 vis.forEach(e=>{const c=p[e.id],col=TC[e.t];
  s+='<g class="n" data-id="'+e.id+'" transform="translate('+c.x+','+c.y+')" style="cursor:pointer">';
  s+='<circle class="sel" r="35" fill="none" stroke="#F5A623" stroke-width="2.2" opacity="0"/>';
  if(e.shared)s+='<circle r="30.5" fill="none" stroke="#8FA3B8" stroke-dasharray="3 3"/>';
  s+='<circle r="24" fill="#0F2236" stroke="'+col+'" stroke-width="2.6"'+(e.status==='Planned'?' stroke-dasharray="4 3" opacity=".75"':'')+'/>';
  s+='<text y="4" text-anchor="middle" font-size="10" font-weight="700" fill="'+col+'">'+esc(e.ab)+'</text>';
  s+='<text y="41" text-anchor="middle" font-size="10.5" font-weight="600" fill="#E6EEF5">'+esc(e.n)+'</text>';
  if(e.status==='Live'&&e.wb===0)s+='<circle cx="18" cy="-18" r="5" fill="#E5484D"><title>No tables in workbook</title></circle>';
  else if(e.sf>0)s+='<circle cx="18" cy="-18" r="4" fill="#3DD68C"><title>'+e.sf+' object(s) found in Snowflake</title></circle>';
  s+='<title>'+esc(e.n+' · '+e.t)+'</title></g>'});
 svg.innerHTML=s;bind();paint();inspect()}
function paint(){const f=hov||sel;const vis=visible();const nb=new Set();
 if(f){nb.add(f);D.rels.forEach(r=>{if(r.a===f)nb.add(r.b);if(r.b===f)nb.add(r.a)})}
 const m=q?new Set(vis.filter(e=>(e.n+' '+e.ab+' '+e.syn+' '+e.objs.map(o=>o.name+' '+o.friendly).join(' ')).toLowerCase().indexOf(q)>-1).map(e=>e.id)):null;
 svg.querySelectorAll('g.n').forEach(g=>{const id=g.dataset.id;const dim=(f&&!nb.has(id))||(m&&!m.has(id));g.setAttribute('opacity',dim?.22:1);
  g.querySelector('.sel').setAttribute('opacity',id===sel?1:0)});
 svg.querySelectorAll('g.e').forEach(g=>{const a=g.dataset.a,b=g.dataset.b;const on=f&&(a===f||b===f);const dim=(f&&!on)||(m&&!(m.has(a)||m.has(b)));
  const l=g.querySelector('line');l.setAttribute('stroke',on?'#F5A623':'#7F95AB');l.setAttribute('stroke-width',on?2.2:1.3);l.setAttribute('marker-end','url(#m'+(on?1:0)+')');g.setAttribute('opacity',dim?.15:1)})}
function pt(ev){const P=svg.createSVGPoint();P.x=ev.clientX;P.y=ev.clientY;return P.matrixTransform(svg.getScreenCTM().inverse())}
function bind(){svg.querySelectorAll('g.n').forEach(g=>{const id=g.dataset.id;
 g.addEventListener('mouseenter',()=>{if(!drag){hov=id;paint()}});
 g.addEventListener('mouseleave',()=>{if(!drag){hov='';paint()}});
 g.addEventListener('mousedown',ev=>{ev.preventDefault();const P=pt(ev);drag={id:id,x:P.x,y:P.y,moved:false}})})}
window.addEventListener('mousemove',ev=>{if(!drag)return;const P=pt(ev),p=layout()[drag.id];
 if(Math.abs(P.x-drag.x)+Math.abs(P.y-drag.y)>3)drag.moved=true;
 if(drag.moved){p.x=Math.max(65,Math.min(725,P.x));p.y=Math.max(45,Math.min(430,P.y));render()}});
window.addEventListener('mouseup',()=>{if(!drag)return;const d=drag;drag=null;if(!d.moved){sel=(sel===d.id?'':d.id);render()}});
svg.addEventListener('click',ev=>{if(ev.target===svg){sel='';render()}});
function inspect(){if(!sel||!E[sel]||!inDom(E[sel])){insp.style.display='none';return}const e=E[sel];
 const rs=D.rels.filter(r=>r.a===sel||r.b===sel);
 let h='<span class="x" id="ix">✕</span><h4>'+esc(e.n)+'</h4><span class="tag">'+esc(e.t)+'</span><span class="tag">'+esc(e.doms.map(d=>D.dn[d]||d).join(', '))+'</span>'+(e.status==='Planned'?'<span class="tag dr">Planned</span>':'')+
  '<div>'+esc(e.def)+'</div><div style="color:#8FA3B8;font-size:11px;margin-top:3px">Business Glossary · '+esc(e.ds)+(e.owner?' · owner: '+esc(e.owner):'')+'</div>';
 if(e.narr)h+='<div class="sec">Process narrative</div><div>'+esc(e.narr)+'</div><div style="color:#8FA3B8;font-size:11px">Uploaded Word Document · '+esc(e.narrsrc)+'</div>';
 h+='<div class="sec">Technical objects ('+e.objs.length+')</div>';
 if(!e.objs.length)h+='<div><span class="tag no">Not in loaded data</span></div>';
 e.objs.forEach(o=>{h+='<div class="row"><span class="mono">'+esc(o.name)+'</span> <span style="color:#8FA3B8">'+esc(o.role)+'</span><br><span style="color:#A9BBCC">'+esc(o.friendly)+'</span> '+(o.sf?'<span class="tag ok">in Snowflake</span>':'<span class="tag">workbook only</span>')+'</div>'});
 h+='<div class="sec">Relationships ('+rs.length+')</div>';
 rs.forEach(r=>{h+='<div class="row">'+esc(E[r.a].n)+' <b>'+esc(r.l)+'</b> '+esc(E[r.b].n)+' <span class="tag '+(r.style==='solid'?'ok':'dr')+'">'+(r.style==='solid'?'workbook':'proposed')+'</span><br><span style="color:#8FA3B8">'+esc(r.detail)+'</span></div>'});
 h+='<div style="color:#8FA3B8;font-size:11px;margin-top:8px">Pick it under <b>Inspect entity</b> to open definitions, relationships and the drill down in the side panel.</div>';
 insp.innerHTML=h;insp.style.display='block';document.getElementById('ix').onclick=()=>{sel='';render()}}
function pills(){const d=document.getElementById('doms');d.innerHTML='';
 D.domains.forEach(x=>{const b=document.createElement('span');b.className='pill'+(x.id===dom?' on':'');b.innerHTML=esc(x.n)+(x.status==='View'?'':'<small>('+esc(x.status)+')</small>');
  b.onclick=()=>{dom=x.id;pills();render();note()};d.appendChild(b)});
 const t=document.getElementById('types');t.innerHTML='';
 Object.keys(TC).forEach(k=>{const b=document.createElement('span');b.className='pill'+(types.has(k)?'':' off');b.innerHTML='<span class="dot" style="background:'+TC[k]+'"></span>'+k;
  b.onclick=()=>{types.has(k)?types.delete(k):types.add(k);pills();render()};t.appendChild(b)})}
function note(){const x=D.domains.find(d=>d.id===dom);document.getElementById('note').textContent=
 dom==='ap'?'Accounts Payable is live: tables and columns come from Snowflake and the uploaded Excel workbook. Glossary terms and the Word narrative are samples. Solid links are supported by the workbook; dashed links are proposed.':
 dom==='ent'?'Enterprise view: every domain together. Entities with a dashed ring are shared across domains, so one definition serves all of them.':
 (x?x.n:dom)+' is planned: its entities and relationships are proposed and no metadata is loaded yet. Shared entities (dashed ring) already have AP metadata.'}
document.getElementById('q').addEventListener('input',ev=>{q=ev.target.value.trim().toLowerCase();paint()});
document.getElementById('reset').onclick=()=>{delete pos[dom];render()};
pills();render();note();
</script></body></html>"""


LINEAGE_HTML = r"""<!doctype html><html><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{margin:0;font:12px/1.4 -apple-system,"Segoe UI",Arial,sans-serif;color:#1E2A36;background:#fff}
.bar{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:6px}
.leg{display:flex;flex-wrap:wrap;gap:12px;color:#5F6F7E}.leg i{display:inline-block;width:11px;height:11px;border:2px solid;border-radius:3px;margin-right:4px;vertical-align:-1px}
button{background:#fff;color:#0070AD;border:1px solid #0070AD;border-radius:6px;padding:4px 10px;font-size:12px;cursor:pointer;margin-left:4px}
#box{border:1px solid #D9E1E8;border-radius:8px;background:#F8FAFC;overflow:auto;max-height:__MAXH__px}
.hint{color:#5F6F7E;margin-top:5px}
</style></head><body>
<div class="bar"><div class="leg" id="leg"></div><div><button id="ex">Expand all</button><button id="co">Collapse</button></div></div>
<div id="box"></div><div class="hint">Click a node to expand or collapse it. <span style="color:#1E8E5A">●</span> object found in Snowflake. Counts come from the uploaded Excel workbook.</div>
<script>
const D=__DATA__;
const K={process:['Process','#0B2A4A'],view:['Reporting view','#0070AD'],mart:['Data mart','#12ABDB'],fact:['Fact table','#2B6CB0'],master:['Master / reference','#6B7FA3'],calc:['Calculated','#C77700'],sap:['SAP table','#1E8E5A']};
const DEPTHN=['Process','Reporting views','Data mart','Sources in EDW','SAP / base tables'];
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const N={};D.nodes.forEach(n=>{n.kids=[];N[n.id]=n});D.edges.forEach(e=>{if(N[e.a]&&N[e.b]&&N[e.a].kids.indexOf(e.b)<0)N[e.a].kids.push(e.b)});
const HL=new Set(D.hl||[]);const EXP=new Set(D.expanded||['proc']);
document.getElementById('leg').innerHTML=Object.keys(K).map(k=>'<span><i style="border-color:'+K[k][1]+'"></i>'+K[k][0]+'</span>').join('')+'<span><i style="border-color:#C77700;background:#FFF1DB"></i>highlighted</span>';
function vis(){const seen=new Set(['proc']),q=['proc'];while(q.length){const n=N[q.shift()];if(!n||!EXP.has(n.id))continue;n.kids.forEach(k=>{if(!seen.has(k)){seen.add(k);q.push(k)}})}return seen}
const tr=(s,n)=>String(s).length>n?String(s).slice(0,n-1)+'…':String(s);
function render(){const v=vis();const cols=[[],[],[],[],[]];D.nodes.forEach(n=>{if(v.has(n.id))cols[n.d].push(n.id)});
 const W=152,H=42,GX=34,GY=10,top=30;const P={};let mx=1;
 cols.forEach((c,d)=>{mx=Math.max(mx,c.length);c.forEach((id,i)=>P[id]={x:12+d*(W+GX),y:top+i*(H+GY)})});
 const SW=24+5*W+4*GX,SH=top+mx*(H+GY)+8;
 let s='<svg viewBox="0 0 '+SW+' '+SH+'" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="-apple-system,Segoe UI,Arial,sans-serif">';
 DEPTHN.forEach((n,d)=>{if(cols[d].length)s+='<text x="'+(12+d*(W+GX))+'" y="18" font-size="10.5" font-weight="700" fill="#5F6F7E">'+n.toUpperCase()+'</text>'});
 D.edges.forEach(e=>{if(!P[e.a]||!P[e.b]||!EXP.has(e.a))return;const a=P[e.a],b=P[e.b],x1=a.x+W,y1=a.y+H/2,x2=b.x,y2=b.y+H/2,m=(x1+x2)/2;const hot=HL.has(e.a)&&HL.has(e.b);
  s+='<path d="M'+x1+' '+y1+' C'+m+' '+y1+' '+m+' '+y2+' '+x2+' '+y2+'" fill="none" stroke="'+(hot?'#C77700':'#B8C4CE')+'" stroke-width="'+(hot?2.4:1.2)+'"/>';
  if(e.l&&N[e.a].d>=2)s+='<text x="'+m+'" y="'+((y1+y2)/2-3)+'" font-size="9" fill="#7B8794" text-anchor="middle">'+esc(e.l)+'</text>'});
 Object.keys(P).forEach(id=>{const n=N[id],p=P[id],k=K[n.kind]||K.master,hot=HL.has(id);const more=n.kids.length&&!EXP.has(id)?n.kids.length:0;
  s+='<g data-id="'+id+'" style="cursor:'+(n.kids.length?'pointer':'default')+'"><title>'+esc(n.label+(n.sub?' · '+n.sub:''))+'</title>'+
  '<rect x="'+p.x+'" y="'+p.y+'" width="'+W+'" height="'+H+'" rx="6" fill="'+(hot?'#FFF1DB':'#fff')+'" stroke="'+(hot?'#C77700':k[1])+'" stroke-width="'+(hot?2.2:1.4)+'"/>'+
  '<rect x="'+p.x+'" y="'+p.y+'" width="4" height="'+H+'" rx="2" fill="'+k[1]+'"/>'+
  '<text x="'+(p.x+10)+'" y="'+(p.y+17)+'" font-size="10.5" font-weight="700" fill="#1E2A36">'+esc(tr(n.label,19))+'</text>'+
  '<text x="'+(p.x+10)+'" y="'+(p.y+32)+'" font-size="9.5" fill="#5F6F7E">'+esc(tr(n.sub||'',25))+'</text>'+
  (n.sf?'<circle cx="'+(p.x+W-8)+'" cy="'+(p.y+8)+'" r="3.5" fill="#1E8E5A"><title>Found in Snowflake</title></circle>':'')+
  (more?'<text x="'+(p.x+W-8)+'" y="'+(p.y+31)+'" font-size="10" font-weight="700" fill="#0070AD" text-anchor="end">+'+more+'</text>':'')+'</g>'});
 s+='</svg>';document.getElementById('box').innerHTML=s;
 document.querySelectorAll('#box g[data-id]').forEach(g=>g.onclick=()=>{const id=g.dataset.id;if(!N[id].kids.length)return;
  if(EXP.has(id)){EXP.delete(id)}else{EXP.add(id)}render()})}
document.getElementById('ex').onclick=()=>{D.nodes.forEach(n=>{if(n.kids.length)EXP.add(n.id)});render()};
document.getElementById('co').onclick=()=>{EXP.clear();EXP.add('proc');render()};
render();
</script></body></html>"""


st.set_page_config(page_title="Knowledge Co-Worker · AP", layout="wide")
session = get_active_session()

# ------------------------------------------------------------------ look and feel (v3 palette)
st.markdown("""
<style>
:root{--blue:#0070AD;--dk:#12ABDB;--navy:#0B2A4A;--bg:#F4F7FA;--line:#D9E1E8;--txt:#1E2A36;--mut:#5F6F7E;
      --ok:#1E8E5A;--warn:#C77700;--bad:#B3261E}
.block-container{padding-top:.8rem;max-width:1700px}
.kc-head{background:var(--navy);color:#fff;border-radius:10px;padding:12px 18px;display:flex;justify-content:space-between;
         align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:.5rem}
.kc-head h1{margin:0;font-size:1.15rem;font-weight:700;color:#fff;padding:0}.kc-head small{color:#9FC4E0;font-weight:400}
.kc-head .who{font-size:.8rem;color:#CFE3F3}
.kc-chips{display:flex;flex-wrap:wrap;gap:6px;align-items:center;justify-content:flex-end;padding-top:.35rem}
.kc-chips .lbl{color:var(--mut);font-size:.78rem;margin-right:2px}
.kc-src{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--line);background:#fff;border-radius:999px;
        padding:1px 9px;font-size:.72rem;color:var(--txt);white-space:nowrap}
.kc-src i{width:8px;height:8px;border-radius:50%;display:inline-block;background:#9AA9B8}
.kc-src.Connected i,.kc-src.Loaded i{background:var(--ok)}.kc-src.Sample i{background:var(--warn)}
.kc-h{font-size:.74rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--mut);margin:.35rem 0 .35rem}
.kc-t{font-size:1rem;font-weight:700;color:var(--navy);margin:0 0 .2rem}
.kc-note{font-size:.78rem;color:var(--mut)}
.kc-banner{display:inline-block;background:#FFF4E0;color:var(--warn);border:1px solid #F5D49A;border-radius:6px;padding:2px 10px;font-size:.78rem}
.tag{display:inline-block;font-size:.72rem;border-radius:10px;padding:0 8px;margin:0 4px 3px 0;border:1px solid transparent}
.tag.sf{background:#E6F4FB;color:#0070AD;border-color:#B6DDF2}.tag.xls{background:#DDF3E8;color:#1E8E5A;border-color:#A7DFC2}
.tag.doc{background:#E9E5FB;color:#5B3FC4;border-color:#CFC6F5}.tag.glo{background:#FFEBCC;color:#C77700;border-color:#F5D49A}
.tag.pdf{background:#EEF1F4;color:#44515E;border-color:#D9E1E8}.tag.apv{background:#DDF3E8;color:#1E8E5A;border-color:#A7DFC2}
.tag.ok{background:#DDF3E8;color:var(--ok)}.tag.dr{background:#FFEBCC;color:var(--warn)}.tag.no{background:#FBE0DE;color:var(--bad)}
.tag.gr{background:#EEF1F4;color:#44515E}
.kc-steps{display:flex;gap:6px;align-items:stretch;flex-wrap:nowrap}
.kc-step{flex:1 1 0;min-width:0;border:1px solid var(--line);border-top:4px solid var(--blue);border-radius:8px;
         background:#F8FAFC;padding:8px 10px;font-size:.78rem}
.kc-step.gap{border-top-color:var(--bad);background:#FDF0EF}
.kc-step b{display:block;font-size:.86rem;color:var(--txt);margin-bottom:3px}
.kc-step .o{font-family:ui-monospace,Menlo,monospace;font-size:.72rem;color:#44515E;word-break:break-word}
.kc-step .sfo{color:var(--ok)}
.kc-arrow{align-self:center;color:#9AA9B8}
.kc-card{border:1px solid var(--line);border-radius:8px;padding:.55rem .75rem;background:#fff;margin-bottom:.35rem;font-size:.84rem}
.kc-card .m{font-family:ui-monospace,Menlo,monospace;font-size:.78rem;word-break:break-word}
.kc-card.hl{border-left:4px solid var(--warn);background:#FFF8EC}
.kc-hop{text-align:center;color:#9AA9B8;font-size:.75rem;line-height:1;margin:-.1rem 0 .25rem}
.kc-hops{display:flex;gap:6px;align-items:stretch;margin:.4rem 0}
.kc-hopcard{flex:1 1 0;min-width:0;border:1px solid var(--line);border-left:4px solid var(--blue);border-radius:6px;padding:8px 10px;
            background:#fff;font-size:.76rem;overflow-wrap:anywhere}
.kc-hopcard.hl{border-left-color:var(--warn);background:#FFF8EC}
.kc-hopcard .h{font-size:.68rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--mut);margin-bottom:4px}
.kc-hopcard code{display:inline-block;max-width:100%;white-space:normal;word-break:break-all;font-size:.72rem;background:#EEF3F8;color:#1E2A36;border-radius:3px;padding:0 4px;margin:0 3px 3px 0}
.kc-arr{align-self:center;color:#5F6F7E;font-size:.8rem}
.kc-greet{background:#EEF3F8;border-radius:8px;padding:.7rem .9rem;font-size:.9rem;color:var(--txt)}
.ex h2{font-size:1.05rem;margin:1rem 0 .6rem;color:var(--navy)}
.ex .kpis{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin-bottom:14px}
.ex .kpi{background:#fff;border:1px solid var(--line);border-top:4px solid var(--blue);border-radius:8px;padding:10px 12px}
.ex .kpi b{display:block;font-size:1.6rem;color:var(--navy);line-height:1.15}.ex .kpi span{font-size:.76rem;color:var(--mut)}
.ex .kpi.g{border-top-color:var(--ok)}.ex .kpi.w{border-top-color:var(--warn)}.ex .kpi.r{border-top-color:var(--bad)}
.ex .card{background:#fff;border:1px solid var(--line);border-radius:8px;padding:12px 14px}
.ex .card h3{margin:0 0 8px;font-size:.86rem;color:var(--navy);font-weight:700;padding:0}
.ex .grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-top:14px}
.ex .flow{display:flex;align-items:center;gap:6px;margin:6px 0}
.ex .flow div{flex:1;background:#EEF3F8;border-radius:6px;padding:8px;text-align:center;font-size:.78rem;color:var(--txt)}
.ex .flow div b{display:block;font-size:1.2rem;color:var(--navy)}.ex .flow s{text-decoration:none;color:#5F6F7E}
.ex .hb{display:flex;align-items:center;gap:8px;margin:5px 0;font-size:.78rem}
.ex .hb label{width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--txt)}
.ex .hb .tr{flex:1;background:#E5ECF2;border-radius:4px;height:13px}.ex .hb .tr i{display:block;height:100%;border-radius:4px;background:var(--blue)}
.ex .hb em{width:40px;font-style:normal;color:var(--mut);text-align:right}
.ex .leg{font-size:.8rem;margin:4px 0;color:var(--txt)}.ex .leg i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:6px}
.ex ul{margin:0;padding-left:18px;font-size:.8rem;color:var(--txt)}.ex li{margin:3px 0}
.ex .dec{background:#FFF8E1;border-color:#F0D58A}
.ex table{width:100%;font-size:.8rem;border-collapse:collapse}.ex td{padding:3px 4px 3px 0;vertical-align:top;border:0;color:var(--txt)}
.ex .mini{display:grid;grid-template-columns:1fr auto;gap:4px 12px;font-size:.8rem}.ex .mini b{color:var(--navy)}
div[data-testid="stButton"] button{border-radius:7px}
button[kind="primary"],[data-testid="stBaseButton-primary"]{background:var(--blue)!important;border-color:var(--blue)!important;color:#fff!important}
button[kind="primary"]:hover,[data-testid="stBaseButton-primary"]:hover{background:var(--dk)!important;border-color:var(--dk)!important}
button[data-baseweb="tab"][aria-selected="true"] p{color:var(--blue)!important;font-weight:600}
div[data-baseweb="tab-highlight"]{background-color:var(--blue)!important}
div[role="radiogroup"]{gap:.4rem;flex-wrap:wrap}
div[role="radiogroup"] label[data-baseweb="radio"],[data-testid="stRadioOption"]{border:1px solid var(--line);border-radius:999px;
  padding:.18rem .85rem;background:#fff;margin-right:.3rem;white-space:nowrap}
div[role="radiogroup"] label[data-baseweb="radio"] > div:first-child,[data-testid="stRadioOption"] > div > div:first-child{display:none}
div[role="radiogroup"] label[data-baseweb="radio"]:has(input:checked),[data-testid="stRadioOption"][data-selected="true"]{
  background:var(--navy);border-color:var(--navy)}
div[role="radiogroup"] label[data-baseweb="radio"]:has(input:checked) p,[data-testid="stRadioOption"][data-selected="true"] p{
  color:#fff!important;font-weight:600}
div[role="radiogroup"] p{font-weight:600;color:#44515E}
.st-key-kc_questions div[data-testid="stButton"] button{justify-content:flex-start;text-align:left;border-color:#9CC9E6;color:var(--blue)}
.st-key-kc_questions div[data-testid="stButton"] button p{text-align:left;font-size:.84rem}
.st-key-kc_questions div[data-testid="stButton"] button:hover{background:#EEF6FB}
</style>""", unsafe_allow_html=True)


# ------------------------------------------------------------------ data access
def q(sql, params=None):
    return (session.sql(sql, params=params) if params else session.sql(sql)).to_pandas()


def run(sql, params=None):
    return (session.sql(sql, params=params) if params else session.sql(sql)).collect()


def box(key=None, **kw):
    """Bordered container; the key (CSS hook) is used only where the Streamlit version supports it."""
    for args in ({"border": True, "key": key, **kw}, {"border": True, **kw}, {}):
        try:
            return st.container(**args)
        except TypeError:
            continue


def esc(v):
    return html.escape("" if v is None or (isinstance(v, float) and pd.isna(v)) else str(v))


def tag(text, cls):
    return f'<span class="tag {cls}">{esc(text)}</span>'


def src_tags(names):
    return "".join(tag(n, SRC_CLASS.get(n, "gr")) for n in names)


@st.cache_resource
def ensure_tables():
    run(f"""CREATE TABLE IF NOT EXISTS {KF}.KF_QUESTION_LOG (
        QUESTION VARCHAR, ASKED_BY VARCHAR, APP_ROLE VARCHAR, ASKED_AT TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP())
        COMMENT = 'Questions asked in the app (recent questions and usage counts)'""")
    run(f"""CREATE TABLE IF NOT EXISTS {KF}.KF_DESCRIPTION_APPROVALS (
        MODEL_NAME VARCHAR, FIELD_NAME VARCHAR, SUGGESTED_TEXT VARCHAR, FINAL_TEXT VARCHAR,
        STATUS VARCHAR COMMENT 'Draft, Approved or Rejected', EVIDENCE VARCHAR,
        SUGGESTED_BY VARCHAR, SUGGESTED_AT TIMESTAMP_LTZ, DECIDED_BY VARCHAR, DECIDED_AT TIMESTAMP_LTZ)
        COMMENT = 'Draft & Approve: AI-suggested business descriptions and the business owner decision'""")
    for col in ["BUSINESS_NAME VARCHAR", "CONFIDENCE VARCHAR", "BASIS VARCHAR", "PROFILE VARCHAR"]:
        try:
            run(f"ALTER TABLE {KF}.KF_DESCRIPTION_APPROVALS ADD COLUMN IF NOT EXISTS {col}")
        except Exception:
            pass
    return True


ensure_tables()


@st.cache_data(ttl=300)
def load(view, order=""):
    """One Knowledge Fabric view as a DataFrame (empty if the view is missing: 07d not run yet)."""
    try:
        return q(f"SELECT * FROM {KF}.{view} {order}")
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=600)
def sf_tables():
    try:
        df = q(f"SELECT TABLE_SCHEMA, TABLE_NAME FROM {DB}.INFORMATION_SCHEMA.TABLES")
        return set(df["TABLE_SCHEMA"] + "." + df["TABLE_NAME"]), set(df["TABLE_NAME"])
    except Exception:
        return set(), set()


@st.cache_data(ttl=600)
def fields():
    return q(f"""SELECT SHEET, SHEET_ROW, LAYER, SCHEMA_NAME, MODEL_NAME, FIELD_NAME, BUSINESS_NAME, DEFINITION,
                        SOURCE_SYSTEM, SOURCE_EDW_TABLE, SOURCE_TABLE, SOURCE_FIELD, MAPPING
                 FROM {KF}.KF_EXCEL_MAPPING_SHEET ORDER BY SHEET, SHEET_ROW""").fillna("")


APV_COLS = ["MODEL_NAME", "FIELD_NAME", "BUSINESS_NAME", "SUGGESTED_TEXT", "FINAL_TEXT", "STATUS", "CONFIDENCE", "BASIS",
            "PROFILE", "EVIDENCE", "SUGGESTED_BY", "DECIDED_BY", "DECIDED_AT"]


def approvals():
    try:
        df = q(f"SELECT {', '.join(APV_COLS)} FROM {KF}.KF_DESCRIPTION_APPROVALS WHERE MODEL_NAME = '{DM}'")
        df["DECIDED_AT"] = df["DECIDED_AT"].astype(str)
        return df.fillna("")
    except Exception:
        return pd.DataFrame(columns=APV_COLS)


def recent_questions(n=6):
    try:
        df = q(f"""SELECT QUESTION, MAX(ASKED_AT) AS LAST_ASKED, COUNT(*) AS N FROM {KF}.KF_QUESTION_LOG
                   WHERE QUESTION IS NOT NULL AND QUESTION <> '' GROUP BY QUESTION ORDER BY LAST_ASKED DESC LIMIT {n}""")
        return list(zip(df["QUESTION"], df["N"]))
    except Exception:
        return []


def refresh_data():
    st.cache_data.clear()


@st.cache_data(ttl=3600)
def snowflake_identity():
    """Viewer and the Snowflake roles granted to them (falls back quietly where the account does not allow it)."""
    user = ""
    try:   # st.user on newer Streamlit; st.experimental_user only where st.user does not exist (avoids a deprecation banner)
        u = st.user if hasattr(st, "user") else st.experimental_user
        user = u.get("user_name") or u.get("login_name") or ""
    except Exception:
        user = ""
    if not user:
        try:
            user = run("SELECT CURRENT_USER() AS U")[0]["U"] or ""
        except Exception:
            user = ""
    roles = []
    if user:
        try:
            roles = [str(r["role"]) for r in run(f'SHOW GRANTS TO USER "{user}"')]
        except Exception:
            roles = []
    return user, roles


# ------------------------------------------------------------------ agent
def walk(obj, found):
    """Collect tool names, SQL and cited titles from the agent response."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == "name" and isinstance(v, str) and v in TOOL_SOURCES:
                found["tools"].add(v)
            elif k == "sql" and isinstance(v, str) and v.strip():
                found["sql"].append(v.strip())
            elif k in ("DOC_TITLE", "doc_title") and isinstance(v, str):
                found["docs"].add(v)
            elif k in ("DOC_TYPE", "doc_type") and isinstance(v, str) and "Word" in v:
                found["word"] = True
            walk(v, found)
    elif isinstance(obj, list):
        for v in obj:
            walk(v, found)


def call_agent(messages):
    raw = run("SELECT SNOWFLAKE.CORTEX.DATA_AGENT_RUN(?, ?) AS R", [AGENT, json.dumps({"messages": messages})])[0]["R"]
    resp = json.loads(raw)
    texts = [c.get("text", "") for c in resp.get("content", []) if c.get("type") == "text"]
    found = {"tools": set(), "sql": [], "docs": set(), "word": False}
    walk(resp.get("content", []), found)
    return "\n\n".join(t for t in texts if t) or "_The co-worker returned no text._", found


def sources_used(answer, found):
    used = []
    for t in sorted(found["tools"]):
        for s in TOOL_SOURCES[t]:
            if s not in used:
                used.append(s)
    if found.get("word") and "Uploaded Word Document" not in used:
        used.append("Uploaded Word Document")
    tail = answer.split("Sources:")[-1].lower() if "Sources:" in answer else ""
    for word, s in [("snowflake", "Snowflake Metadata"), ("excel", "Uploaded Excel"), ("mapping sheet", "Uploaded Excel"),
                    ("workbook", "Uploaded Excel"), ("word", "Uploaded Word Document"), ("glossary", "Business Glossary")]:
        if word in tail and s not in used:
            used.append(s)
    return used


def ask_agent(question):
    current = {"role": "user", "content": [{"type": "text", "text": question}]}
    history = [{"role": m["role"], "content": [{"type": "text", "text": m["text"]}]} for m in st.session_state.messages[-4:]]
    found = {"tools": set(), "sql": [], "docs": set(), "word": False}
    try:
        answer, found = call_agent(history + [current])
    except Exception:
        try:
            answer, found = call_agent([current])
        except Exception as error:
            answer = f"_The co-worker could not answer: {str(error)[:300]}_"
    try:
        run(f"INSERT INTO {KF}.KF_QUESTION_LOG (QUESTION, ASKED_BY, APP_ROLE) VALUES (?, CURRENT_USER(), ?)",
            [question, st.session_state.role])
    except Exception:
        pass
    st.session_state.evidence = {"question": question, "sources": sources_used(answer, found),
                                 "tools": sorted(found["tools"]), "sql": found["sql"][:4], "docs": sorted(found["docs"])}
    return answer


# ------------------------------------------------------------------ Draft & Approve helpers (unchanged logic)
def parse_ai_json(raw):
    """AI_COMPLETE may return the JSON as an encoded string and inside ```json fences: unwrap both."""
    text = raw if isinstance(raw, str) else str(raw)
    for _ in range(2):
        t = text.strip()
        if t.startswith('"') and t.endswith('"'):
            try:
                text = json.loads(t)
                continue
            except Exception:
                pass
        break
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    match = re.search(r"\{.*\}", text, re.S)
    if match:
        try:
            return json.loads(match.group(0)), text
        except Exception:
            pass
    return {}, text


def profile(col):
    """Data profile of one data mart column (numbers compared as numbers; masked columns are not sampled)."""
    t = f"{DB}.{DATAMART}.{DM}"
    p = run(f"""SELECT COUNT(*) AS N, COUNT_IF({col} IS NULL) AS NULLS, COUNT(DISTINCT {col}) AS D,
                       MIN({col})::VARCHAR AS MINV, MAX({col})::VARCHAR AS MAXV,
                       COUNT(TRY_TO_DOUBLE({col}::VARCHAR)) AS NUMS,
                       MIN(TRY_TO_DOUBLE({col}::VARCHAR)) AS NMIN, MAX(TRY_TO_DOUBLE({col}::VARCHAR)) AS NMAX
                FROM {t}""")[0]
    filled = p["N"] - p["NULLS"]
    numeric = filled > 0 and p["NUMS"] == filled
    lo, hi = (f"{p['NMIN']:g}", f"{p['NMAX']:g}") if numeric else (p["MINV"], p["MAXV"])
    masked = q(f"SELECT COUNT_IF(IS_MASKED) AS M FROM {KF}.KF_COLUMNS WHERE OBJECT_NAME = ? AND COLUMN_NAME = ?", [DM, col])
    is_masked = len(masked) > 0 and pd.notna(masked.iloc[0]["M"]) and int(masked.iloc[0]["M"]) > 0
    top = [] if is_masked else [(r["V"], r["C"]) for r in run(
        f"SELECT {col}::VARCHAR AS V, COUNT(*) AS C FROM {t} WHERE {col} IS NOT NULL GROUP BY 1 ORDER BY 2 DESC LIMIT 6")]
    return {"rows": p["N"], "empty_pct": round(100 * p["NULLS"] / max(p["N"], 1), 1), "distinct": p["D"],
            "min": lo, "max": hi, "numeric": numeric, "top": top, "masked": is_masked}


def profile_text(pr):
    s = (f"{pr['rows']} rows, {pr['empty_pct']}% empty, {pr['distinct']} distinct values, "
         f"{'numeric ' if pr['numeric'] else ''}range {pr['min']} to {pr['max']}")
    if pr["top"]:
        s += "; most frequent: " + ", ".join(f"{v} ({c})" for v, c in pr["top"])
    elif pr["masked"]:
        s += "; values masked, not sampled"
    return s


STEWARD_PROMPT = """You are a senior finance data steward writing the business data dictionary for an Accounts Payable data mart.
Your reader is a finance user (controller, AP manager), not an engineer.

Write for the column below:
- business_name: 2 to 5 words, Title Case, plain business wording (standard abbreviations such as AP, USD, GL are fine).
- description: 1 or 2 sentences, at most 40 words. Start with what the field represents (for example "Number of days...",
  "Aging band of...", "Name of..."). Mention the unit or currency for amounts and days, and the allowed values when the data
  shows a small fixed set. If many values are empty and the rule explains why, say when it is filled (for example
  "Empty for paid items."). No SQL, no technical column names, nothing that is not supported by the facts below.
- confidence: High (rule, source definition and data agree), Medium (rule or data only), Low (name only or conflicting facts).
- basis: one short sentence for the approver explaining what the draft is based on.

Reply with JSON only: {"business_name": "...", "description": "...", "confidence": "High|Medium|Low", "basis": "..."}

Table: AP global details data mart (one row per AP line item, open and paid; amounts in USD at month-end rate).
Column: <<COL>>
Business entity: <<ENTITY>>
Source EDW table / view: <<SRC_TBL>>
Source field: <<SRC_FLD>>
Mapping rule: <<RULE>>
Source field business definition: <<SRC_DEF>>
Data profile: <<PROFILE>>"""


def draft_description(col, row, src_def, entity):
    pr = profile(col)
    prompt = (STEWARD_PROMPT.replace("<<COL>>", col).replace("<<ENTITY>>", entity or "-")
              .replace("<<SRC_TBL>>", row.get("SOURCE_EDW_TABLE") or "-").replace("<<SRC_FLD>>", row.get("SOURCE_FIELD") or "-")
              .replace("<<RULE>>", row.get("MAPPING") or "-").replace("<<SRC_DEF>>", src_def)
              .replace("<<PROFILE>>", profile_text(pr)))
    raw = run("SELECT AI_COMPLETE(?, ?) AS T", [AI_MODEL, prompt])[0]["T"]
    d, text = parse_ai_json(raw)
    conf = d.get("confidence") if d.get("confidence") in ("High", "Medium", "Low") else "Medium"
    return {"name": (d.get("business_name") or col.replace("_", " ").title()).strip(),
            "text": (d.get("description") or text).strip().strip('"'),
            "confidence": conf, "basis": (d.get("basis") or "").strip(), "profile": pr}


# ------------------------------------------------------------------ exports
def xlsx_bytes(sheets):
    """Minimal .xlsx writer (no extra packages): sheets = [(name, header, rows)]; bold frozen header, filter."""
    def col(n):
        s = ""
        n += 1
        while n:
            n, r = divmod(n - 1, 26)
            s = chr(65 + r) + s
        return s

    def cell(ref, v, style):
        if v is None or (isinstance(v, float) and pd.isna(v)):
            return ""
        if isinstance(v, bool):
            v = "Yes" if v else "No"
        if isinstance(v, (int, float)):
            return f'<c r="{ref}" s="{style}"><v>{v}</v></c>'
        t = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v))
        return f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{html.escape(t, quote=False)}</t></is></c>'

    z = io.BytesIO()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as f:
        names = [re.sub(r"[\[\]:*?/\\]", " ", s[0])[:31] for s in sheets]
        f.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                             for i in range(len(sheets))) + '</Types>')
        f.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        f.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + "".join(f'<sheet name="{html.escape(n)}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, n in enumerate(names))
                   + '</sheets></workbook>')
        f.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>'
                             for i in range(len(sheets)))
                   + f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        f.writestr("xl/styles.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<fonts count="2"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font></fonts>'
                   '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
                   '<fill><patternFill patternType="solid"><fgColor rgb="FF0B2A4A"/><bgColor indexed="64"/></patternFill></fill></fills>'
                   '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                   '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                   '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
                   '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>'
                   '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
        for i, (_, header, rows) in enumerate(sheets):
            widths = [min(max(len(str(h)), *(len(str(r[j])) for r in rows[:200]), 8) + 2, 60) if rows else max(len(str(h)) + 2, 10)
                      for j, h in enumerate(header)]
            xml = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                   '<cols>' + "".join(f'<col min="{j + 1}" max="{j + 1}" width="{w}" customWidth="1"/>' for j, w in enumerate(widths)) + '</cols><sheetData>']
            for r, values in enumerate([header] + [list(x) for x in rows]):
                xml.append(f'<row r="{r + 1}">' + "".join(cell(f"{col(c)}{r + 1}", v, 1 if r == 0 else 0)
                                                         for c, v in enumerate(values)) + '</row>')
            xml.append('</sheetData>')
            if header:
                xml.append(f'<autoFilter ref="A1:{col(len(header) - 1)}{len(rows) + 1}"/>')
            xml.append('</worksheet>')
            f.writestr(f"xl/worksheets/sheet{i + 1}.xml", "".join(xml))
    return z.getvalue()


def report_meta(title, used, n):
    status = {r["SOURCE_NAME"]: r["SOURCE_STATUS"] for _, r in sources_df.iterrows()} if len(sources_df) else {}
    return [("Report", title), ("Generated", datetime.now().strftime("%Y-%m-%d %H:%M")), ("Domain", "Accounts Payable (live)"),
            ("Rows", str(n)), ("Metadata sources", "; ".join(f"{s} ({status.get(s, '?')})" for s in used)),
            ("Status", "Draft for review. Synthetic POC data. Column lineage is traced from the mapping workbook and checked against "
                       "Snowflake; the glossary and Word narrative are samples until the customer versions are loaded.")]


def report_html(title, meta, df):
    head = "".join(f"<th>{esc(c)}</th>" for c in df.columns)
    body = "".join("<tr>" + "".join(f"<td>{esc(v)}</td>" for v in row) + "</tr>" for row in df.itertuples(index=False))
    metas = "".join(f"<tr><th>{esc(k)}</th><td>{esc(v)}</td></tr>" for k, v in meta)
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{esc(title)}</title><style>
@page{{size:A4 landscape;margin:10mm}}body{{font:10px/1.35 Arial,sans-serif;color:#1E2A36;margin:18px}}
h1{{font-size:16px;color:#0B2A4A;margin:0 0 8px}}table{{border-collapse:collapse;width:100%}}
td,th{{border:1px solid #D9E1E8;padding:3px 5px;text-align:left;vertical-align:top}}
.data th{{background:#0B2A4A;color:#fff}}.meta{{width:auto;margin-bottom:12px}}.meta th{{background:#F4F7FA;width:140px}}
button{{background:#0070AD;color:#fff;border:0;border-radius:6px;padding:8px 14px;margin-bottom:12px;cursor:pointer}}
@media print{{button{{display:none}}.data thead{{display:table-header-group}}}}</style></head><body>
<button onclick="window.print()">Print / Save as PDF</button><h1>{esc(title)}</h1>
<table class="meta">{metas}</table><table class="data"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>
</body></html>""".encode("utf-8")


# ------------------------------------------------------------------ Word upload
def read_docx(data):
    """Paragraph text of a .docx (no extra packages)."""
    z = zipfile.ZipFile(io.BytesIO(data))
    xml = z.read("word/document.xml").decode("utf-8", "ignore")
    paras = []
    for p in re.findall(r"<w:p[ >].*?</w:p>", xml, re.S):
        text = html.unescape("".join(re.findall(r"<w:t(?: [^>]*)?>(.*?)</w:t>", p, re.S))).strip()
        if text:
            paras.append(re.sub(r"\s+", " ", text))
    title = ""
    try:
        core = z.read("docProps/core.xml").decode("utf-8", "ignore")
        m = re.search(r"<dc:title>(.*?)</dc:title>", core, re.S)
        title = html.unescape(m.group(1)).strip() if m else ""
    except KeyError:
        pass
    return title, paras


def save_word(file_name, data):
    title, paras = read_docx(data)
    if not paras:
        raise ValueError("No text paragraphs found in the document.")
    title = title or (paras[0] if len(paras[0]) <= 80 else file_name.rsplit(".", 1)[0])
    doc_id = "DOC_" + hashlib.md5((file_name + str(len(data)) + datetime.now().isoformat()).encode()).hexdigest()[:12].upper()
    run(f"""INSERT INTO {KF}.KF_UPLOADED_DOCUMENTS (DOC_ID, FILE_NAME, DOC_TITLE, DOC_KIND, IS_SAMPLE, PARAGRAPHS,
            UPLOADED_BY, UPLOADED_AT, DOC_STATUS) SELECT ?, ?, ?, 'Word', FALSE, ?, CURRENT_USER(), CURRENT_TIMESTAMP(), 'Loaded'""",
        [doc_id, file_name, title, len(paras)])
    para_df = pd.DataFrame({"DOC_ID": doc_id, "PARA_NO": range(1, len(paras) + 1), "PARA_TEXT": paras, "ENTITY_HINT": None})
    session.write_pandas(para_df, "KF_UPLOADED_DOC_PARAGRAPHS", database=DB, schema=KF_SCHEMA, auto_create_table=False)
    searchable = True
    try:
        run(f"""INSERT INTO {KF}.KF_DOC_CHUNKS (CHUNK_ID, FILE_NAME, DOC_TITLE, DOC_TYPE, DOC_VERSION, DOC_STATUS, PAGE_NUMBER,
                CHUNK_TEXT, SEARCH_TEXT)
                SELECT ? || '#para-' || p.PARA_NO, ?, ?, 'Uploaded Word Document', '1', 'Loaded', 1, p.PARA_TEXT,
                       ? || ' (Uploaded Word Document, paragraph ' || p.PARA_NO || ')\\n' || p.PARA_TEXT
                FROM {KF}.KF_UPLOADED_DOC_PARAGRAPHS p WHERE p.DOC_ID = ?""", [file_name, file_name, title, title, doc_id])
        run(f"ALTER CORTEX SEARCH SERVICE {KF}.{DOCS_SEARCH} REFRESH")
    except Exception:
        searchable = False
    return title, len(paras), searchable


# ------------------------------------------------------------------ payloads for the graphs
def ontology_payload(selected):
    objs = ent_objects_df
    narr = narrative_df
    out = []
    for _, e in entities_df.iterrows():
        o = objs[objs["ENTITY_ID"] == e["ENTITY_ID"]] if len(objs) else objs
        n = narr[narr["ENTITY_ID"] == e["ENTITY_ID"]].sort_values(["IS_SAMPLE", "PARA_NO"]) if len(narr) else narr
        out.append({"id": e["ENTITY_ID"], "n": e["ENTITY_NAME"], "t": e["ENTITY_TYPE"], "ab": e["ABBREVIATION"],
                    "doms": str(e["DOMAINS"]).split(","), "status": e["ENTITY_STATUS"], "x": float(e["GRAPH_X"]),
                    "y": float(e["GRAPH_Y"]), "def": e["BUSINESS_DEFINITION"], "ds": e["DEFINITION_STATUS"],
                    "owner": e["OWNER_ROLE"], "shared": bool(e["IS_SHARED"]), "syn": e["SYNONYMS"] or "",
                    "wb": int((o["EVIDENCE"] == "Uploaded Excel").sum()) if len(o) else 0,
                    "sf": int(o["IN_SNOWFLAKE"].fillna(False).astype(bool).sum()) if len(o) else 0,
                    "narr": n.iloc[0]["PARA_TEXT"] if len(n) else "", "narrsrc": n.iloc[0]["DOC_TITLE"] if len(n) else "",
                    "objs": [{"name": r["OBJECT_NAME"], "role": r["OBJECT_ROLE"], "friendly": r["FRIENDLY_NAME"],
                              "sf": bool(r["IN_SNOWFLAKE"]) if pd.notna(r["IN_SNOWFLAKE"]) else False} for _, r in o.iterrows()]})
    rels = [{"a": r["FROM_ENTITY"], "b": r["TO_ENTITY"], "l": r["RELATIONSHIP"], "style": r["LINE_STYLE"],
             "detail": r["EVIDENCE_DETAIL"], "status": r["EVIDENCE_STATUS"]} for _, r in rels_df.iterrows()]
    doms = [{"id": d["DOMAIN_ID"], "n": d["DOMAIN_NAME"], "status": d["DOMAIN_STATUS"]} for _, d in domains_df.iterrows()]
    return json.dumps({"entities": out, "rels": rels, "domains": doms, "dn": {d["id"]: d["n"] for d in doms},
                       "domain": "ap", "selected": selected or ""})


def split_objects(text, sep=r"[&]"):
    return [t.strip().split(".")[-1] for t in re.split(sep, text or "") if t.strip()]


def lineage_payload(field):
    full, names = sf_tables()
    dm_rows = prov_df[prov_df["MODEL_NAME"] == DM]
    fact_rows = prov_df[prov_df["MODEL_NAME"] == FACT]
    nodes, edges = {}, []

    def add(i, label, sub, kind, d, sf=False):
        nodes.setdefault(i, {"id": i, "label": label, "sub": sub, "kind": kind, "d": d, "sf": bool(sf)})

    add("proc", "Accounts Payable process", "Procure-to-Pay › Accounts Payable", "process", 0)
    for v in VIEWS:
        add("v:" + v, v, FRIENDLY.get(v, "Reporting view"), "view", 1, f"{REPORTING}.{v}" in full)
        edges.append({"a": "proc", "b": "v:" + v, "l": ""})
        edges.append({"a": "v:" + v, "b": "dm", "l": "reads"})
    add("dm", DM, f"{len(dm_rows)} columns · AP global details", "mart", 2, f"{DATAMART}.{DM}" in full)
    counts = {}
    for _, r in dm_rows.iterrows():
        for t in split_objects(r["SOURCE_EDW_TABLE"]) or ["Unspecified"]:
            counts[t] = counts.get(t, 0) + 1
    for t, n in sorted(counts.items(), key=lambda x: -x[1]):
        kind = "calc" if t == "Calculated" else "fact" if t.startswith("FACT_") else "master"
        add("e:" + t, t, f"{FRIENDLY.get(t, 'EDW source')} · {n} cols", kind, 3, t in names)
        edges.append({"a": "dm", "b": "e:" + t, "l": f"{n} cols"})
    sap = {}
    for _, r in fact_rows.iterrows():
        for t in re.split(r"[\s,;/&]+", str(r["SOURCE_TABLE"] or "")):
            if re.fullmatch(r"[A-Z][A-Z0-9_]{2,}", t) and t not in ("EDW", FACT):
                sap[t] = sap.get(t, 0) + 1
    for t, n in sorted(sap.items(), key=lambda x: -x[1]):
        base = re.match(r"(XREF_|TV_|DIM_|VW_|FACT_|YFIT_)", t) is not None      # EDW / reference objects, not SAP tables
        add("s:" + t, t, f"{FRIENDLY.get(t, 'Reference table' if base else 'SAP table')} · {n} fields", "master" if base else "sap", 4,
            f"SAP_{t}" in names or t in names)
        edges.append({"a": "e:" + FACT, "b": "s:" + t, "l": f"{n} fields"})
    hl, expanded = set(), {"proc"}
    if field:
        rec_dm = dm_rows[dm_rows["FIELD_NAME"] == field]
        rec_fact = fact_rows[fact_rows["FIELD_NAME"] == field]
        if len(rec_dm):
            r = rec_dm.iloc[0]
            hl |= {"proc", "dm"} | {"v:" + v for v in views_for(field)}
            hl |= {"e:" + t for t in split_objects(r["SOURCE_EDW_TABLE"]) or ["Unspecified"]}
            fact_field = r["FACT_FIELD"] if pd.notna(r["FACT_FIELD"]) else None
            if fact_field:
                rec_fact = fact_rows[fact_rows["FIELD_NAME"] == fact_field]
        if len(rec_fact):
            hl |= {"e:" + FACT} | {"s:" + t for t in re.split(r"[\s,;/&]+", str(rec_fact.iloc[0]["SOURCE_TABLE"] or "")) if t}
            if not len(rec_dm):
                users = dm_rows[dm_rows["FACT_FIELD"] == field]
                if len(users):
                    hl |= {"proc", "dm"} | {"v:" + v for v in VIEWS}
        hl = {h for h in hl if h in nodes}
        expanded |= {h for h in hl if any(e["a"] == h for e in edges)}
    return json.dumps({"nodes": list(nodes.values()), "edges": edges, "hl": sorted(hl), "expanded": sorted(expanded)})


@st.cache_data(ttl=600)
def view_columns():
    try:
        df = q(f"""SELECT SOURCE_COLUMN, SPLIT_PART(TARGET_OBJECT, '.', 2) AS VIEW_NAME FROM {KF}.KF_FIELD_MAPPING
                   WHERE TARGET_LAYER = 'Reporting' AND SOURCE_OBJECT ILIKE '%{DM}'""")
        return df.groupby("SOURCE_COLUMN")["VIEW_NAME"].apply(lambda s: sorted(set(s))).to_dict()
    except Exception:
        return {}


def views_for(col):
    return view_columns().get(col, [])


# ------------------------------------------------------------------ state
for key, value in {"messages": [], "pending": "", "field": None, "entity": None, "box": 0, "auto": None,
                   "evidence": None}.items():
    st.session_state.setdefault(key, value)


def on_pick(widget, target, clear=True):
    """Selectbox callback: copy the picked value into session state (placeholder = nothing picked)."""
    v = st.session_state.get(widget)
    if v is None or str(v).startswith("Select"):
        if clear:
            st.session_state[target] = None
    else:
        st.session_state[target] = v


def sync(widget, value, options, placeholder):
    """Show the current entity / field in a selectbox without fighting the user's own pick."""
    want = value if value in options else placeholder
    if st.session_state.get(widget) != want:
        st.session_state[widget] = want


def put_question(text, field=None):
    st.session_state.pending = text
    st.session_state.box += 1
    if field:
        st.session_state.field = field


def detect_field(text):
    names = set(prov_df["FIELD_NAME"]) if len(prov_df) else set()
    for token in re.findall(r"[A-Z][A-Z0-9_]{2,}", text.upper()):
        if token in names:
            return token
    return None


def detect_entity(text):
    t = " " + re.sub(r"[^a-z0-9/]+", " ", text.lower()) + " "
    best = None
    for _, e in entities_df.iterrows():
        for s in [e["ENTITY_NAME"].lower()] + str(e["SYNONYMS"] or "").split(","):
            s = s.strip()
            if s and f" {s} " in t and (best is None or len(s) > best[1]):
                best = (e["ENTITY_ID"], len(s))
    return best[0] if best else None


def ent_name(eid):
    row = entities_df[entities_df["ENTITY_ID"] == eid]
    return row.iloc[0]["ENTITY_NAME"] if len(row) else eid


# ------------------------------------------------------------------ load everything once per run
entities_df = load("KF_ONTOLOGY_ENTITIES", "ORDER BY SORT_ORDER")
rels_df = load("KF_ONTOLOGY_RELATIONSHIPS", "ORDER BY REL_ID")
ent_objects_df = load("KF_ENTITY_OBJECTS", "ORDER BY ENTITY_ID, OBJECT_ROLE, OBJECT_NAME")
domains_df = load("KF_DOMAIN", "ORDER BY SORT_ORDER")
process_df = load("KF_PROCESS_COVERAGE", "ORDER BY STEP_NO")
sources_df = load("KF_METADATA_SOURCES", "ORDER BY PRECEDENCE")
prov_df = load("KF_FIELD_PROVENANCE", "ORDER BY SHEET, SHEET_ROW")
narrative_df = load("KF_ENTITY_NARRATIVE", "ORDER BY ENTITY_ID, DOC_ID, PARA_NO")
READY = len(entities_df) > 0 and len(prov_df) > 0

user, sf_roles = snowflake_identity()
if POWER_ROLE in sf_roles:
    role_default, role_from = ENGINEER, POWER_ROLE
elif BUSINESS_ROLE in sf_roles:
    role_default, role_from = OWNER, BUSINESS_ROLE
else:
    role_default, role_from = ENGINEER, ""

# ------------------------------------------------------------------ header
who = (f"Signed in as {esc(user)}" if user else "Snowflake session") + (
    f" · role from Snowflake: {esc(role_from)}" if role_from else " · demo role switch")
st.markdown(f'<div class="kc-head"><h1>Knowledge Co-Worker – AP <small>· Snowflake POC</small></h1>'
            f'<span class="who">{who}</span></div>', unsafe_allow_html=True)

n1, n2, n3 = st.columns([2.35, 3.0, 0.85])
with n1:
    st.session_state.view = st.radio("View", VIEW_NAMES, horizontal=True, label_visibility="collapsed", key="view_radio")
with n2:
    chips = "".join(f'<span class="kc-src {esc(r["SOURCE_STATUS"])}" title="{esc(r["DETAIL"])}"><i></i>'
                    f'{esc(r["SOURCE_NAME"])} · {esc(r["SOURCE_STATUS"])}</span>' for _, r in sources_df.iterrows())
    st.markdown(f'<div class="kc-chips"><span class="lbl">Metadata sources:</span>{chips}</div>', unsafe_allow_html=True)
with n3:
    st.session_state.role = st.selectbox("Role", ROLES, index=ROLES.index(role_default), key="role_select",
                                         label_visibility="collapsed")

if not READY:
    st.error("The ontology and metadata-source objects are not in this database yet. In the notebook run "
             "`run.upgrade_v15()` (or `run.run(['07d_ontology_and_sources.sql'])`), then reload this app.")
    st.stop()

left, mid, right = st.columns([1.0, 2.55, 1.6], gap="medium")

# ------------------------------------------------------------------ questions panel
with left:
    with box("kc_questions"):
        st.markdown('<p class="kc-t">Questions</p><p class="kc-h">Starter questions</p>', unsafe_allow_html=True)
        persona_q = load("KF_PERSONA_QUESTIONS", "ORDER BY PERSONA, SORT_ORDER")
        mine = persona_q[persona_q["PERSONA"] == st.session_state.role]["QUESTION"].tolist() if len(persona_q) else []
        for i, question in enumerate(mine or QUICK[st.session_state.role]):
            if st.button(question, key=f"start_{i}", use_container_width=True):
                st.session_state.auto = question
        if mine:
            with st.expander("Quick questions"):
                for i, question in enumerate(QUICK[st.session_state.role]):
                    if st.button(question, key=f"quick_{i}", use_container_width=True):
                        st.session_state.auto = question
        st.markdown('<p class="kc-h">Recent questions</p>', unsafe_allow_html=True)
        recent = recent_questions()
        if recent:
            for i, (question, n) in enumerate(recent):
                if st.button(f"↻ {question}  ·  {n}", key=f"recent_{i}", use_container_width=True):
                    st.session_state.auto = question
        else:
            st.markdown('<span class="kc-note">Your questions will appear here for reuse.</span>', unsafe_allow_html=True)

        st.divider()
        st.markdown('<p class="kc-t">Build a question</p>', unsafe_allow_html=True)
        src_tables = sorted({t for s in prov_df.loc[prov_df["MODEL_NAME"] == FACT, "SOURCE_TABLE"].fillna("")
                             for t in re.split(r"[\s,;/&]+", s) if re.fullmatch(r"[A-Z][A-Z0-9_]{2,}", t) and t != "EDW"})
        fact_fields = prov_df.loc[prov_df["MODEL_NAME"] == FACT, "FIELD_NAME"].tolist()
        dm_fields = prov_df.loc[prov_df["MODEL_NAME"] == DM, "FIELD_NAME"].tolist()
        kind = st.selectbox("What do you want to know?", ["Select a question type…"] + [a[0] for a in ATTR_LIST], key="bq_kind")
        src_count = {t: int(prov_df.loc[prov_df["MODEL_NAME"] == FACT, "SOURCE_TABLE"].fillna("").str.contains(rf"\b{t}\b").sum())
                     for t in src_tables}
        s_src = st.selectbox("About a source table", [f"Select a source table… ({len(src_tables)})"] + src_tables, key="bq_src",
                             format_func=lambda t: t if t.startswith("Select") else f"{t}  ({src_count.get(t, 0)} fields)")
        s_fact = st.selectbox("About a fact field", [f"Select a fact field… ({len(fact_fields)})"] + fact_fields, key="bq_fact")
        s_dm = st.selectbox("About a data mart column", [f"Select a mart column… ({len(dm_fields)})"] + dm_fields, key="bq_dm")
        picked = ("dm", s_dm) if not s_dm.startswith("Select") else ("fact", s_fact) if not s_fact.startswith("Select") else \
            ("src", s_src) if not s_src.startswith("Select") else ("model", "")
        phrase = {"dm": f"the data mart column {picked[1]}", "fact": f"the fact field {picked[1]}",
                  "src": f"the source table {picked[1]}", "model": "the AP model"}[picked[0]]
        st.markdown(f'<div class="kc-note" style="background:#F4F7FA;border-radius:6px;padding:6px 8px">Applies to: '
                    f'<b>{esc(phrase)}</b>{"" if picked[0] != "model" else " (pick a table, field or column to narrow it)"}</div>',
                    unsafe_allow_html=True)
        if st.button("Put in the Ask box", use_container_width=True, disabled=kind.startswith("Select")):
            template = dict(ATTR_LIST)[kind]
            put_question(template.format(o=phrase), picked[1] if picked[0] in ("dm", "fact") else None)
            st.rerun()

# ------------------------------------------------------------------ middle: the three views
with mid:
    view = st.session_state.view
    if view == "Business ontology":
        components.html(ONTOLOGY_HTML.replace("__DATA__", ontology_payload(st.session_state.entity)), height=660, scrolling=True)
        e_ids = entities_df["ENTITY_ID"].tolist()
        c1, c2 = st.columns([2.2, 1])
        current = st.session_state.entity if st.session_state.entity in e_ids else None
        sync("inspect_entity", current, e_ids, "Select an entity…")
        c1.selectbox("Inspect entity in the side panel", ["Select an entity…"] + e_ids, key="inspect_entity",
                     on_change=on_pick, args=("inspect_entity", "entity"),
                     format_func=lambda x: x if x.startswith("Select") else
                     f"{ent_name(x)} · {entities_df.loc[entities_df.ENTITY_ID == x, 'ENTITY_TYPE'].iloc[0]}")
        if c2.button(f"Ask: which tables hold {ent_name(current) if current else 'it'}?", use_container_width=True,
                     disabled=current is None):
            st.session_state.auto = f"Which tables hold {ent_name(current)}?"

    elif view == "Technical lineage":
        st.markdown('<span class="kc-banner">Technical lineage is shown for the live domain, Accounts Payable</span>',
                    unsafe_allow_html=True)
        with st.container(border=True):
            p0 = process_df.iloc[0]
            st.markdown(f'<div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px">'
                        f'<p class="kc-t">Accounts Payable process</p><span class="kc-banner">Illustrative flow · to be replaced '
                        f'by the customer\'s AP entity list</span></div><p class="kc-note">{esc(p0["PROCESS_L1"])} (L1) › '
                        f'{esc(p0["PROCESS_L2"])} (L2) › {esc(p0["PROCESS_L3"])} (L3)</p>', unsafe_allow_html=True)
            cards = []
            for _, s in process_df.iterrows():
                gap = s["STEP_STATUS"] == "Gap"
                eo = ent_objects_df[ent_objects_df["ENTITY_ID"] == s["ENTITY_ID"]].sort_values(["EVIDENCE", "OBJECT_ROLE", "OBJECT_NAME"],
                                                                                                ascending=[False, True, True])
                body = "".join(f'<div class="o{" sfo" if o["IN_SNOWFLAKE"] is True else ""}">'
                               f'{"●&nbsp;" if o["IN_SNOWFLAKE"] is True else ""}{esc(o["OBJECT_NAME"])}'
                               f'{" <i>(POC)</i>" if o["EVIDENCE"] != "Uploaded Excel" else ""}</div>'
                               for _, o in eo.iterrows()) if not gap else \
                    f'<div class="o" style="color:#B3261E">{esc(s["NOTE"] or "Not in loaded data")}</div>'
                cards.append(f'<div class="kc-step{" gap" if gap else ""}"><b>{esc(s["STEP_NAME"])}</b>{body}</div>')
            st.markdown('<div class="kc-steps">' + '<div class="kc-arrow">▶</div>'.join(cards) + '</div>'
                        '<p class="kc-note" style="margin-top:.4rem">Objects named in the uploaded Excel workbook · '
                        '<span style="color:#1E8E5A">● green: found in Snowflake</span> · <i>(POC)</i>: in this Snowflake '
                        'account only</p>', unsafe_allow_html=True)
        with st.container(border=True):
            st.markdown('<p class="kc-t">Lineage graph <span class="kc-note">· click a node to expand or collapse'
                        + (f' · highlighted: <b>{esc(st.session_state.field)}</b>' if st.session_state.field else '')
                        + '</span></p>', unsafe_allow_html=True)
            components.html(LINEAGE_HTML.replace("__MAXH__", "380").replace("__DATA__", lineage_payload(st.session_state.field)),
                            height=450, scrolling=False)
        with st.container(border=True):
            all_cols = dm_fields + [f for f in fact_fields if f not in dm_fields]
            c1, c2 = st.columns([1, 1.4])
            c1.markdown('<p class="kc-t" style="margin-top:.4rem">Column lineage</p>', unsafe_allow_html=True)
            sync("trace_col", st.session_state.field, all_cols, "Select a column to trace…")
            c2.selectbox("Column", ["Select a column to trace…"] + all_cols, label_visibility="collapsed", key="trace_col",
                         on_change=on_pick, args=("trace_col", "field"),
                         format_func=lambda c: c if c.startswith("Select") else
                         (f"{c} · data mart" if c in dm_fields else f"{c} · fact"))
            lin = load("KF_RPT_COLUMN_LINEAGE")
            if len(lin):
                st.download_button("Export CSV (all mart columns)", lin.to_csv(index=False).encode("utf-8-sig"),
                                   file_name="AP_column_lineage.csv", mime="text/csv")
            fld = st.session_state.field
            if fld:
                rec = prov_df[prov_df["FIELD_NAME"] == fld]
                dm_rec = rec[rec["MODEL_NAME"] == DM]
                fact_rec = rec[rec["MODEL_NAME"] == FACT]
                if len(dm_rec) and pd.notna(dm_rec.iloc[0]["FACT_FIELD"]):
                    fact_rec = prov_df[(prov_df["MODEL_NAME"] == FACT) & (prov_df["FIELD_NAME"] == dm_rec.iloc[0]["FACT_FIELD"])]
                hops = []
                if len(fact_rec):
                    f = fact_rec.iloc[0]
                    hops.append(("SAP source", f["SAP_ORIGIN"] or "not stated in the workbook", f"{f['CITATION']}", False))
                    hops.append(("Fact field", f"{EDW}.{FACT}.{f['FIELD_NAME']}", f"{f['TRANSFORMATION_TYPE']} · {str(f['MAPPING'])[:120]}",
                                 len(dm_rec) == 0))
                if len(dm_rec):
                    d = dm_rec.iloc[0]
                    if not len(fact_rec):
                        hops.append(("EDW source", f"{d['SOURCE_EDW_TABLE']}.{d['SOURCE_FIELD'] or ''}".strip("."), d["CITATION"], False))
                    hops.append(("Data mart column", f"{DATAMART}.{DM}.{d['FIELD_NAME']}", f"{d['TRANSFORMATION_TYPE']} · {str(d['MAPPING'])[:120]}", True))
                    vs = views_for(fld)
                    if vs:
                        hops.append(("Reporting views", "; ".join(vs), "Passed through (reporting view, no logic)", False))
                cards = [f'<div class="kc-hopcard{" hl" if hl else ""}"><div class="h">{esc(t)}</div>'
                         + "".join(f'<code>{esc(x.strip())}</code>' for x in str(o).split(";") if x.strip())
                         + f'<div class="kc-note">{esc(s)}</div></div>' for t, o, s, hl in hops]
                st.markdown('<div class="kc-hops">' + '<span class="kc-arr">▶</span>'.join(cards) + '</div>'
                            '<p class="kc-note">Traced from the uploaded mapping workbook and checked against the columns in '
                            'Snowflake. Use the button below to compare with Snowflake\'s own column-level lineage.</p>',
                            unsafe_allow_html=True)
                if st.button("Check against Snowflake lineage", key="sf_lineage"):
                    target = f"{DB}.{DATAMART}.{DM}.{fld}" if len(dm_rec) else f"{DB}.{EDW}.{FACT}.{fld}"
                    try:
                        sfl = q(f"SELECT * FROM TABLE(SNOWFLAKE.CORE.GET_LINEAGE('{target}', 'COLUMN', 'UPSTREAM', 3))")
                        if len(sfl):
                            st.success(f"Snowflake recorded {len(sfl)} upstream lineage edge(s) for {fld}.")
                            st.dataframe(sfl, hide_index=True, use_container_width=True)
                        else:
                            st.info("Snowflake has no lineage recorded for this column yet (it can take a few hours after a load). "
                                    "The path above comes from the uploaded Excel workbook.")
                    except Exception as error:
                        st.info(f"Snowflake lineage is not available here ({str(error)[:140]}). The path above comes from the workbook.")
            else:
                st.markdown('<span class="kc-note">Pick a column, or ask about one, to trace it from SAP to the data mart.</span>',
                            unsafe_allow_html=True)

    else:  # Reports and export
        with st.container(border=True):
            st.markdown('<p class="kc-t">Exportable lineage and mapping reports</p>', unsafe_allow_html=True)
            r1, r2 = st.columns([2, 1.3])
            rkey = r1.selectbox("Report", list(REPORTS), format_func=lambda k: REPORTS[k][0], label_visibility="collapsed",
                                key="report_pick")
            flt = r2.text_input("Filter", placeholder="Filter rows…", label_visibility="collapsed", key="report_filter")
            title, view_name, cols, used = REPORTS[rkey]
            raw_df = load(view_name)
            if rkey == "source" and "SORT_KEY" in raw_df.columns:
                raw_df = raw_df.sort_values("SORT_KEY")
            df = raw_df[[c for c in cols if c in raw_df.columns]].rename(columns=cols)
            for c in df.columns:
                if df[c].dtype == bool or c == "In Snowflake":
                    df[c] = df[c].map({True: "Yes", False: "No"}).fillna("")
            if flt:
                df = df[df.astype(str).apply(lambda r: r.str.contains(flt, case=False, regex=False)).any(axis=1)]
            meta = report_meta(title, used, len(df))
            stamp = datetime.now().strftime("%Y%m%d")
            fname = re.sub(r"[^A-Za-z0-9]+", "_", title).strip("_")[:60]
            e1, e2, e3 = st.columns(3)
            e1.download_button("Export CSV", df.to_csv(index=False).encode("utf-8-sig"), file_name=f"{fname}_{stamp}.csv",
                               mime="text/csv", type="primary", use_container_width=True)
            e2.download_button("Export Excel", xlsx_bytes([(title[:31], list(df.columns), df.fillna("").values.tolist()),
                                                           ("About this report", ["Item", "Value"], meta)]),
                               file_name=f"{fname}_{stamp}.xlsx", use_container_width=True,
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            e3.download_button("Print / Save as PDF", report_html(title, meta, df.fillna("")), file_name=f"{fname}_{stamp}.html",
                               mime="text/html", use_container_width=True, help="Opens as a print-ready page; use Print → Save as PDF.")
            st.markdown(f'<p class="kc-note"><b>{esc(title)}</b> · {len(df)} rows · Sources: {src_tags(used)}<br>'
                        'Draft for review. Lineage is traced from the uploaded Excel workbook and checked against Snowflake '
                        'objects; the glossary and Word narrative are samples.</p>', unsafe_allow_html=True)
            st.dataframe(df, hide_index=True, use_container_width=True, height=380)

    # -------------------------------------------------------------- Sources / Field record
    with st.container(border=True):
        t_src, t_rec, t_cmp = st.tabs(["Sources", "Field record", "Completeness"])
        with t_src:
            ev = st.session_state.evidence
            if ev:
                st.markdown(f'**Used for this answer:** {src_tags(ev["sources"]) or tag("none detected", "gr")}'
                            f'<br><span class="kc-note">Question: {esc(ev["question"])}</span>', unsafe_allow_html=True)
                if ev["tools"]:
                    st.markdown('<span class="kc-note">Agent tools: ' + ", ".join(esc(t) for t in ev["tools"]) + "</span>",
                                unsafe_allow_html=True)
                if ev["docs"]:
                    st.markdown('<span class="kc-note">Documents cited: ' + "; ".join(esc(d) for d in ev["docs"]) + "</span>",
                                unsafe_allow_html=True)
                for i, sql in enumerate(ev["sql"]):
                    with st.expander(f"SQL run by the co-worker ({i + 1})"):
                        st.code(sql, language="sql")
            else:
                st.markdown('**Used for this answer:** ' + tag("Uploaded Excel", "xls") +
                            '<br><span class="kc-note">Ask a question to see the evidence behind its answer.</span>',
                            unsafe_allow_html=True)
            with st.expander("All metadata sources and status"):
                for _, r in sources_df.iterrows():
                    st.markdown(f'{tag(r["SOURCE_NAME"], SRC_CLASS.get(r["SOURCE_NAME"], "gr"))} **{esc(r["SOURCE_STATUS"])}** · '
                                f'{esc(r["DETAIL"])}<br><span class="kc-note">{esc(r["PROVIDES"])} Owner: {esc(r["OWNER_ROLE"])}. '
                                f'Precedence {int(r["PRECEDENCE"])}.</span>', unsafe_allow_html=True)
            with st.expander("Upload a Word document (process narrative, SOP)"):
                st.markdown('<span class="kc-note">Paragraphs are linked to business entities by their names and synonyms '
                            'and become searchable by the co-worker.</span>', unsafe_allow_html=True)
                up = st.file_uploader("Word document", type=["docx"], label_visibility="collapsed", key="word_up")
                if up is not None and st.button("Load document", type="primary"):
                    try:
                        t, n, searchable = save_word(up.name, up.getvalue())
                        refresh_data()
                        st.success(f"Loaded “{t}”: {n} paragraphs." + ("" if searchable else
                                   " (Search refresh not allowed here; it is picked up on the next search refresh.)"))
                    except Exception as error:
                        st.error(f"Could not load the document: {str(error)[:200]}")
                docs = load("KF_UPLOADED_DOCUMENTS", "ORDER BY UPLOADED_AT DESC")
                if len(docs):
                    st.dataframe(docs[["DOC_TITLE", "FILE_NAME", "DOC_STATUS", "PARAGRAPHS", "UPLOADED_BY"]],
                                 hide_index=True, use_container_width=True)
        with t_rec:
            fld = st.session_state.field
            rec = prov_df[prov_df["FIELD_NAME"] == fld] if fld else prov_df.iloc[0:0]
            if len(rec):
                for _, r in rec.iterrows():
                    status = r["DEFINITION_STATUS"]
                    cls = "ok" if status in ("Approved", "Documented in workbook") else "dr" if status.startswith("Draft") else "no"
                    st.markdown(f'**{esc(r["SHEET"])}** · row {int(r["SHEET_ROW"])} · `{esc(r["SCHEMA_NAME"])}.{esc(r["MODEL_NAME"])}.'
                                f'{esc(r["FIELD_NAME"])}`<br>{src_tags(str(r["METADATA_SOURCES"]).split(" · "))}',
                                unsafe_allow_html=True)
                    facts = {"Business name": r["BUSINESS_NAME"], "Business entity": ent_name(r["ENTITY_ID"]),
                             "Definition": r["BUSINESS_DEFINITION"], "Transformation type": r["TRANSFORMATION_TYPE"],
                             "SAP origin": r["SAP_ORIGIN"], "Source EDW table / view": r["SOURCE_EDW_TABLE"],
                             "Source field": r["SOURCE_FIELD"], "Data type (Snowflake)": r["SNOWFLAKE_DATA_TYPE"],
                             "Column comment (Snowflake)": r["SNOWFLAKE_COMMENT"], "Citation": r["CITATION"]}
                    st.markdown(tag(status, cls) + "  \n" + "\n".join(f"- **{k}:** {esc(v)}" for k, v in facts.items()
                                                                      if v is not None and str(v) not in ("", "nan", "None")),
                                unsafe_allow_html=True)
                    st.code(r["MAPPING"] or "", language="sql")
            else:
                st.caption("Ask about a field, pick one in Build a question or Column lineage, or drill down from an entity.")
        with t_cmp:
            st.markdown('<p class="kc-t">Metadata completeness scorecard (live)</p>', unsafe_allow_html=True)
            cov = load("KF_RPT_METADATA_SOURCES")
            for _, r in (cov.sort_values("SORT_KEY") if len(cov) else cov).iterrows():
                if r["SECTION"] == "Coverage":
                    st.progress(min(max(int(r["PCT"] or 0), 0), 100) / 100,
                                text=f"{r['ITEM']}: {r['STATUS_COVERAGE']} · {r['DETAIL']}")
                elif r["SECTION"] == "Gap":
                    st.markdown(tag("gap", "no") + f'<span class="kc-note">{esc(r["ITEM"])}. {esc(r["DETAIL"])}.</span>',
                                unsafe_allow_html=True)
            st.markdown('<span class="kc-note">Gaps are routed as Tier 2 (consultant drafts, business owner approves in '
                        'Draft &amp; Approve) or Tier 3 (needs an outside source).</span>', unsafe_allow_html=True)

# ------------------------------------------------------------------ right panel
with right:
    ent = st.session_state.entity
    erow = entities_df[entities_df["ENTITY_ID"] == ent].iloc[0] if ent in entities_df["ENTITY_ID"].tolist() else None
    with st.container(border=True):
        a_tab, d_tab, r_tab, x_tab = st.tabs(["Answer", "Business definition", "Relationships", "Drill down"])
        with a_tab:
            chat = st.container(height=430, border=False)
            with chat:
                st.markdown('<div class="kc-greet">Hi, I am the Knowledge Co-Worker. I answer from the loaded Finance AP '
                            'metadata only: Snowflake, the uploaded Excel workbook, the Word narrative and the business '
                            'glossary. Switch the role at the top right to see the Data Engineer, Data Architect or Functional Owner '
                            'view.</div>', unsafe_allow_html=True)
                for m in st.session_state.messages:
                    with st.chat_message(m["role"], avatar="🧑‍💼" if m["role"] == "user" else "📘"):
                        st.markdown(m["text"])
                        if m.get("sources"):
                            st.markdown('<span class="kc-note">Metadata sources used: </span>' + src_tags(m["sources"]),
                                        unsafe_allow_html=True)
        with d_tab:
            if erow is not None:
                st.markdown(f'<p class="kc-t">{esc(erow["ENTITY_NAME"])}</p>{tag(erow["ENTITY_TYPE"], "gr")}'
                            f'{tag("Shared across domains", "gr") if erow["IS_SHARED"] else ""}'
                            f'{tag("Planned", "dr") if erow["ENTITY_STATUS"] == "Planned" else ""}', unsafe_allow_html=True)
                st.markdown(f'{esc(erow["BUSINESS_DEFINITION"])}<br>{tag("Business Glossary · " + erow["DEFINITION_STATUS"], "glo")}'
                            f'<span class="kc-note">Owner: {esc(erow["OWNER_ROLE"])}</span>', unsafe_allow_html=True)
                nar = narrative_df[narrative_df["ENTITY_ID"] == ent] if len(narrative_df) else narrative_df
                st.markdown('<p class="kc-h">Process narrative</p>', unsafe_allow_html=True)
                if len(nar):
                    for _, p in nar.head(4).iterrows():
                        st.markdown(f'“{esc(p["PARA_TEXT"])}”<br>{tag("Uploaded Word Document · " + str(p["DOC_TITLE"]), "doc")}'
                                    f'<span class="kc-note">paragraph {int(p["PARA_NO"])}</span>', unsafe_allow_html=True)
                else:
                    st.markdown('<span class="kc-note">No Word paragraph mentions this entity yet.</span>', unsafe_allow_html=True)
                st.markdown(f'<p class="kc-h">Synonyms</p><span class="kc-note">{esc(erow["SYNONYMS"])}</span>', unsafe_allow_html=True)
            else:
                st.markdown('<span class="kc-note">Pick an entity under the graph (Inspect entity), or ask about one, '
                            'e.g. “Which tables hold AP Document?”.</span>', unsafe_allow_html=True)
            fld = st.session_state.field
            if fld:
                fr = prov_df[prov_df["FIELD_NAME"] == fld].iloc[0]
                st.markdown(f'<p class="kc-h">Field · {esc(fld)}</p><b>{esc(fr["BUSINESS_NAME"] or fld)}</b>: '
                            f'{esc(fr["BUSINESS_DEFINITION"] or "no business definition yet")}<br>'
                            f'{tag(fr["DEFINITION_STATUS"], "ok" if fr["DEFINITION_STATUS"] in ("Approved", "Documented in workbook") else "dr" if str(fr["DEFINITION_STATUS"]).startswith("Draft") else "no")}',
                            unsafe_allow_html=True)
        with r_tab:
            if erow is not None:
                rr = rels_df[(rels_df["FROM_ENTITY"] == ent) | (rels_df["TO_ENTITY"] == ent)]
                st.markdown(f'<p class="kc-t">{esc(erow["ENTITY_NAME"])} · {len(rr)} relationships</p>', unsafe_allow_html=True)
                for _, r in rr.iterrows():
                    solid = r["LINE_STYLE"] == "solid"
                    st.markdown(f'<div class="kc-card"><b>{esc(r["FROM_NAME"])}</b> → {esc(r["RELATIONSHIP"])} → '
                                f'<b>{esc(r["TO_NAME"])}</b><br>{tag("Supported by workbook" if solid else r["EVIDENCE_STATUS"], "ok" if solid else "dr")}'
                                f'<span class="kc-note">{esc(r["EVIDENCE_DETAIL"])}</span></div>', unsafe_allow_html=True)
                if not len(rr):
                    st.caption("No relationships recorded.")
            else:
                st.caption("Pick an entity to see how it relates to other business entities.")
        with x_tab:
            st.markdown('<p class="kc-h">Business-to-technical drill down</p>', unsafe_allow_html=True)
            if erow is not None:
                eo = ent_objects_df[ent_objects_df["ENTITY_ID"] == ent]
                st.markdown(f'<b>{esc(erow["ENTITY_NAME"])}</b> → {len(eo)} technical objects', unsafe_allow_html=True)
                if not len(eo):
                    st.markdown(tag("Not in loaded data", "no") + '<span class="kc-note">Route as a gap to the AP Data Steward (role).</span>',
                                unsafe_allow_html=True)
                for _, o in eo.iterrows():
                    insf = bool(o["IN_SNOWFLAKE"]) if pd.notna(o["IN_SNOWFLAKE"]) else False
                    counts = []
                    if o["FIELDS_IN_WORKBOOK"]:
                        counts.append(f'{int(o["FIELDS_IN_WORKBOOK"])} fields in workbook')
                    if o["FACT_FIELDS_FED"]:
                        counts.append(f'feeds {int(o["FACT_FIELDS_FED"])} fact fields')
                    if o["MART_COLUMNS_FED"]:
                        counts.append(f'feeds {int(o["MART_COLUMNS_FED"])} mart columns')
                    st.markdown(f'<div class="kc-card"><span class="m"><b>{esc(o["OBJECT_NAME"])}</b></span> '
                                f'<span class="kc-note">{esc(o["OBJECT_ROLE"])} · {esc(o["FRIENDLY_NAME"])}</span><br>'
                                f'{tag("in Snowflake: " + str(o["SNOWFLAKE_KEY"]), "sf") if insf else tag("workbook only", "gr")}'
                                f'{tag(o["EVIDENCE"], SRC_CLASS.get(o["EVIDENCE"], "gr"))}'
                                f'<span class="kc-note">{esc(" · ".join(counts))}</span></div>', unsafe_allow_html=True)
                ef = prov_df[prov_df["ENTITY_ID"] == ent]
                if len(ef):
                    st.markdown(f'<p class="kc-h">Fields linked to {esc(erow["ENTITY_NAME"])} ({len(ef)})</p>', unsafe_allow_html=True)
                    st.dataframe(ef[["MODEL_NAME", "FIELD_NAME", "BUSINESS_NAME", "DEFINITION_STATUS"]].rename(columns={
                        "MODEL_NAME": "Table", "FIELD_NAME": "Field", "BUSINESS_NAME": "Business name",
                        "DEFINITION_STATUS": "Definition"}), hide_index=True, use_container_width=True, height=220)
                    opts = ef["FIELD_NAME"].drop_duplicates().tolist()
                    sync(f"drill_{ent}", st.session_state.field, opts, "Select a field…")
                    st.selectbox("Open a field (Field record, Column lineage)", ["Select a field…"] + opts, key=f"drill_{ent}",
                                 on_change=on_pick, args=(f"drill_{ent}", "field", False))
            else:
                st.caption("Pick an entity to go from the business view down to tables, columns and their documentation.")

        c1, c2 = st.columns([4, 1])
        typed = c1.text_input("Ask", value=st.session_state.pending, key=f"box_{st.session_state.box}",
                              placeholder="Ask about AP tables, fields, lineage…", label_visibility="collapsed")
        clicked = c2.button("Ask", type="primary", use_container_width=True)
        question = st.session_state.auto or (typed.strip() if clicked else "")
        if question:
            st.session_state.auto = None
            st.session_state.field = detect_field(question) or st.session_state.field
            st.session_state.entity = detect_entity(question) or st.session_state.entity
            with st.spinner("Checking Snowflake metadata, the workbook, the glossary and documents..."):
                answer = ask_agent(question)
            used = (st.session_state.evidence or {}).get("sources", [])
            st.session_state.messages += [{"role": "user", "text": question},
                                          {"role": "assistant", "text": answer, "sources": used}]
            put_question("")
            st.rerun()

    # -------------------------------------------------------------- Draft & Approve
    f_all = fields()
    apv = approvals()
    gaps_all = f_all[(f_all["MODEL_NAME"] == DM) & (f_all["DEFINITION"] == "")]["FIELD_NAME"].tolist()
    approved = set(apv.loc[apv["STATUS"] == "Approved", "FIELD_NAME"])
    gap_total = len(set(gaps_all) | approved)
    with st.container(border=True):
        st.markdown('<p class="kc-t">Draft & Approve · close documentation gaps</p><span class="kc-note">Mart columns with no '
                    'business description yet. The co-worker drafts one from the mapping rule and the actual data; the '
                    'consultant edits it and the Functional Owner approves it.</span>', unsafe_allow_html=True)
        open_gaps = [g for g in gaps_all if g not in approved]
        drafted = set(apv.loc[apv["STATUS"] == "Draft", "FIELD_NAME"])
        pick = st.selectbox("Column", (["Select a data mart column…"] + open_gaps) if open_gaps else ["(all descriptions approved)"],
                            label_visibility="collapsed", key="gap_pick",
                            format_func=lambda c: f"✎ {c}  ·  draft ready" if c in drafted else c)
        picked = pick in open_gaps
        suggest = st.button("Suggest a description", use_container_width=True, type="primary", disabled=not picked)

        if suggest:
            row = f_all[(f_all["MODEL_NAME"] == DM) & (f_all["FIELD_NAME"] == pick)].iloc[0].to_dict()
            src = f_all[(f_all["MODEL_NAME"] == FACT) & (f_all["FIELD_NAME"] == str(row["SOURCE_FIELD"]).upper())]
            src_def = (f"{src.iloc[0]['BUSINESS_NAME']}: {src.iloc[0]['DEFINITION']}"
                       if len(src) and src.iloc[0]["DEFINITION"] else "none")
            pe = prov_df[(prov_df["MODEL_NAME"] == DM) & (prov_df["FIELD_NAME"] == pick)]
            entity = ent_name(pe.iloc[0]["ENTITY_ID"]) if len(pe) else ""
            with st.spinner("Profiling the data and drafting a description..."):
                try:
                    d = draft_description(pick, row, src_def, entity)
                except Exception as error:
                    st.error(f"Draft failed: {str(error)[:250]}")
                    d = None
            if d:
                evidence = (f"Mapping rule (AP DM Mapping row {row['SHEET_ROW']})"
                            + (" · fact field definition" if src_def != "none" else "") + " · data profile")
                values = [d["name"], d["text"], d["confidence"], d["basis"], profile_text(d["profile"]), evidence]
                run(f"""MERGE INTO {KF}.KF_DESCRIPTION_APPROVALS t USING (SELECT ? AS M, ? AS F) s
                        ON t.MODEL_NAME = s.M AND t.FIELD_NAME = s.F
                        WHEN MATCHED THEN UPDATE SET BUSINESS_NAME = ?, SUGGESTED_TEXT = ?, STATUS = 'Draft', CONFIDENCE = ?,
                             BASIS = ?, PROFILE = ?, EVIDENCE = ?, SUGGESTED_BY = CURRENT_USER(), SUGGESTED_AT = CURRENT_TIMESTAMP()
                        WHEN NOT MATCHED THEN INSERT (MODEL_NAME, FIELD_NAME, BUSINESS_NAME, SUGGESTED_TEXT, STATUS, CONFIDENCE,
                             BASIS, PROFILE, EVIDENCE, SUGGESTED_BY, SUGGESTED_AT)
                             VALUES (s.M, s.F, ?, ?, 'Draft', ?, ?, ?, ?, CURRENT_USER(), CURRENT_TIMESTAMP())""",
                    [DM, pick] + values + values)
                for k in (f"name_{pick}", f"text_{pick}"):
                    st.session_state.pop(k, None)
                refresh_data()
                apv = approvals()

        cur = apv[(apv["FIELD_NAME"] == pick) & (apv["STATUS"] == "Draft")] if picked else apv.iloc[0:0]
        if len(cur):
            c = cur.iloc[0]
            conf = c["CONFIDENCE"] or "Medium"
            st.markdown(tag("Draft · pending approval", "dr") + tag(f"Confidence: {conf}", {"High": "ok", "Low": "no"}.get(conf, "dr")),
                        unsafe_allow_html=True)
            if c["BASIS"]:
                st.markdown(f'<span class="kc-note">{esc(c["BASIS"])}</span>', unsafe_allow_html=True)
            name = st.text_input("Business name", value=c["BUSINESS_NAME"] or pick.replace("_", " ").title(), key=f"name_{pick}")
            text = st.text_area("Business description", value=c["SUGGESTED_TEXT"], key=f"text_{pick}", height=90)
            st.markdown(f'<span class="kc-note">Evidence: {esc(c["EVIDENCE"])} · drafted by {esc(c["SUGGESTED_BY"])}</span>',
                        unsafe_allow_html=True)
            with st.expander("Data profile and mapping rule behind this draft"):
                st.markdown(f"**Data profile** · `{DM}.{pick}`  \n{c['PROFILE']}")
                rule = f_all[(f_all["MODEL_NAME"] == DM) & (f_all["FIELD_NAME"] == pick)].iloc[0]["MAPPING"]
                st.markdown("**Mapping rule (AP DM mapping sheet)**")
                st.code(rule, language="sql")
            is_owner = st.session_state.role == OWNER
            b1, b2 = st.columns(2)
            if b1.button("Approve", type="primary", disabled=not is_owner, use_container_width=True):
                run(f"""UPDATE {KF}.KF_DESCRIPTION_APPROVALS SET BUSINESS_NAME = ?, FINAL_TEXT = ?, STATUS = 'Approved',
                        DECIDED_BY = CURRENT_USER(), DECIDED_AT = CURRENT_TIMESTAMP() WHERE MODEL_NAME = ? AND FIELD_NAME = ?""",
                    [name, text, DM, pick])
                run(f"UPDATE {KF}.KF_EXCEL_MAPPING_SHEET SET BUSINESS_NAME = ?, DEFINITION = ? WHERE MODEL_NAME = ? AND FIELD_NAME = ?",
                    [name, text, DM, pick])
                comment = (name + ": " + text).replace("\\", " ").replace("'", "''")
                try:
                    run(f"ALTER TABLE {DB}.{DATAMART}.{DM} MODIFY COLUMN {pick} COMMENT '{comment}'")
                except Exception:
                    pass
                refresh_data()
                st.toast(f"{pick} approved and written to the column comment in Snowflake.", icon="✅")
                st.rerun()
            if b2.button("Reject", disabled=not is_owner, use_container_width=True):
                run(f"""UPDATE {KF}.KF_DESCRIPTION_APPROVALS SET STATUS = 'Rejected', DECIDED_BY = CURRENT_USER(),
                        DECIDED_AT = CURRENT_TIMESTAMP() WHERE MODEL_NAME = ? AND FIELD_NAME = ?""", [DM, pick])
                refresh_data()
                st.toast(f"{pick} rejected. The column stays open for a new draft.", icon="✖️")
                st.rerun()
            st.markdown('<span class="kc-note">' + ("You can edit the name and text before approving." if is_owner else
                        f"Switch the role (top right) to {OWNER} to approve. You can still edit the text.") + '</span>',
                        unsafe_allow_html=True)
        elif open_gaps:
            st.markdown('<span class="kc-note">Pick a column above to begin, then press <b>Suggest a description</b>. '
                        f'{len(open_gaps)} mart columns still have no business description.</span>', unsafe_allow_html=True)
        st.progress(len(approved) / max(gap_total, 1), text=f"{len(approved)} of {gap_total} data mart descriptions approved")
        decided = apv[apv["STATUS"].isin(["Approved", "Rejected"])].sort_values("DECIDED_AT", ascending=False)
        if len(decided):
            with st.expander(f"Decision log ({len(decided)})"):
                for _, r in decided.head(20).iterrows():
                    st.markdown(f'{tag(r["STATUS"], "ok" if r["STATUS"] == "Approved" else "no")} <b>{esc(r["FIELD_NAME"])}</b> · '
                                f'{esc(r["BUSINESS_NAME"])}: {esc(r["FINAL_TEXT"] or r["SUGGESTED_TEXT"])} '
                                f'<span class="kc-note">· {esc(r["DECIDED_BY"])}</span>', unsafe_allow_html=True)


# ------------------------------------------------------------------ executive snapshot (full width, live)
def pct(a, b):
    return round(100 * a / b) if b else 0


def bar(label, value, maxv, color=None, show=None):
    width = pct(value, maxv)
    col = color or ("var(--ok)" if width >= 90 else "var(--warn)" if width >= 50 else "var(--bad)")
    return (f'<div class="hb"><label title="{esc(label)}">{esc(label)}</label><div class="tr"><i style="width:{width}%;'
            f'background:{col}"></i></div><em>{esc(show if show is not None else value)}</em></div>')


@st.cache_data(ttl=600)
def load_tasks():
    """Snowflake tasks that load the fact table and the data mart (refresh schedule)."""
    try:
        t = q(f"SHOW TASKS IN DATABASE {DB}")
        names = " ".join(t[[c for c in t.columns if c.strip('"').lower() == "name"][0]].astype(str))
        return {m: (f"LOAD_{m}" in names) for m in (FACT, DM)}
    except Exception:
        return {FACT: False, DM: False}


fact_p = prov_df[prov_df["MODEL_NAME"] == FACT]
dm_p = prov_df[prov_df["MODEL_NAME"] == DM]
n_from_fact = int(dm_p["TRANSFORMATION_TYPE"].isin(["Direct (pass-through)", "Direct with rule"]).sum())
n_calc = int((dm_p["TRANSFORMATION_TYPE"] == "Calculated").sum())
n_join = len(dm_p) - n_from_fact - n_calc
sap_n = int(fact_p["SAP_ORIGIN"].fillna("").ne("").sum())
def_n = int(fact_p["BUSINESS_DEFINITION"].fillna("").ne("").sum())
apc = len(approved)
dm_described = int(dm_p["DEFINITION_STATUS"].isin(["Approved", "Documented in workbook"]).sum())
src_tabs = fact_p["SOURCE_TABLE"].fillna("").loc[lambda x: x != ""].value_counts()
types_n = int(prov_df["SNOWFLAKE_DATA_TYPE"].notna().sum())
comments_n = int(prov_df["SNOWFLAKE_COMMENT"].fillna("").ne("").sum())
tasks = load_tasks()
status = {r["SOURCE_NAME"]: r["SOURCE_STATUS"] for _, r in sources_df.iterrows()}
ap_ents = entities_df[entities_df["DOMAINS"].str.contains("ap")]
n_live_dom = int((domains_df["DOMAIN_STATUS"] == "Live").sum())
n_plan_dom = int((domains_df["DOMAIN_STATUS"] == "Planned").sum())

kpis = [("", 4, "layers: SAP → fact → mart → reports"), ("", len(fact_p), "fact fields documented"),
        ("", len(dm_p), "data mart columns mapped"), ("", len(VIEWS), "reporting views on the mart"),
        ("g", f"{pct(def_n, len(fact_p))}%", "fact fields with business definitions"),
        ("r" if apc == 0 else "w", f"{pct(apc, len(dm_p))}%", f"mart columns with approved definitions ({apc})")]
flow = [("SAP source", f"{src_tabs.index[0] if len(src_tabs) else 'BSEG'} + {max(len(src_tabs) - 1, 0)} related tables"),
        ("Fact table", f"{len(fact_p)} fields · {pct(sap_n, len(fact_p))}% traced to SAP"),
        ("Data mart", f"{len(dm_p)} columns · {n_calc} calculated"), ("Reporting views", f"{len(VIEWS)} views · Tableau")]
parts = [("From the fact table", n_from_fact, "#0070AD"), ("Joined from master / reference data", n_join, "#12ABDB"),
         ("Calculated in the mart", n_calc, "#C77700")]
donut, off = '<circle cx="21" cy="21" r="15.9" fill="none" stroke="#E5ECF2" stroke-width="6"/>', 25.0
for _, n, c in parts:
    v = 100 * n / max(len(dm_p), 1)
    donut += (f'<circle cx="21" cy="21" r="15.9" fill="none" stroke="{c}" stroke-width="6" stroke-dasharray="{v:.2f} {100 - v:.2f}" '
              f'stroke-dashoffset="{off:.2f}"/>')
    off -= v
donut += f'<text x="21" y="23" text-anchor="middle" font-size="7" font-weight="700" fill="#0B2A4A">{len(dm_p)}</text>'
top = src_tabs.head(7)
coverage = [("Fact: definition", def_n, len(fact_p)), ("Fact: SAP origin traced", sap_n, len(fact_p)),
            ("Mart: rule documented", int(dm_p["MAPPING"].fillna("").ne("").sum()), len(dm_p)),
            ("Mart: business definition", dm_described, len(dm_p)), ("Mart: approved in the app", apc, len(dm_p)),
            ("Data types (Snowflake)", types_n, len(prov_df)), ("Column comments (Snowflake)", comments_n, len(prov_df)),
            ("Refresh schedule (tasks)", sum(tasks.values()), 2), ("Owner / steward per field", 0, len(prov_df))]
answers_from = [("Excel mapping workbook", status.get("Uploaded Excel", "?"), "ok"),
                ("Snowflake metadata (tables, columns, types, comments)", status.get("Snowflake Metadata", "?"),
                 "ok" if status.get("Snowflake Metadata") == "Connected" else "dr"),
                ("Snowflake column-level lineage", "Available: check per column", "ok"),
                ("Descriptions stored as Snowflake column comments", "Active via Approve", "ok"),
                ("Business glossary", status.get("Business Glossary", "?"), "dr"),
                ("Word process narrative", status.get("Uploaded Word Document", "?"),
                 "ok" if status.get("Uploaded Word Document") == "Loaded" else "dr")]
next_steps = [("Connect to Snowflake metadata (sandbox)", "Done"),
              ("Column-level lineage and the interactive graph on live metadata", "Done"),
              ("Approved descriptions written back as column comments", "Done"),
              ("AP process map from the customer's entity list", "Waiting for the list"),
              ("Same build in the customer development environment", "Next")]

html_ex = (
    '<div class="ex"><h2>Executive snapshot · Finance AP metadata (live from Snowflake)</h2><div class="kpis">'
    + "".join(f'<div class="kpi {c}"><b>{esc(v)}</b><span>{esc(t)}</span></div>' for c, v, t in kpis) + '</div>'
    + '<div class="card"><h3>How AP data flows, and what is documented at each step</h3><div class="flow">'
    + '<s>▶</s>'.join(f'<div><b>{esc(a)}</b>{esc(b)}</div>' for a, b in flow) + '</div></div>'
    + '<div class="grid3">'
    + '<div class="card"><h3>Where data mart columns come from</h3><div style="display:flex;gap:14px;align-items:center">'
    + f'<svg width="130" height="130" viewBox="0 0 42 42">{donut}</svg><div>'
    + "".join(f'<div class="leg"><i style="background:{c}"></i>{esc(a)}: <b>{n}</b> ({pct(n, len(dm_p))}%)</div>' for a, n, c in parts)
    + '</div></div></div>'
    + '<div class="card"><h3>Top SAP / source tables behind the fact table</h3>'
    + "".join(bar(t, int(n), int(top.iloc[0]), "var(--blue)") for t, n in top.items()) + '</div>'
    + '<div class="card"><h3>Documentation coverage: what exists vs. the gap</h3>'
    + "".join(bar(a, n, b, show=f"{pct(n, b)}%") for a, n, b in coverage) + '</div></div>'
    + '<div class="grid3">'
    + '<div class="card"><h3>Why it matters</h3><ul><li>Answers to “where does this number come from?” in seconds, with a '
      'citation, instead of chasing people or SQL.</li><li>Reduces dependence on a few experts who hold the mapping knowledge.'
      '</li><li>Gives the trusted metadata foundation that later phases (semantic layer, AI answers on data) need.</li></ul></div>'
    + '<div class="card"><h3>What the Co-Worker does with the gaps</h3>'
    + '<div class="leg"><i style="background:var(--ok)"></i><b>Tier 1 · Load</b>: tables, columns, data types, comments and '
      'lineage straight from Snowflake</div>'
    + f'<div class="leg"><i style="background:var(--warn)"></i><b>Tier 2 · Draft &amp; approve</b>: {len(open_gaps)} mart-column '
      'definitions drafted by the co-worker, edited by the consultant, approved by the business owner</div>'
    + '<div class="leg"><i style="background:var(--bad)"></i><b>Tier 3 · Outside source</b>: owners, KPI definitions, report '
      'descriptions, the customer AP entity list</div></div>'
    + '<div class="card dec"><h3>Decisions needed from the business</h3><ul><li>Confirm BSEG vs BSEC as the AP line-item source '
      'with customer data engineers.</li><li>Approve AI-drafted business definitions (business owner sign-off).</li><li>Name '
      'owners / stewards, routed via the Data Privacy Officer.</li><li>Confirm Snowflake feature availability for the next '
      'phase.</li></ul></div></div>'
    + '<div class="grid3">'
    + '<div class="card"><h3>Where answers come from</h3><table>'
    + "".join(f'<tr><td>{esc(a)}</td><td>{tag(b, c)}</td></tr>' for a, b, c in answers_from) + '</table></div>'
    + '<div class="card"><h3>Three personas, one knowledge base</h3><ul><li><b>Data Engineer:</b> schemas, column lineage, rules '
      'and technical names.</li><li><b>Data Architect:</b> model purpose, reuse, dimensions, sources and derived logic.</li>'
      '<li><b>Functional Owner:</b> business names, answers in plain words, the process flow and '
      'approvals.</li><li>The role follows the Snowflake role of whoever signs in'
    + (f' (now: {esc(role_from)})' if role_from else '') + '.</li></ul></div>'
    + '<div class="card"><h3>Status of the proposed next steps</h3><table>'
    + "".join(f'<tr><td>{esc(a)}</td><td>{tag(b, "ok" if b == "Done" else "dr")}</td></tr>' for a, b in next_steps)
    + '</table></div></div>'
    + '<div class="grid3">'
    + '<div class="card"><h3>Ontology at a glance</h3><div class="mini">'
    + f'<span>Domains</span><b>{n_live_dom} live, {n_plan_dom} planned</b><span>AP entities</span><b>{len(ap_ents)}</b>'
    + f'<span>AP links supported by workbook</span><b>{int((rels_df["EVIDENCE_STATUS"] == "Supported by workbook").sum())}</b>'
    + f'<span>Links proposed (AP process)</span><b>{int((rels_df["EVIDENCE_BASIS"] == "Meeting notes").sum())}</b>'
    + f'<span>Shared entities</span><b>{int(entities_df["IS_SHARED"].astype(bool).sum())}</b></div></div>'
    + '<div class="card"><h3>Metadata source transparency</h3><table>'
    + "".join(f'<tr><td>{tag(r["SOURCE_NAME"], SRC_CLASS.get(r["SOURCE_NAME"], "gr"))}</td><td class="kc-note">{esc(r["SOURCE_STATUS"])}</td></tr>'
              for _, r in sources_df.iterrows()) + '</table></div>'
    + '<div class="card"><h3>Exports available</h3><ul><li>Source-to-target mapping</li><li>Column-level lineage</li><li>Entity to '
      'technical map and relationships</li><li>Source transparency and completeness</li></ul>'
      '<span class="kc-note">CSV, Excel and print to PDF in Reports and export.</span></div></div>'
    + '<p style="text-align:center;margin-top:12px;font-size:.74rem;color:#5F6F7E">Synthetic POC data. Metadata is read live from Snowflake '
      'and the uploaded AP workbook. Where no source has the information (owners, KPI definitions per field), the Co-Worker '
      'says so rather than guessing. Review and validate before sharing externally.</p></div>')
st.markdown(html_ex, unsafe_allow_html=True)

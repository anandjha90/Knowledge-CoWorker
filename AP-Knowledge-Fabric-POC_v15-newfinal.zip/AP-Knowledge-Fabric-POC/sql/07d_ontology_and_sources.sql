-- =====================================================================
-- 07d BUSINESS ONTOLOGY, PROCESS CONTEXT AND METADATA SOURCE TRANSPARENCY
--   Client demo feedback (v3 design): business entities and their relationships on top of the
--   technical model, business-to-technical drill down, multi-domain framework, AP process context
--   (L1-L3), metadata source transparency (Snowflake Metadata / Uploaded Excel / Uploaded Word
--   Document / Business Glossary) and five exportable lineage and mapping reports.
--
--   Shaped like Snowflake's business ontology concepts (entities, relationships, mapped objects) so it
--   can move to the native feature when that is available in the account. Synthetic POC data.
--   Evidence counts and statuses are computed live from the loaded workbook and from Snowflake.
-- =====================================================================
USE WAREHOUSE {{WAREHOUSE}};

-- ---------------------------------------------------------------- domains (multi-domain framework)
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_DOMAIN (
  DOMAIN_ID     VARCHAR COMMENT 'Domain ID: ap, ar, gl, proc, ent.',
  DOMAIN_NAME   VARCHAR COMMENT 'Domain name, e.g. Accounts Payable.',
  DOMAIN_STATUS VARCHAR COMMENT 'Live (metadata loaded), Planned (entities proposed, no metadata yet) or View (all domains).',
  DESCRIPTION   VARCHAR COMMENT 'What the domain covers.',
  SORT_ORDER    NUMBER
) COMMENT = 'Business domains of the knowledge co-worker. Accounts Payable is live; the others are planned.';

INSERT INTO {{DATABASE}}.{{KF}}.KF_DOMAIN VALUES
  ('ap',   'Accounts Payable',    'Live',    'Vendor invoices, AP documents and payments. Tables and columns come from the AP mapping workbook and Snowflake.', 1),
  ('ar',   'Accounts Receivable', 'Planned', 'Customers, sales orders, AR invoices and cash receipts. Entities proposed, no metadata loaded yet.', 2),
  ('gl',   'General Ledger',      'Planned', 'Journal entries, GL accounts and cost centers. Entities proposed, no metadata loaded yet.', 3),
  ('proc', 'Procurement',         'Planned', 'Vendors, materials, purchase orders and goods receipts. Shares Vendor and Purchase Order with AP.', 4),
  ('ent',  'Enterprise view',     'View',    'All domains together. Entities shared across domains appear once.', 5);

-- ---------------------------------------------------------------- business entities
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY (
  ENTITY_ID           VARCHAR COMMENT 'Entity ID, e.g. apdoc.',
  ENTITY_NAME         VARCHAR COMMENT 'Business entity name, e.g. AP Document.',
  ENTITY_TYPE         VARCHAR COMMENT 'Master data, Transaction, Reference or Report.',
  ABBREVIATION        VARCHAR COMMENT 'Short label used in the graph, e.g. APD.',
  DOMAINS             VARCHAR COMMENT 'Comma-separated domain IDs the entity belongs to (more than one = shared).',
  ENTITY_STATUS       VARCHAR COMMENT 'Live (in the live AP domain) or Planned (shell entity, no metadata yet).',
  BUSINESS_DEFINITION VARCHAR COMMENT 'Business definition of the entity (Business Glossary source).',
  DEFINITION_SOURCE   VARCHAR COMMENT 'Metadata source of the definition.',
  DEFINITION_STATUS   VARCHAR COMMENT 'Sample (POC sample glossary), Draft or Approved.',
  SYNONYMS            VARCHAR COMMENT 'Comma-separated words people use for the entity; used to match questions and Word paragraphs.',
  OWNER_ROLE          VARCHAR COMMENT 'Accountable owner (a role, never a person).',
  GRAPH_X             NUMBER  COMMENT 'Default x position in the ontology graph.',
  GRAPH_Y             NUMBER  COMMENT 'Default y position in the ontology graph.',
  SORT_ORDER          NUMBER
) COMMENT = 'Business entities of the ontology (business layer above tables and columns).';

INSERT INTO {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY VALUES
  ('vendor',   'Vendor',             'Master data', 'VEN', 'ap,proc',       'Live',    'A supplier of goods or services, held as a master record with general and company-level data such as payment terms and status.', 'Business Glossary', 'Sample', 'vendor,supplier,vendors,suppliers', 'AP Finance Data Owner (role)', 90, 210, 1),
  ('po',       'Purchase Order',     'Transaction', 'PO',  'ap,proc',       'Live',    'A commitment to buy goods or services from a vendor at agreed quantities and prices.', 'Business Glossary', 'Sample', 'purchase order,purchase orders,po', 'Procurement Data Owner (role)', 220, 95, 2),
  ('gr',       'Goods Receipt',      'Transaction', 'GR',  'ap,proc',       'Live',    'Confirmation that goods or services ordered on a purchase order were received.', 'Business Glossary', 'Sample', 'goods receipt,goods receipts,gr,gr/ir', 'Procurement Data Owner (role)', 365, 88, 3),
  ('inv',      'Vendor Invoice',     'Transaction', 'INV', 'ap',            'Live',    'A vendor''s bill for goods or services, matched to the purchase order and goods receipt before posting.', 'Business Glossary', 'Sample', 'vendor invoice,vendor invoices,invoice,invoices', 'AP Finance Data Owner (role)', 345, 280, 4),
  ('apdoc',    'AP Document',        'Transaction', 'APD', 'ap',            'Live',    'The accounting record created when a vendor invoice is posted, creating a liability to the vendor.', 'Business Glossary', 'Sample', 'ap document,ap documents,accounting document,accounting documents,ap item,ap line item', 'AP Finance Data Owner (role)', 525, 215, 5),
  ('pay',      'Payment',            'Transaction', 'PAY', 'ap',            'Live',    'The settlement of an open AP document, which clears the liability.', 'Business Glossary', 'Sample', 'payment,payments,vendor payment', 'AP Finance Data Owner (role)', 690, 120, 6),
  ('gl',       'GL Account',         'Reference',   'GL',  'ap,gl',         'Live',    'An account in the chart of accounts to which postings are made.', 'Business Glossary', 'Sample', 'gl account,gl accounts,general ledger account', 'GL Data Owner (role)', 525, 75, 7),
  ('entity',   'Legal Entity',       'Reference',   'ENT', 'ap,ar,gl,proc', 'Live',    'A legal company that books transactions and reports financial results.', 'Business Glossary', 'Sample', 'legal entity,legal entities,company code,company codes', 'Finance Master Data Owner (role)', 515, 385, 8),
  ('org',      'Organization',       'Reference',   'ORG', 'ap,gl',         'Live',    'The organizational structure used to assign and report transactions.', 'Business Glossary', 'Sample', 'organization,organisation,org hierarchy,profit center', 'Finance Master Data Owner (role)', 375, 375, 9),
  ('fiscal',   'Fiscal Calendar',    'Reference',   'FC',  'ap,ar,gl',      'Live',    'The company calendar of fiscal years, periods and days used for posting and reporting.', 'Business Glossary', 'Sample', 'fiscal calendar,fiscal period,fiscal year,fiscal week', 'Finance Master Data Owner (role)', 650, 400, 10),
  ('country',  'Country',            'Reference',   'CTY', 'ap,ar',         'Live',    'A country reference used for vendor and reporting attributes.', 'Business Glossary', 'Sample', 'country,countries,vendor country', 'Finance Master Data Owner (role)', 90, 360, 11),
  ('rpt',      'AP Reporting Views', 'Report',      'RPT', 'ap',            'Live',    'The reporting views that expose AP data from the data mart to Tableau users.', 'Business Glossary', 'Sample', 'ap reporting views,reporting views,ap reports,reports,tableau', 'AP Finance Data Owner (role)', 690, 315, 12),
  ('customer', 'Customer',           'Master data', 'CUS', 'ar',            'Planned', 'A buyer of goods or services, held as a master record.', 'Business Glossary', 'Sample', 'customer,customers', 'To be assigned', 120, 110, 13),
  ('so',       'Sales Order',        'Transaction', 'SO',  'ar',            'Planned', 'A customer order for goods or services.', 'Business Glossary', 'Sample', 'sales order,sales orders', 'To be assigned', 300, 80, 14),
  ('arinv',    'AR Invoice',         'Transaction', 'ARI', 'ar',            'Planned', 'A bill issued to a customer.', 'Business Glossary', 'Sample', 'ar invoice,customer invoice', 'To be assigned', 420, 230, 15),
  ('cash',     'Cash Receipt',       'Transaction', 'CR',  'ar',            'Planned', 'Money received from a customer that clears an open item.', 'Business Glossary', 'Sample', 'cash receipt,cash receipts', 'To be assigned', 640, 180, 16),
  ('je',       'Journal Entry',      'Transaction', 'JE',  'gl',            'Planned', 'A manual or automated posting to the general ledger.', 'Business Glossary', 'Sample', 'journal entry,journal entries', 'To be assigned', 330, 210, 17),
  ('cc',       'Cost Center',        'Reference',   'CC',  'gl',            'Planned', 'An organizational unit used to collect and report costs.', 'Business Glossary', 'Sample', 'cost center,cost centre,cost centers', 'To be assigned', 180, 330, 18),
  ('mat',      'Material',           'Master data', 'MAT', 'proc',          'Planned', 'A good or service that can be ordered, received and stocked.', 'Business Glossary', 'Sample', 'material,materials', 'To be assigned', 90, 60, 19);

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITIES
  COMMENT = 'Business entities with domains, shared flag and default graph position.' AS
SELECT e.*,
       ARRAY_SIZE(SPLIT(e.DOMAINS, ',')) > 1 AS IS_SHARED,
       SPLIT_PART(e.DOMAINS, ',', 1)         AS PRIMARY_DOMAIN
FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY e;

-- ---------------------------------------------------------------- entity -> technical objects
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECT_MAP (
  ENTITY_ID        VARCHAR COMMENT 'Business entity.',
  OBJECT_ROLE      VARCHAR COMMENT 'EDW object, Data mart, Reporting view or SAP table.',
  OBJECT_NAME      VARCHAR COMMENT 'Object name as written in the mapping workbook (SAP tables without prefix).',
  WORKBOOK_SCHEMA  VARCHAR COMMENT 'Schema named in the workbook (may not exist in this account).',
  SNOWFLAKE_SCHEMA VARCHAR COMMENT 'Schema of the object in this Snowflake database, if loaded.',
  SNOWFLAKE_OBJECT VARCHAR COMMENT 'Table or view in this Snowflake database, if loaded.',
  FRIENDLY_NAME    VARCHAR COMMENT 'Business-friendly name of the object.',
  EVIDENCE         VARCHAR COMMENT 'Uploaded Excel (named in the mapping workbook) or Snowflake Metadata (found in the account only).'
) COMMENT = 'Business-to-technical map: which tables, views and SAP tables hold each business entity.';

INSERT INTO {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECT_MAP VALUES
  ('vendor',  'EDW object',     'DIM_VENDOR_GEN',            'CORP_MASTER', NULL,              NULL,                        'Vendor master (general)',   'Uploaded Excel'),
  ('vendor',  'EDW object',     'DIM_VENDOR_COMPANY',        'CORP_MASTER', NULL,              NULL,                        'Vendor master (company)',   'Uploaded Excel'),
  ('vendor',  'SAP table',      'LFB1',                      NULL,          '{{LANDING}}',     'SAP_LFB1',                  'Vendor company data',       'Uploaded Excel'),
  ('vendor',  'SAP table',      'LFA1',                      NULL,          '{{LANDING}}',     'SAP_LFA1',                  'Vendor general data',       'Snowflake Metadata'),
  ('vendor',  'EDW object',     'DIM_VENDOR',                NULL,          '{{EDW}}',         'DIM_VENDOR',                'Vendor dimension (POC)',    'Snowflake Metadata'),
  ('po',      'EDW object',     'FACT_PURCHASE_ORDER',       'CORP_TRAN',   NULL,              NULL,                        'Purchase orders',           'Uploaded Excel'),
  ('po',      'SAP table',      'EKKO',                      NULL,          NULL,              NULL,                        'PO header',                 'Uploaded Excel'),
  ('po',      'SAP table',      'EKPO',                      NULL,          NULL,              NULL,                        'PO items',                  'Uploaded Excel'),
  ('inv',     'SAP table',      'RSEG',                      NULL,          NULL,              NULL,                        'Invoice items',             'Uploaded Excel'),
  ('apdoc',   'EDW object',     'FACT_ACCOUNT_PAYABLE_GBL',  'CORP_TRAN',   '{{EDW}}',         'FACT_ACCOUNT_PAYABLE_GBL',  'AP transactions',           'Uploaded Excel'),
  ('apdoc',   'Data mart',      'DM_FIN_AP_GBL_DETAILS',     'CORP_DM_FIN', '{{DATAMART}}',    'DM_FIN_AP_GBL_DETAILS',     'AP global details mart',    'Uploaded Excel'),
  ('apdoc',   'SAP table',      'BKPF',                      NULL,          '{{LANDING}}',     'SAP_BKPF',                  'Document header',           'Uploaded Excel'),
  ('apdoc',   'SAP table',      'BSEG',                      NULL,          '{{LANDING}}',     'SAP_BSEG',                  'AP line items',             'Uploaded Excel'),
  ('apdoc',   'SAP table',      'BSET',                      NULL,          NULL,              NULL,                        'Tax data',                  'Uploaded Excel'),
  ('apdoc',   'SAP table',      'T003T',                     NULL,          '{{LANDING}}',     'SAP_T003T',                 'Document type text',        'Uploaded Excel'),
  ('apdoc',   'SAP table',      'BSEC',                      NULL,          '{{LANDING}}',     'SAP_BSEC',                  'One-time vendor data',      'Snowflake Metadata'),
  ('pay',     'SAP table',      'PAYR',                      NULL,          NULL,              NULL,                        'Payments',                  'Uploaded Excel'),
  ('gl',      'SAP table',      'SKAT',                      NULL,          NULL,              NULL,                        'GL account text',           'Uploaded Excel'),
  ('entity',  'EDW object',     'DIM_ENTITY',                'CORP_MASTER', NULL,              NULL,                        'Legal entity',              'Uploaded Excel'),
  ('entity',  'SAP table',      'T001',                      NULL,          '{{LANDING}}',     'SAP_T001',                  'Company codes',             'Snowflake Metadata'),
  ('entity',  'EDW object',     'DIM_COMPANY_CODE',          NULL,          '{{EDW}}',         'DIM_COMPANY_CODE',          'Company code dimension (POC)', 'Snowflake Metadata'),
  ('org',     'EDW object',     'VW_DIM_ORG',                'CORP_REPORT', NULL,              NULL,                        'Organization',              'Uploaded Excel'),
  ('fiscal',  'EDW object',     'TV_TIME_FISCAL_DAY',        'CORP_REF',    NULL,              NULL,                        'Fiscal calendar',           'Uploaded Excel'),
  ('country', 'EDW object',     'TV_DIM_COUNTRY',            'CORP_MASTER', NULL,              NULL,                        'Country',                   'Uploaded Excel'),
  ('country', 'SAP table',      'T005T',                     NULL,          '{{LANDING}}',     'SAP_T005T',                 'Country names',             'Snowflake Metadata'),
  ('rpt',     'Reporting view', 'VW_FIN_AP_CLOSING_BALANCE', 'CORP_REPORT', '{{REPORTING}}',   'VW_FIN_AP_CLOSING_BALANCE', 'Closing balance report',    'Uploaded Excel'),
  ('rpt',     'Reporting view', 'VW_FIN_AP_VENDOR_PAYMENT',  'CORP_REPORT', '{{REPORTING}}',   'VW_FIN_AP_VENDOR_PAYMENT',  'Vendor payment report',     'Uploaded Excel'),
  ('rpt',     'Reporting view', 'VW_FIN_AP_INV_DETAILS',     'CORP_REPORT', '{{REPORTING}}',   'VW_FIN_AP_INV_DETAILS',     'Invoice details report',    'Uploaded Excel');

-- Evidence per object: how many workbook rows read it, and whether it really exists in Snowflake
CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECTS
  COMMENT = 'Business-to-technical map with live evidence: workbook rows that read each object and whether the object exists in Snowflake.' AS
WITH wb AS (
  SELECT m.ENTITY_ID, m.OBJECT_NAME,
         COUNT(DISTINCT IFF(x.SHEET ILIKE 'AP FACT%', x.SHEET_ROW, NULL)) AS FACT_FIELDS_FED,
         COUNT(DISTINCT IFF(x.SHEET ILIKE 'AP DM%',   x.SHEET_ROW, NULL)) AS MART_COLUMNS_FED
  FROM {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECT_MAP m
  LEFT JOIN {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET x
    ON m.EVIDENCE = 'Uploaded Excel'
   AND x.MODEL_NAME <> m.OBJECT_NAME
   AND CONTAINS(UPPER(COALESCE(x.SOURCE_EDW_TABLE, '') || ' ' || COALESCE(x.SOURCE_TABLE, '')), m.OBJECT_NAME)
  GROUP BY 1, 2),
own AS (
  SELECT MODEL_NAME, COUNT(*) AS OWN_FIELDS FROM {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET GROUP BY 1),
sf AS (
  SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE, ROW_COUNT, COMMENT
  FROM {{DATABASE}}.INFORMATION_SCHEMA.TABLES)
SELECT m.ENTITY_ID, e.ENTITY_NAME, m.OBJECT_ROLE, m.OBJECT_NAME, m.FRIENDLY_NAME, m.WORKBOOK_SCHEMA,
       IFF(m.SNOWFLAKE_OBJECT IS NULL, NULL, m.SNOWFLAKE_SCHEMA || '.' || m.SNOWFLAKE_OBJECT) AS SNOWFLAKE_KEY,
       sf.TABLE_NAME IS NOT NULL                    AS IN_SNOWFLAKE,
       IFF(sf.TABLE_TYPE = 'VIEW', 'View', IFF(sf.TABLE_TYPE IS NULL, NULL, 'Table')) AS SNOWFLAKE_TYPE,
       sf.ROW_COUNT                                 AS SNOWFLAKE_ROW_COUNT,
       sf.COMMENT                                   AS SNOWFLAKE_COMMENT,
       m.EVIDENCE,
       COALESCE(own.OWN_FIELDS, 0)                  AS FIELDS_IN_WORKBOOK,
       COALESCE(wb.FACT_FIELDS_FED, 0)              AS FACT_FIELDS_FED,
       COALESCE(wb.MART_COLUMNS_FED, 0)             AS MART_COLUMNS_FED
FROM {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECT_MAP m
JOIN {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY e ON e.ENTITY_ID = m.ENTITY_ID
LEFT JOIN wb  ON wb.ENTITY_ID = m.ENTITY_ID AND wb.OBJECT_NAME = m.OBJECT_NAME
LEFT JOIN own ON own.MODEL_NAME = m.OBJECT_NAME
LEFT JOIN sf  ON sf.TABLE_SCHEMA = m.SNOWFLAKE_SCHEMA AND sf.TABLE_NAME = m.SNOWFLAKE_OBJECT;

-- ---------------------------------------------------------------- relationships between entities
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIP (
  REL_ID           NUMBER  COMMENT 'Relationship ID.',
  FROM_ENTITY      VARCHAR COMMENT 'From entity ID.',
  RELATIONSHIP     VARCHAR COMMENT 'Verb phrase, e.g. posts as.',
  TO_ENTITY        VARCHAR COMMENT 'To entity ID.',
  EVIDENCE_BASIS   VARCHAR COMMENT 'Workbook (rows in the mapping workbook support it), Meeting notes (AP process flow) or Planned.',
  EVIDENCE_OBJECTS VARCHAR COMMENT 'Comma-separated objects whose workbook rows support the relationship.',
  DOMAIN_ID        VARCHAR COMMENT 'Domain the relationship belongs to.'
) COMMENT = 'Relationships between business entities. Workbook-backed ones carry live evidence counts.';

INSERT INTO {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIP VALUES
  ( 1, 'inv',      'posts as',              'apdoc',   'Workbook',      'RSEG',                                'ap'),
  ( 2, 'apdoc',    'references',            'po',      'Workbook',      'FACT_PURCHASE_ORDER,EKKO,EKPO',       'ap'),
  ( 3, 'apdoc',    'is owed to',            'vendor',  'Workbook',      'DIM_VENDOR_GEN,DIM_VENDOR_COMPANY,LFB1', 'ap'),
  ( 4, 'apdoc',    'is settled by',         'pay',     'Workbook',      'PAYR',                                'ap'),
  ( 5, 'apdoc',    'posts to',              'gl',      'Workbook',      'SKAT',                                'ap'),
  ( 6, 'apdoc',    'is booked in',          'entity',  'Workbook',      'DIM_ENTITY',                          'ap'),
  ( 7, 'apdoc',    'belongs to',            'org',     'Workbook',      'VW_DIM_ORG',                          'ap'),
  ( 8, 'apdoc',    'is dated in',           'fiscal',  'Workbook',      'TV_TIME_FISCAL_DAY',                  'ap'),
  ( 9, 'vendor',   'is located in',         'country', 'Workbook',      'TV_DIM_COUNTRY',                      'ap'),
  (10, 'apdoc',    'is reported in',        'rpt',     'Workbook',      'DM_FIN_AP_GBL_DETAILS',               'ap'),
  (11, 'vendor',   'supplies',              'po',      'Meeting notes', NULL,                                  'proc'),
  (12, 'po',       'is received as',        'gr',      'Meeting notes', NULL,                                  'proc'),
  (13, 'gr',       'is matched to (GR/IR)', 'inv',     'Meeting notes', NULL,                                  'ap'),
  (14, 'vendor',   'issues',                'inv',     'Meeting notes', NULL,                                  'ap'),
  (15, 'customer', 'places',                'so',      'Planned',       NULL,                                  'ar'),
  (16, 'so',       'is billed as',          'arinv',   'Planned',       NULL,                                  'ar'),
  (17, 'arinv',    'is settled by',         'cash',    'Planned',       NULL,                                  'ar'),
  (18, 'arinv',    'is booked in',          'entity',  'Planned',       NULL,                                  'ar'),
  (19, 'arinv',    'is dated in',           'fiscal',  'Planned',       NULL,                                  'ar'),
  (20, 'customer', 'is located in',         'country', 'Planned',       NULL,                                  'ar'),
  (21, 'je',       'posts to',              'gl',      'Planned',       NULL,                                  'gl'),
  (22, 'je',       'charges',               'cc',      'Planned',       NULL,                                  'gl'),
  (23, 'je',       'is booked in',          'entity',  'Planned',       NULL,                                  'gl'),
  (24, 'je',       'is dated in',           'fiscal',  'Planned',       NULL,                                  'gl'),
  (25, 'cc',       'rolls up to',           'org',     'Planned',       NULL,                                  'gl'),
  (26, 'mat',      'is ordered on',         'po',      'Planned',       NULL,                                  'proc');

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIPS
  COMMENT = 'Entity relationships with live evidence from the mapping workbook: fact fields, mart columns and view columns that support each one.' AS
WITH obj AS (
  SELECT r.REL_ID, TRIM(s.VALUE) AS OBJECT_NAME
  FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIP r,
       LATERAL SPLIT_TO_TABLE(COALESCE(r.EVIDENCE_OBJECTS, ''), ',') s
  WHERE TRIM(s.VALUE) <> ''),
wb AS (
  SELECT o.REL_ID, o.OBJECT_NAME,
         COUNT(DISTINCT IFF(x.SHEET ILIKE 'AP FACT%', x.SHEET_ROW, NULL)) AS FACT_FIELDS,
         COUNT(DISTINCT IFF(x.SHEET ILIKE 'AP DM%',   x.SHEET_ROW, NULL)) AS MART_COLUMNS
  FROM obj o
  LEFT JOIN {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET x
    ON x.MODEL_NAME <> o.OBJECT_NAME
   AND CONTAINS(UPPER(COALESCE(x.SOURCE_EDW_TABLE, '') || ' ' || COALESCE(x.SOURCE_TABLE, '')), o.OBJECT_NAME)
  GROUP BY 1, 2),
vw AS (
  SELECT o.REL_ID, o.OBJECT_NAME, COUNT(f.TARGET_COLUMN) AS VIEW_COLUMNS
  FROM obj o
  LEFT JOIN {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING f
    ON f.TARGET_LAYER = 'Reporting' AND CONTAINS(UPPER(f.SOURCE_OBJECT), o.OBJECT_NAME)
  GROUP BY 1, 2),
ev AS (
  SELECT wb.REL_ID,
         SUM(wb.FACT_FIELDS + wb.MART_COLUMNS + COALESCE(vw.VIEW_COLUMNS, 0)) AS EVIDENCE_ROWS,
         LISTAGG(IFF(wb.FACT_FIELDS + wb.MART_COLUMNS + COALESCE(vw.VIEW_COLUMNS, 0) = 0, NULL,
                 wb.OBJECT_NAME || ' feeds ' || ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
                   IFF(wb.FACT_FIELDS  > 0, wb.FACT_FIELDS  || ' fact fields',  NULL),
                   IFF(wb.MART_COLUMNS > 0, wb.MART_COLUMNS || ' mart columns', NULL),
                   IFF(vw.VIEW_COLUMNS > 0, vw.VIEW_COLUMNS || ' view columns', NULL)), ', ')), '; ')
           WITHIN GROUP (ORDER BY wb.OBJECT_NAME) AS EVIDENCE_DETAIL
  FROM wb LEFT JOIN vw ON vw.REL_ID = wb.REL_ID AND vw.OBJECT_NAME = wb.OBJECT_NAME
  GROUP BY 1)
SELECT r.REL_ID, r.FROM_ENTITY, f.ENTITY_NAME AS FROM_NAME, r.RELATIONSHIP, r.TO_ENTITY, t.ENTITY_NAME AS TO_NAME,
       r.DOMAIN_ID, r.EVIDENCE_BASIS, r.EVIDENCE_OBJECTS,
       COALESCE(ev.EVIDENCE_ROWS, 0) AS EVIDENCE_ROWS,
       CASE WHEN r.EVIDENCE_BASIS = 'Workbook' AND COALESCE(ev.EVIDENCE_ROWS, 0) > 0 THEN 'Supported by workbook'
            WHEN r.EVIDENCE_BASIS = 'Workbook' THEN 'Not found in loaded workbook'
            ELSE 'Proposed' END AS EVIDENCE_STATUS,
       CASE WHEN r.EVIDENCE_BASIS = 'Workbook' THEN COALESCE(NULLIF(ev.EVIDENCE_DETAIL, ''), 'No workbook rows reference ' || r.EVIDENCE_OBJECTS)
            WHEN r.EVIDENCE_BASIS = 'Meeting notes' THEN 'AP process flow from the meeting notes (no tables loaded yet)'
            ELSE 'Proposed for a planned domain' END AS EVIDENCE_DETAIL,
       IFF(r.EVIDENCE_BASIS = 'Workbook' AND COALESCE(ev.EVIDENCE_ROWS, 0) > 0, 'solid', 'dashed') AS LINE_STYLE
FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIP r
JOIN {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY f ON f.ENTITY_ID = r.FROM_ENTITY
JOIN {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY t ON t.ENTITY_ID = r.TO_ENTITY
LEFT JOIN ev ON ev.REL_ID = r.REL_ID;

-- ---------------------------------------------------------------- process context (L1 - L3)
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_PROCESS_STEP (
  PROCESS_L1 VARCHAR COMMENT 'Level 1 process, e.g. Procure-to-Pay.',
  PROCESS_L2 VARCHAR COMMENT 'Level 2 process, e.g. Accounts Payable.',
  PROCESS_L3 VARCHAR COMMENT 'Level 3 process, e.g. Vendor to AP document.',
  STEP_NO    NUMBER  COMMENT 'Order of the step.',
  STEP_NAME  VARCHAR COMMENT 'Process step, e.g. Goods receipt.',
  ENTITY_ID  VARCHAR COMMENT 'Business entity created or used by the step.',
  NOTE       VARCHAR COMMENT 'Note shown with the step.'
) COMMENT = 'AP process context: illustrative L1-L3 flow, to be replaced by the customer AP entity list.';

INSERT INTO {{DATABASE}}.{{KF}}.KF_PROCESS_STEP VALUES
  ('Procure-to-Pay', 'Accounts Payable', 'Vendor to AP document', 1, 'Vendor creation', 'vendor', NULL),
  ('Procure-to-Pay', 'Accounts Payable', 'Vendor to AP document', 2, 'Purchase order',  'po',     NULL),
  ('Procure-to-Pay', 'Accounts Payable', 'Vendor to AP document', 3, 'Goods receipt',   'gr',     'GR / GR-IR tables are not in the loaded data'),
  ('Procure-to-Pay', 'Accounts Payable', 'Vendor to AP document', 4, 'Vendor invoice',  'inv',    NULL),
  ('Procure-to-Pay', 'Accounts Payable', 'Vendor to AP document', 5, 'AP document',     'apdoc',  NULL);

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_PROCESS_COVERAGE
  COMMENT = 'AP process steps with the workbook objects and Snowflake objects behind each step, and gaps (not in loaded data).' AS
SELECT p.PROCESS_L1, p.PROCESS_L2, p.PROCESS_L3, p.STEP_NO, p.STEP_NAME, p.ENTITY_ID, e.ENTITY_NAME,
       LISTAGG(DISTINCT IFF(o.EVIDENCE = 'Uploaded Excel', o.OBJECT_NAME, NULL), ', ') AS WORKBOOK_OBJECTS,
       LISTAGG(DISTINCT IFF(o.IN_SNOWFLAKE, o.SNOWFLAKE_KEY, NULL), ', ')             AS SNOWFLAKE_OBJECTS,
       IFF(COUNT_IF(o.EVIDENCE = 'Uploaded Excel') = 0, 'Gap', 'Covered')              AS STEP_STATUS,
       COALESCE(p.NOTE, IFF(COUNT_IF(o.EVIDENCE = 'Uploaded Excel') = 0, 'Not in loaded data', NULL)) AS NOTE
FROM {{DATABASE}}.{{KF}}.KF_PROCESS_STEP p
JOIN {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY e ON e.ENTITY_ID = p.ENTITY_ID
LEFT JOIN {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECTS o ON o.ENTITY_ID = p.ENTITY_ID
GROUP BY p.PROCESS_L1, p.PROCESS_L2, p.PROCESS_L3, p.STEP_NO, p.STEP_NAME, p.ENTITY_ID, e.ENTITY_NAME, p.NOTE;

-- ---------------------------------------------------------------- uploaded Word documents (kept across re-runs)
CREATE TABLE IF NOT EXISTS {{DATABASE}}.{{KF}}.KF_UPLOADED_DOCUMENTS (
  DOC_ID      VARCHAR COMMENT 'Document ID.',
  FILE_NAME   VARCHAR COMMENT 'Uploaded file name.',
  DOC_TITLE   VARCHAR COMMENT 'Title (first heading or file name).',
  DOC_KIND    VARCHAR COMMENT 'Word.',
  IS_SAMPLE   BOOLEAN COMMENT 'TRUE for the POC sample narrative.',
  PARAGRAPHS  NUMBER  COMMENT 'Number of paragraphs read.',
  UPLOADED_BY VARCHAR COMMENT 'Snowflake user who uploaded it.',
  UPLOADED_AT TIMESTAMP_LTZ,
  DOC_STATUS  VARCHAR COMMENT 'Loaded or Sample.'
) COMMENT = 'Word documents uploaded in the app (process narratives, SOPs). Metadata source: Uploaded Word Document.';

CREATE TABLE IF NOT EXISTS {{DATABASE}}.{{KF}}.KF_UPLOADED_DOC_PARAGRAPHS (
  DOC_ID      VARCHAR COMMENT 'Document ID.',
  PARA_NO     NUMBER  COMMENT 'Paragraph number in the document.',
  PARA_TEXT   VARCHAR COMMENT 'Paragraph text.',
  ENTITY_HINT VARCHAR COMMENT 'Entity the paragraph is about, when known (otherwise matched by entity synonyms).'
) COMMENT = 'Paragraphs of uploaded Word documents, searchable and linked to business entities.';

DELETE FROM {{DATABASE}}.{{KF}}.KF_UPLOADED_DOCUMENTS      WHERE DOC_ID = 'SAMPLE_AP_PROCESS';
DELETE FROM {{DATABASE}}.{{KF}}.KF_UPLOADED_DOC_PARAGRAPHS WHERE DOC_ID = 'SAMPLE_AP_PROCESS';

INSERT INTO {{DATABASE}}.{{KF}}.KF_UPLOADED_DOCUMENTS
SELECT 'SAMPLE_AP_PROCESS', 'AP_Process_Narrative_sample.docx', 'AP process narrative (sample)', 'Word', TRUE, 8,
       'POC sample', CURRENT_TIMESTAMP(), 'Sample';

INSERT INTO {{DATABASE}}.{{KF}}.KF_UPLOADED_DOC_PARAGRAPHS VALUES
  ('SAMPLE_AP_PROCESS', 1, 'A vendor is created and approved before any purchase order can be raised.', 'vendor'),
  ('SAMPLE_AP_PROCESS', 2, 'A purchase order is raised against an approved vendor.', 'po'),
  ('SAMPLE_AP_PROCESS', 3, 'Goods are received against the purchase order, which updates the GR/IR clearing account.', 'gr'),
  ('SAMPLE_AP_PROCESS', 4, 'The vendor invoice is matched to the purchase order and goods receipt.', 'inv'),
  ('SAMPLE_AP_PROCESS', 5, 'Posting the invoice creates the AP document and the open liability.', 'apdoc'),
  ('SAMPLE_AP_PROCESS', 6, 'Payment clears the AP document at or after its due date.', 'pay'),
  ('SAMPLE_AP_PROCESS', 7, 'Each AP document is booked in a legal entity (company code) and dated in the fiscal calendar.', 'entity'),
  ('SAMPLE_AP_PROCESS', 8, 'Finance users read AP data in Tableau through the AP reporting views, which read the data mart only.', 'rpt');

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_ENTITY_NARRATIVE
  COMMENT = 'Word document paragraphs per business entity (by explicit hint, or by entity synonyms found in the text).' AS
WITH words AS (
  SELECT p.*, ' ' || TRIM(REGEXP_REPLACE(LOWER(p.PARA_TEXT), '[^a-z0-9/]+', ' ')) || ' ' AS NORM_TEXT
  FROM {{DATABASE}}.{{KF}}.KF_UPLOADED_DOC_PARAGRAPHS p),
syn AS (
  SELECT e.ENTITY_ID, TRIM(LOWER(s.VALUE)) AS SYNONYM
  FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY e, LATERAL SPLIT_TO_TABLE(e.SYNONYMS, ',') s),
hits AS (
  SELECT w.DOC_ID, w.PARA_NO, w.PARA_TEXT, w.ENTITY_HINT AS ENTITY_ID, 'Named in document' AS MATCHED_BY
  FROM words w WHERE w.ENTITY_HINT IS NOT NULL
  UNION
  SELECT w.DOC_ID, w.PARA_NO, w.PARA_TEXT, s.ENTITY_ID, 'Synonym: ' || MIN(s.SYNONYM)
  FROM words w JOIN syn s ON CONTAINS(w.NORM_TEXT, ' ' || s.SYNONYM || ' ')
  WHERE w.ENTITY_HINT IS NULL
  GROUP BY w.DOC_ID, w.PARA_NO, w.PARA_TEXT, s.ENTITY_ID)
SELECT h.ENTITY_ID, h.DOC_ID, d.FILE_NAME, d.DOC_TITLE, d.IS_SAMPLE, d.DOC_STATUS, h.PARA_NO, h.PARA_TEXT, h.MATCHED_BY
FROM hits h JOIN {{DATABASE}}.{{KF}}.KF_UPLOADED_DOCUMENTS d ON d.DOC_ID = h.DOC_ID;

-- ---------------------------------------------------------------- Draft & Approve table (also created by the app)
CREATE TABLE IF NOT EXISTS {{DATABASE}}.{{KF}}.KF_DESCRIPTION_APPROVALS (
  MODEL_NAME VARCHAR, FIELD_NAME VARCHAR, SUGGESTED_TEXT VARCHAR, FINAL_TEXT VARCHAR,
  STATUS VARCHAR COMMENT 'Draft, Approved or Rejected', EVIDENCE VARCHAR,
  SUGGESTED_BY VARCHAR, SUGGESTED_AT TIMESTAMP_LTZ, DECIDED_BY VARCHAR, DECIDED_AT TIMESTAMP_LTZ,
  BUSINESS_NAME VARCHAR, CONFIDENCE VARCHAR, BASIS VARCHAR, PROFILE VARCHAR
) COMMENT = 'Draft & Approve: AI-suggested business descriptions and the business owner decision';
ALTER TABLE {{DATABASE}}.{{KF}}.KF_DESCRIPTION_APPROVALS ADD COLUMN IF NOT EXISTS BUSINESS_NAME VARCHAR;
ALTER TABLE {{DATABASE}}.{{KF}}.KF_DESCRIPTION_APPROVALS ADD COLUMN IF NOT EXISTS CONFIDENCE VARCHAR;
ALTER TABLE {{DATABASE}}.{{KF}}.KF_DESCRIPTION_APPROVALS ADD COLUMN IF NOT EXISTS BASIS VARCHAR;
ALTER TABLE {{DATABASE}}.{{KF}}.KF_DESCRIPTION_APPROVALS ADD COLUMN IF NOT EXISTS PROFILE VARCHAR;

CREATE TABLE IF NOT EXISTS {{DATABASE}}.{{KF}}.KF_QUESTION_LOG (
  QUESTION VARCHAR, ASKED_BY VARCHAR, APP_ROLE VARCHAR, ASKED_AT TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
) COMMENT = 'Questions asked in the app (recent questions and usage counts)';

-- ---------------------------------------------------------------- field provenance: which source says what, per field
CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE
  COMMENT = 'One row per workbook field (fact and data mart): business entity, transformation type, SAP origin, definition status and which metadata sources hold information about it.' AS
WITH x AS (
  SELECT * FROM {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET),
fact AS (
  SELECT FIELD_NAME, BUSINESS_NAME, DEFINITION, SOURCE_TABLE, SOURCE_FIELD, MAPPING
  FROM x WHERE SHEET ILIKE 'AP FACT%'),
ent AS (
  SELECT x.SHEET, x.SHEET_ROW, m.ENTITY_ID
  FROM x JOIN {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECT_MAP m
    ON m.EVIDENCE = 'Uploaded Excel' AND m.OBJECT_ROLE IN ('EDW object', 'SAP table') AND x.MODEL_NAME <> m.OBJECT_NAME
   AND CONTAINS(UPPER(COALESCE(x.SOURCE_EDW_TABLE, '') || ' ' || COALESCE(x.SOURCE_TABLE, '')), m.OBJECT_NAME)
  QUALIFY ROW_NUMBER() OVER (PARTITION BY x.SHEET, x.SHEET_ROW ORDER BY IFF(m.ENTITY_ID = 'apdoc', 1, 0), m.OBJECT_NAME) = 1),
cols AS (
  SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, COMMENT
  FROM {{DATABASE}}.INFORMATION_SCHEMA.COLUMNS),
apv AS (
  SELECT MODEL_NAME, FIELD_NAME, STATUS, BUSINESS_NAME, FINAL_TEXT
  FROM {{DATABASE}}.{{KF}}.KF_DESCRIPTION_APPROVALS
  QUALIFY ROW_NUMBER() OVER (PARTITION BY MODEL_NAME, FIELD_NAME ORDER BY COALESCE(DECIDED_AT, SUGGESTED_AT) DESC NULLS LAST) = 1),
narr AS (
  SELECT DISTINCT ENTITY_ID FROM {{DATABASE}}.{{KF}}.KF_ENTITY_NARRATIVE)
SELECT x.SHEET, x.SHEET_ROW, x.LAYER, x.SCHEMA_NAME, x.MODEL_NAME, x.FIELD_NAME,
       COALESCE(IFF(apv.STATUS = 'Approved', apv.BUSINESS_NAME, NULL), NULLIF(x.BUSINESS_NAME, '')) AS BUSINESS_NAME,
       COALESCE(ent.ENTITY_ID, 'apdoc') AS ENTITY_ID,
       x.SOURCE_SYSTEM, x.SOURCE_EDW_TABLE, x.SOURCE_TABLE, x.SOURCE_FIELD, x.MAPPING,
       CASE WHEN x.SHEET ILIKE 'AP FACT%' THEN IFF(COALESCE(x.MAPPING, '') IN ('', 'Direct Mapping'), 'Direct (from SAP)', 'Rule / calculation')
            WHEN x.SOURCE_EDW_TABLE ILIKE 'Calculated%' THEN 'Calculated'
            WHEN CONTAINS(COALESCE(x.SOURCE_EDW_TABLE, ''), '&') THEN 'Join (multi-source)'
            WHEN x.SOURCE_EDW_TABLE ILIKE '%FACT_ACCOUNT_PAYABLE_GBL%'
              THEN IFF(COALESCE(x.MAPPING, '') IN ('', 'Direct Mapping'), 'Direct (pass-through)', 'Direct with rule')
            WHEN COALESCE(x.SOURCE_EDW_TABLE, '') = '' THEN 'Unspecified'
            ELSE 'Join / lookup' END AS TRANSFORMATION_TYPE,
       f.FIELD_NAME AS FACT_FIELD,
       CASE WHEN x.SHEET ILIKE 'AP FACT%' AND COALESCE(x.SOURCE_TABLE, '') <> ''
              THEN x.SOURCE_TABLE || IFF(COALESCE(x.SOURCE_FIELD, '') <> '', '.' || x.SOURCE_FIELD, '')
            WHEN x.SHEET ILIKE 'AP FACT%'
              THEN ARRAY_TO_STRING(ARRAY_SLICE(ARRAY_DISTINCT(REGEXP_SUBSTR_ALL(x.MAPPING, '[A-Z][A-Z0-9_]{2,}\\.[A-Z][A-Z0-9_]{2,}')), 0, 5), '; ')
            WHEN COALESCE(f.SOURCE_TABLE, '') <> ''
              THEN f.SOURCE_TABLE || IFF(COALESCE(f.SOURCE_FIELD, '') <> '', '.' || f.SOURCE_FIELD, '')
            WHEN f.FIELD_NAME IS NOT NULL
              THEN ARRAY_TO_STRING(ARRAY_SLICE(ARRAY_DISTINCT(REGEXP_SUBSTR_ALL(f.MAPPING, '[A-Z][A-Z0-9_]{2,}\\.[A-Z][A-Z0-9_]{2,}')), 0, 5), '; ')
            ELSE NULL END AS SAP_ORIGIN,
       CASE WHEN apv.STATUS = 'Approved' THEN apv.FINAL_TEXT
            WHEN COALESCE(x.DEFINITION, '') <> '' THEN x.DEFINITION
            WHEN COALESCE(f.DEFINITION, '') <> '' THEN f.DEFINITION END AS BUSINESS_DEFINITION,
       CASE WHEN apv.STATUS = 'Approved' THEN 'Approved'
            WHEN COALESCE(x.DEFINITION, '') <> '' THEN 'Documented in workbook'
            WHEN COALESCE(f.DEFINITION, '') <> '' THEN 'Draft (inherited from fact field)'
            WHEN apv.STATUS = 'Draft' THEN 'Draft (pending approval)'
            ELSE 'Missing' END AS DEFINITION_STATUS,
       c.COLUMN_NAME IS NOT NULL AS IN_SNOWFLAKE,
       CASE WHEN c.DATA_TYPE IS NULL THEN NULL
            WHEN c.CHARACTER_MAXIMUM_LENGTH IS NOT NULL
              THEN IFF(c.DATA_TYPE = 'TEXT', 'VARCHAR', c.DATA_TYPE) || '(' || c.CHARACTER_MAXIMUM_LENGTH || ')'
            WHEN c.DATA_TYPE = 'NUMBER' THEN 'NUMBER(' || c.NUMERIC_PRECISION || ',' || c.NUMERIC_SCALE || ')'
            ELSE c.DATA_TYPE END AS SNOWFLAKE_DATA_TYPE,
       c.COMMENT AS SNOWFLAKE_COMMENT,
       narr.ENTITY_ID IS NOT NULL AS HAS_WORD_NARRATIVE,
       ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
         IFF(c.COLUMN_NAME IS NOT NULL, 'Snowflake Metadata', NULL),
         'Uploaded Excel',
         IFF(narr.ENTITY_ID IS NOT NULL, 'Uploaded Word Document', NULL),
         'Business Glossary',
         IFF(apv.STATUS = 'Approved', 'Draft & Approve', NULL)), ' · ') AS METADATA_SOURCES,
       IFF(x.SHEET ILIKE 'AP FACT%', 'AP_Fact_Mapping', 'AP_DM_Mapping') || ' row ' || x.SHEET_ROW AS CITATION
FROM x
LEFT JOIN fact f ON x.SHEET ILIKE 'AP DM%' AND x.SOURCE_EDW_TABLE ILIKE '%FACT_ACCOUNT_PAYABLE_GBL%'
                AND NOT CONTAINS(COALESCE(x.SOURCE_EDW_TABLE, ''), '&') AND f.FIELD_NAME = UPPER(x.SOURCE_FIELD)
LEFT JOIN ent  ON ent.SHEET = x.SHEET AND ent.SHEET_ROW = x.SHEET_ROW
LEFT JOIN cols c ON c.TABLE_SCHEMA = x.SCHEMA_NAME AND c.TABLE_NAME = x.MODEL_NAME AND c.COLUMN_NAME = x.FIELD_NAME
LEFT JOIN apv  ON apv.MODEL_NAME = x.MODEL_NAME AND apv.FIELD_NAME = x.FIELD_NAME
LEFT JOIN narr ON narr.ENTITY_ID = COALESCE(ent.ENTITY_ID, 'apdoc');

-- ---------------------------------------------------------------- metadata sources (live status)
CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_METADATA_SOURCE_REGISTRY (
  SOURCE_KEY  VARCHAR COMMENT 'sf, xls, doc, glo.',
  SOURCE_NAME VARCHAR COMMENT 'Snowflake Metadata, Uploaded Excel, Uploaded Word Document, Business Glossary.',
  PROVIDES    VARCHAR COMMENT 'What this source contributes to answers.',
  OWNER_ROLE  VARCHAR COMMENT 'Who maintains it (role).',
  PRECEDENCE  NUMBER  COMMENT '1 = most trusted when sources disagree.'
) COMMENT = 'The four metadata sources shown in the app header (metadata source transparency).';

INSERT INTO {{DATABASE}}.{{KF}}.KF_METADATA_SOURCE_REGISTRY VALUES
  ('sf',  'Snowflake Metadata',     'Tables, views, columns, data types, comments, tags, masking, keys, tasks and lineage, read live from the account.', 'EDW Platform Team (role)', 1),
  ('glo', 'Business Glossary',      'Business entity and term definitions with owner and approval status.', 'AP Finance Data Owner (role)', 2),
  ('xls', 'Uploaded Excel',         'AP FACT and AP DM mapping sheets: business names, definitions, SAP source tables and fields, mapping rules.', 'AP Data Steward (role)', 3),
  ('doc', 'Uploaded Word Document', 'Process narratives and SOPs: how the AP process works and why.', 'AP Process Owner (role)', 4);

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_METADATA_SOURCES
  COMMENT = 'Live status of each metadata source: Connected / Loaded / Sample, with item counts.' AS
WITH sf AS (
  SELECT COUNT(DISTINCT t.TABLE_SCHEMA || '.' || t.TABLE_NAME) AS N_OBJECTS
  FROM {{DATABASE}}.INFORMATION_SCHEMA.TABLES t
  WHERE t.TABLE_SCHEMA IN ('{{LANDING}}', '{{EDW}}', '{{DATAMART}}', '{{REPORTING}}')),
sfc AS (
  SELECT COUNT(*) AS N_COLUMNS, COUNT_IF(COALESCE(COMMENT, '') <> '') AS N_COMMENTED
  FROM {{DATABASE}}.INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA IN ('{{LANDING}}', '{{EDW}}', '{{DATAMART}}', '{{REPORTING}}')),
xls AS (
  SELECT COUNT(*) AS N_ROWS, COUNT_IF(SHEET ILIKE 'AP FACT%') AS N_FACT, COUNT_IF(SHEET ILIKE 'AP DM%') AS N_DM
  FROM {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET),
doc AS (
  SELECT COUNT(*) AS N_DOCS, COUNT_IF(NOT IS_SAMPLE) AS N_REAL, COALESCE(SUM(PARAGRAPHS), 0) AS N_PARAS
  FROM {{DATABASE}}.{{KF}}.KF_UPLOADED_DOCUMENTS WHERE DOC_KIND = 'Word'),
glo AS (
  SELECT (SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY) AS N_ENTITIES,
         (SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_GLOSSARY) AS N_TERMS,
         (SELECT COUNT_IF(STATUS = 'Approved') FROM {{DATABASE}}.{{KF}}.KF_GLOSSARY) AS N_APPROVED)
SELECT r.SOURCE_KEY, r.SOURCE_NAME, r.PRECEDENCE,
       CASE r.SOURCE_KEY
         WHEN 'sf'  THEN IFF(sf.N_OBJECTS > 0, 'Connected', 'Not connected')
         WHEN 'xls' THEN IFF(xls.N_ROWS > 0, 'Loaded', 'Not loaded')
         WHEN 'doc' THEN IFF(doc.N_REAL > 0, 'Loaded', IFF(doc.N_DOCS > 0, 'Sample', 'Not loaded'))
         WHEN 'glo' THEN 'Sample' END AS SOURCE_STATUS,
       CASE r.SOURCE_KEY
         WHEN 'sf'  THEN sf.N_OBJECTS || ' tables and views, ' || sfc.N_COLUMNS || ' columns (' || sfc.N_COMMENTED || ' with comments), read live'
         WHEN 'xls' THEN xls.N_ROWS || ' rows: AP FACT Table Mapping Sheet (' || xls.N_FACT || ') and AP DM Table Mapping Sheet (' || xls.N_DM || ')'
         WHEN 'doc' THEN doc.N_DOCS || ' document(s), ' || doc.N_PARAS || ' paragraphs' || IFF(doc.N_REAL > 0, '', ' (POC sample narrative; upload the real one in the app)')
         WHEN 'glo' THEN glo.N_ENTITIES || ' entity definitions and ' || glo.N_TERMS || ' AP terms (' || glo.N_APPROVED || ' approved); POC sample, to be replaced by the customer glossary' END AS DETAIL,
       r.PROVIDES, r.OWNER_ROLE
FROM {{DATABASE}}.{{KF}}.KF_METADATA_SOURCE_REGISTRY r, sf, sfc, xls, doc, glo;

-- ---------------------------------------------------------------- the five exportable reports
CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_RPT_SOURCE_TO_TARGET
  COMMENT = 'Report: source-to-target mapping for DM_FIN_AP_GBL_DETAILS (one row per mart column).' AS
SELECT ROW_NUMBER() OVER (ORDER BY SHEET_ROW) AS ROW_NO,
       SCHEMA_NAME || '.' || MODEL_NAME AS TARGET_TABLE, FIELD_NAME AS TARGET_COLUMN,
       SOURCE_EDW_TABLE AS SOURCE_OBJECT, SOURCE_FIELD, TRANSFORMATION_TYPE, MAPPING AS TRANSFORMATION_RULE,
       SAP_ORIGIN, BUSINESS_DEFINITION, DEFINITION_STATUS, SNOWFLAKE_DATA_TYPE, IN_SNOWFLAKE,
       METADATA_SOURCES AS METADATA_SOURCE, CITATION
FROM {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE
WHERE MODEL_NAME = 'DM_FIN_AP_GBL_DETAILS';

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_RPT_COLUMN_LINEAGE
  COMMENT = 'Report: column-level lineage SAP -> fact -> data mart -> reporting views (one row per mart column).' AS
WITH names AS (
  SELECT DISTINCT FIELD_NAME FROM {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET),
calc AS (
  SELECT p.FIELD_NAME, LISTAGG(DISTINCT t.VALUE::STRING, '; ') WITHIN GROUP (ORDER BY t.VALUE::STRING) AS INPUTS
  FROM {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE p,
       LATERAL FLATTEN(INPUT => REGEXP_SUBSTR_ALL(UPPER(p.MAPPING), '[A-Z][A-Z0-9_]{2,}')) t
  WHERE p.MODEL_NAME = 'DM_FIN_AP_GBL_DETAILS' AND p.TRANSFORMATION_TYPE = 'Calculated'
    AND t.VALUE::STRING <> p.FIELD_NAME
    AND t.VALUE::STRING IN (SELECT FIELD_NAME FROM names)
  GROUP BY p.FIELD_NAME),
views AS (
  SELECT SOURCE_COLUMN, LISTAGG(DISTINCT SPLIT_PART(TARGET_OBJECT, '.', 2), ', ') WITHIN GROUP (ORDER BY SPLIT_PART(TARGET_OBJECT, '.', 2)) AS REPORTING_VIEWS
  FROM {{DATABASE}}.{{KF}}.KF_FIELD_MAPPING
  WHERE TARGET_LAYER = 'Reporting' AND SOURCE_OBJECT ILIKE '%DM_FIN_AP_GBL_DETAILS'
  GROUP BY SOURCE_COLUMN)
SELECT p.FIELD_NAME AS MART_COLUMN,
       COALESCE(p.SAP_ORIGIN, IFF(p.TRANSFORMATION_TYPE = 'Calculated', NULL, p.SOURCE_EDW_TABLE || '.' || p.SOURCE_FIELD)) AS SAP_SOURCE,
       p.FACT_FIELD, calc.INPUTS AS CALCULATION_INPUTS,
       NULLIF(RTRIM(TRIM(REGEXP_SUBSTR(p.MAPPING, ' [Oo][Nn] ([A-Z_,& ]+)', 1, 1, 'e', 1)), ', &'), '') AS JOIN_KEYS,
       views.REPORTING_VIEWS, p.TRANSFORMATION_TYPE, p.IN_SNOWFLAKE,
       'Mapping sheet, ' || p.CITATION AS EVIDENCE,
       'Traced from the mapping workbook' || IFF(p.IN_SNOWFLAKE, '; column verified in Snowflake', '; column not found in Snowflake') AS METHOD_NOTE
FROM {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE p
LEFT JOIN calc  ON calc.FIELD_NAME = p.FIELD_NAME
LEFT JOIN views ON views.SOURCE_COLUMN = p.FIELD_NAME
WHERE p.MODEL_NAME = 'DM_FIN_AP_GBL_DETAILS';

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_RPT_ENTITY_OBJECT_MAP
  COMMENT = 'Report: business entity to technical object map.' AS
WITH o AS (
  SELECT ENTITY_ID,
         LISTAGG(DISTINCT IFF(OBJECT_ROLE <> 'SAP table' AND EVIDENCE = 'Uploaded Excel', OBJECT_NAME, NULL), '; ') AS EDW_OBJECTS,
         LISTAGG(DISTINCT IFF(OBJECT_ROLE = 'SAP table' AND EVIDENCE = 'Uploaded Excel', OBJECT_NAME, NULL), '; ')  AS SAP_TABLES,
         LISTAGG(DISTINCT IFF(IN_SNOWFLAKE, SNOWFLAKE_KEY, NULL), '; ')                                             AS SNOWFLAKE_OBJECTS,
         COUNT_IF(EVIDENCE = 'Uploaded Excel') AS WB_OBJECTS
  FROM {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECTS GROUP BY ENTITY_ID),
f AS (
  SELECT ENTITY_ID, COUNT_IF(SHEET ILIKE 'AP FACT%') AS FACT_FIELDS, COUNT_IF(SHEET ILIKE 'AP DM%') AS MART_COLUMNS
  FROM {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE GROUP BY ENTITY_ID)
SELECT e.ENTITY_NAME AS ENTITY, e.ENTITY_TYPE, e.DOMAINS, e.BUSINESS_DEFINITION, e.DEFINITION_STATUS,
       o.EDW_OBJECTS, o.SAP_TABLES, o.SNOWFLAKE_OBJECTS,
       COALESCE(f.FACT_FIELDS, 0) AS FACT_FIELDS, COALESCE(f.MART_COLUMNS, 0) AS MART_COLUMNS,
       CASE WHEN e.ENTITY_STATUS = 'Planned' THEN 'Planned, no metadata yet'
            WHEN COALESCE(o.WB_OBJECTS, 0) > 0 THEN 'Metadata loaded'
            ELSE 'No tables in workbook' END AS STATUS,
       e.OWNER_ROLE
FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITY e
LEFT JOIN o ON o.ENTITY_ID = e.ENTITY_ID
LEFT JOIN f ON f.ENTITY_ID = e.ENTITY_ID
ORDER BY e.SORT_ORDER;

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_RPT_ENTITY_RELATIONSHIPS
  COMMENT = 'Report: business entity relationships with evidence.' AS
SELECT FROM_NAME AS FROM_ENTITY, RELATIONSHIP, TO_NAME AS TO_ENTITY, DOMAIN_ID AS DOMAIN, EVIDENCE_STATUS AS EVIDENCE,
       EVIDENCE_DETAIL AS DETAIL, EVIDENCE_ROWS
FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIPS
ORDER BY REL_ID;

CREATE OR REPLACE VIEW {{DATABASE}}.{{KF}}.KF_RPT_METADATA_SOURCES
  COMMENT = 'Report: metadata source transparency and completeness (coverage per attribute).' AS
WITH p AS (SELECT * FROM {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE),
cov AS (
  SELECT 1 AS N, 'Fact: business name' AS ITEM, COUNT_IF(COALESCE(BUSINESS_NAME, '') <> '') AS COVERED, COUNT(*) AS TOTAL, 'Uploaded Excel' AS SRC FROM p WHERE SHEET ILIKE 'AP FACT%'
  UNION ALL SELECT 2, 'Fact: business definition', COUNT_IF(COALESCE(BUSINESS_DEFINITION, '') <> ''), COUNT(*), 'Uploaded Excel' FROM p WHERE SHEET ILIKE 'AP FACT%'
  UNION ALL SELECT 3, 'Fact: SAP origin traced', COUNT_IF(COALESCE(SAP_ORIGIN, '') <> ''), COUNT(*), 'Uploaded Excel' FROM p WHERE SHEET ILIKE 'AP FACT%'
  UNION ALL SELECT 4, 'Fact: mapping rule', COUNT_IF(COALESCE(MAPPING, '') <> ''), COUNT(*), 'Uploaded Excel' FROM p WHERE SHEET ILIKE 'AP FACT%'
  UNION ALL SELECT 5, 'Data mart: rule or pass-through documented', COUNT_IF(COALESCE(MAPPING, '') <> '' OR TRANSFORMATION_TYPE = 'Direct (pass-through)'), COUNT(*), 'Uploaded Excel' FROM p WHERE SHEET ILIKE 'AP DM%'
  UNION ALL SELECT 6, 'Data mart: source object', COUNT_IF(COALESCE(SOURCE_EDW_TABLE, '') <> ''), COUNT(*), 'Uploaded Excel' FROM p WHERE SHEET ILIKE 'AP DM%'
  UNION ALL SELECT 7, 'Data mart: business definition (documented or approved)', COUNT_IF(DEFINITION_STATUS IN ('Approved', 'Documented in workbook')), COUNT(*), 'Uploaded Excel · Draft & Approve' FROM p WHERE SHEET ILIKE 'AP DM%'
  UNION ALL SELECT 8, 'Data mart: business definition approved in the app', COUNT_IF(DEFINITION_STATUS = 'Approved'), COUNT(*), 'Draft & Approve' FROM p WHERE SHEET ILIKE 'AP DM%'
  UNION ALL SELECT 9, 'Snowflake: workbook fields found as columns', COUNT_IF(IN_SNOWFLAKE), COUNT(*), 'Snowflake Metadata' FROM p
  UNION ALL SELECT 10, 'Snowflake: data type and length', COUNT_IF(SNOWFLAKE_DATA_TYPE IS NOT NULL), COUNT(*), 'Snowflake Metadata' FROM p
  UNION ALL SELECT 11, 'Snowflake: column comment', COUNT_IF(COALESCE(SNOWFLAKE_COMMENT, '') <> ''), COUNT(*), 'Snowflake Metadata' FROM p
  UNION ALL SELECT 12, 'Business entity linked', COUNT_IF(ENTITY_ID IS NOT NULL), COUNT(*), 'Business Glossary' FROM p
  UNION ALL SELECT 13, 'Process narrative available for the entity', COUNT_IF(HAS_WORD_NARRATIVE), COUNT(*), 'Uploaded Word Document' FROM p)
SELECT 'Source' AS SECTION, SOURCE_NAME AS ITEM, SOURCE_STATUS AS STATUS_COVERAGE, DETAIL, NULL::NUMBER AS COVERED, NULL::NUMBER AS TOTAL,
       NULL::NUMBER AS PCT, PRECEDENCE AS SORT_KEY
FROM {{DATABASE}}.{{KF}}.KF_METADATA_SOURCES
UNION ALL
SELECT 'Coverage', ITEM, COVERED || ' / ' || TOTAL || ' (' || ROUND(100 * DIV0(COVERED, TOTAL)) || '%)', SRC, COVERED, TOTAL,
       ROUND(100 * DIV0(COVERED, TOTAL)), 100 + N
FROM cov
UNION ALL
SELECT 'Gap', 'Not in any loaded source yet: field-level owner, KPI definitions per field, customer AP entity list', 'Gap',
       'Ask the AP Data Steward (role); route as Tier 2', NULL, NULL, 0, 200;

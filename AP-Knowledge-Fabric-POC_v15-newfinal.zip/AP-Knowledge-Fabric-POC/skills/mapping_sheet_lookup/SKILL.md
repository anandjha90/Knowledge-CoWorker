---
name: mapping_sheet_lookup
description: Use when the user asks about ONE field or column - its logic, mapping, calculation, transformation rule, source table, source field, source EDW table, business name, definition or lineage (for example AMT_USD_ME, AMT_DOC, AP_SPEND_TYPE, AWPT_DENOMINATOR).
---

# Instructions

The mapping sheets are stored in Snowflake word for word. Quote them; do not rewrite, simplify or "correct" the logic.

1. Find the field
   - metadata_analyst: data_dictionary filtered on dd_field_name (and dd_model_name if the user names a table).
   - If the field exists in several tables (for example FACT_ACCOUNT_PAYABLE_GBL and DM_FIN_AP_GBL_DETAILS), show each table, the user's table first.
   - If not found, try catalog_search with the business words, then say clearly that the field is not documented.

2. Answer in this order
   - Table and field with full name (DATABASE.SCHEMA.TABLE.FIELD) and the business name.
   - Business definition (as stored).
   - Source EDW table / view, source table, source field (as stored; say "calculated" if there is no source).
   - Mapping: the exact mapping text in a code block, unchanged.
   - In one or two plain-English sentences, what the logic does.

3. Lineage (only if asked, or if the user asks "where does it come from")
   - metadata_analyst field_lineage / field_mapping: walk upstream one hop at a time to the SAP source, one line per hop:
     TARGET.COLUMN <- SOURCE.COLUMN (rule).

4. Flag documentation issues you notice, without changing the answer
   - The source field does not exist in the source table (for example a field named in the datamart sheet that the fact sheet does not have).
   - The definition does not match the field name (for example a date definition on a type field).
   - The mapping is empty, or the source is #N/A.
   Say "Documentation gap - confirm with the data steward" and name what to confirm.

End with "Sources:" (data dictionary / mapping sheet, lineage, glossary).

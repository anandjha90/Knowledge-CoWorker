# AP Knowledge Fabric POC (Snowflake)

A **Cortex Agent** that answers metadata and data-discovery questions about an SAP-like Accounts Payable model:

1. Which tables and views make up the AP model, and how are they connected?
2. Where does a reporting field (e.g. vendor country) come from, back to source?
3. How is AP aging defined, and which buckets exist?
4. How often is the AP datamart refreshed, and which fields are masked?

Every reporting view gets a **data dictionary card** with all attributes of the requirement list (schema, names, data types and lengths, keys, business and technical descriptions, transaction/master class, rules, lineage, S2T, KPIs, domain, owners, refresh, dependencies, key filters, alternative views). A phase 2 preview maps SAP T-codes to SAP tables/fields, ingestion status and EDW columns.

It also answers impact questions (what is affected if a field changes, which reports depend on it), requirement traceability, mapping change history (what changed, why, how reviewed) and process / standards questions.

**Synthetic data and generic names only.** No client data, documents or credentials.

![architecture](assets/architecture.png)

## What gets built

| Layer | Objects |
|---|---|
| `SAP_LANDING` | SAP-like tables: `SAP_BKPF`, `SAP_BSEG`, `SAP_BSEC`, `SAP_LFA1`, `SAP_LFB1`, `SAP_LFBK`, `SAP_T001`, `SAP_T005T` (300 vendors, 6,000 invoices) |
| `EDW` | `FACT_ACCOUNTS_PAYABLE_GLOBAL` (vendor lines, account type K), `DIM_VENDOR`, `DIM_COMPANY_CODE`, load procedure + daily task |
| `AP_DATAMART` | `DM_AP_OPEN_ITEMS` (aging), `DM_AP_AGING_SUMMARY`, `DM_AP_VENDOR`, `AP_AGING_BUCKETS`, load procedure + task |
| `AP_REPORTING` | `VW_AP_OPEN_ITEMS`, `VW_AP_OVERDUE_ITEMS`, `VW_AP_AGING_SUMMARY`, `VW_AP_VENDOR` (rename / key filter only, no logic) |
| `GOVERNANCE` | 12 tags (incl. data class, technical owner, key role; inherited from database/schema), 4 masking policies incl. one conditional policy, primary / business key constraints, optional classification |
| `KNOWLEDGE_FABRIC` | Metadata catalog (`KF_*`), refresh procedure, 4 synthetic PDFs parsed with `AI_PARSE_DOCUMENT`, 2 Cortex Search services, semantic view `KF_METADATA_MODEL`, agent `AP_KNOWLEDGE_COWORKER`, evaluation dataset |

## Snowflake features used

Cortex Agents / Snowflake Intelligence · Cortex Search · Cortex Analyst with a semantic view · `AI_COMPLETE` (drafts descriptions for undocumented columns) · `AI_PARSE_DOCUMENT` + `SPLIT_TEXT_RECURSIVE_CHARACTER` · tags with inheritance · masking policies (incl. conditional) · `SYSTEM$CLASSIFY` · `INFORMATION_SCHEMA` (comments, `TAG_REFERENCES`, `POLICY_REFERENCES`) · tasks · `SNOWFLAKE.CORE.GET_LINEAGE`. All generally available; no preview features needed.

## Requirements

- **Enterprise edition** or higher (masking policies, tags, lineage).
- A role that can create a database, warehouse and roles, and use Cortex (`ADMIN_ROLE` in `config.py`, default `ACCOUNTADMIN`).
- Cortex models available in the region, or cross-region enabled (`sql/00_cortex_access.sql`).

## How to run (about 10 minutes)

1. Check `config.py` (database name, admin role). Every name lives there.
2. In Snowsight: **Projects → Workspaces → + Add → Upload folder** and upload this whole folder (incl. `docs/` with the 3 PDFs).
3. Create a notebook in the same folder and run:
   ```python
   import run
   run.run()            # builds files 00-13 in order
   run.check()          # counts per component
   run.demo_masking()   # same query as power user vs business user
   run.lineage_preview("VENDOR_COUNTRY")
   run.impact_preview("LAND1", "SAP_LFA1")   # what breaks if the vendor country source changes
   run.view_card("VW_AP_OPEN_ITEMS")          # data dictionary card: every attribute of a reporting view
   ```
4. Open **AI & ML → Snowflake Intelligence** (or **Agents**) → *AP Knowledge Co-worker*. If file 13 printed a warning, add the agent to Snowflake Intelligence in the agent screen.

Re-run part of the build: `run.run(["09_semantic_view.sql", "10_agent.sql"])`.
After changing comments, tags or policies: `run.refresh()`.

**If the PDF upload fails** (`upload_documents` error): upload the 4 files in `docs/` manually to stage `KNOWLEDGE_FABRIC.KF_DOCUMENTS`, then `run.run(run.SQL_FILES[9:])`.

## Files

| File | What it does |
|---|---|
| `config.py` | All names, roles, model, data volume, schedule |
| `run.py` | Fills `{{NAMES}}`, runs the SQL files, uploads the PDFs; `check()`, `refresh()`, `demo_masking()`, `lineage_preview()`, `impact_preview()` |
| `sql/00` – `sql/13` | The build, one step per file (see the header of each file); `07d` ontology and sources, `09c` ontology semantic view (v15) |
| `streamlit/app.py` | The app (v3 layout); `docs/samples/` has a Word file to test the upload |
| `sql/optional/metadata_inventory.sql` | For a real account later: what governance metadata exists for a domain (ACCOUNT_USAGE) |
| `docs/` | Synthetic BRD (with requirement IDs), FSD, governance standard, AP process and EDW standards (regenerate with `tools/make_documents.py`) |
| `assets/architecture.png` | Architecture diagram |

## v15: client demo feedback (v3 design)

The app now follows the v3 demo layout (three views, questions panel, side panel with Answer / Business definition / Relationships / Drill down, Sources and Field record, Draft & Approve), but reads live from Snowflake, so *Snowflake Metadata* shows **Connected**.

| Demo feedback item | Where it is |
|---|---|
| Business entity / ontology graph (Palantir-style: drag, hover, click to inspect) | App → Business ontology; tables `KF_ONTOLOGY_ENTITY`, `KF_ENTITY_OBJECT_MAP` |
| Business entity relationships (supported by workbook vs proposed, with evidence counts) | `KF_ONTOLOGY_RELATIONSHIPS` (counts computed live from the mapping workbook) |
| Business-to-technical drill down | Side panel → Drill down: entity → tables (found in Snowflake or workbook only) → fields → Field record / Column lineage |
| Multi-domain framework | `KF_DOMAIN`: AP live; AR, GL, Procurement planned; Enterprise view; shared entities marked |
| Metadata source transparency | Header chips and `KF_METADATA_SOURCES` (live status); every answer shows the sources it used; `KF_FIELD_PROVENANCE` per field |
| Uploaded Word document | Sources → Upload a Word document: paragraphs linked to entities, added to document search |
| AP process context L1-L3 with gaps | App → Technical lineage; `KF_PROCESS_COVERAGE` (Goods receipt = not in loaded data) |
| Exportable lineage and mapping reports | App → Reports and export: 5 reports as CSV, Excel, print / PDF; views `KF_RPT_*` |
| Agent answers business-entity questions | Semantic view `KF_ONTOLOGY_MODEL` (09c) + agent tool `ontology_analyst` |

Snowflake's own business ontology feature is not generally available yet; these tables use the same concepts (entities, relationships, mapped objects) so they can move to it later.

**Upgrade an existing build** (keeps all data): upload the changed files, then in the notebook
```python
import importlib, run, config; importlib.reload(config); importlib.reload(run)
run.upgrade_v15()   # 07d, 08, 09c, agent (+ skills), access, app
run.test()          # checks O01-O12 cover the new parts
```

## Design choices

- **Snowflake metadata is primary.** Comments, tags, policies and tasks are read live by `REFRESH_KNOWLEDGE_FABRIC` (scheduled after the datamart load). Documents, the mapping sheet and the glossary are supplementary.
- **Views inherit masking.** Reporting views have no policies of their own; the catalog marks their columns *masked via* the upstream datamart column.
- **Comment convention** `Business name: description` gives every column a business name without a separate table.
- **Deliberate gaps.** 6 columns and 1 table have no comment, so you can see gap detection and the `AI_COMPLETE` drafts that wait for steward approval.
- **Glossary ready for an ontology.** Terms carry owner, status (Approved/Draft) and source, the same shape a business ontology needs later.
- **Snowflake's own lineage** (`GET_LINEAGE`) can take a few hours to appear after the first load. The mapping sheet carries the field rules (for example the one-time vendor condition) that system lineage cannot express.

# =====================================================================
# run.py: builds the AP Knowledge Fabric POC in order.
#   1. reads each .sql file in sql/
#   2. replaces every {{NAME}} with the value from config.py
#   3. runs each statement in Snowflake
#
# In a Snowsight Workspace notebook (same folder):
#     import run
#     run.run()            # build everything (about 5-10 minutes)
#     run.check()          # what was built
#     run.demo_masking()   # same query as power user and as business user
# =====================================================================
import glob
import os
import re

import config

FOLDER = os.path.dirname(os.path.abspath(__file__))

SQL_FILES = [
    "00_cortex_access.sql",          # optional (ACCOUNTADMIN): cross-region models
    "01_setup.sql",
    "02_landing_sap.sql",
    "03_edw.sql",
    "04_datamart.sql",
    "05_reporting_and_refresh.sql",
    "06_governance.sql",
    "06b_classification.sql",        # optional: Snowflake sensitive-data classification
    "06c_keys.sql",                  # primary / business keys (warnings only on re-runs)
    "07_knowledge_fabric.sql",
    "07b_ap_metrics.sql",
    "07c_client_model.sql",          # AP model exactly as in the mapping workbook (generated, synthetic values)
    "07d_ontology_and_sources.sql",  # business ontology, process context, metadata sources, 5 exportable reports
    "08_documents_and_search.sql",
    "09_semantic_view.sql",
    "09b_ap_metrics_semantic_view.sql",  # AP business metrics for the agent
    "09c_ontology_semantic_view.sql",    # business entities, relationships, sources, provenance for the agent
    "10_agent.sql",
    "11_evaluation.sql",
    "11b_persona_questions.sql",     # persona test questions (starter questions in the app + evaluation set)
    "12_access.sql",                 # warnings only
    "13_snowflake_intelligence.sql", # optional
]
# In these files a failing statement is reported and skipped instead of stopping the build
SOFT_FILES = {"00_cortex_access.sql", "06b_classification.sql", "06c_keys.sql", "12_access.sql", "13_snowflake_intelligence.sql"}


def get_session():
    try:
        from snowflake.snowpark.context import get_active_session
        return get_active_session()
    except Exception:
        # Outside Snowflake: uses the default connection in ~/.snowflake/connections.toml
        from snowflake.snowpark import Session
        return Session.builder.getOrCreate()


session = get_session()


def fill_names(sql):
    """{{DATABASE}} -> POC_AP_KNOWLEDGE_FABRIC, using config.py"""
    return re.sub(r"\{\{(\w+)\}\}", lambda m: str(getattr(config, m.group(1))), sql)


def split_statements(sql):
    """Split on ';' but not inside quotes, $$ blocks or -- comments."""
    statements, current, i = [], "", 0
    in_quote = in_dollar = False
    while i < len(sql):
        if not in_quote and sql.startswith("$$", i):
            in_dollar = not in_dollar
            current += "$$"
            i += 2
            continue
        ch = sql[i]
        if not in_quote and not in_dollar and sql.startswith("--", i):
            end = sql.find("\n", i)
            i = len(sql) if end == -1 else end
            continue
        if ch == "'" and not in_dollar:
            in_quote = not in_quote
        if ch == ";" and not in_quote and not in_dollar:
            if current.strip():
                statements.append(current.strip())
            current = ""
        else:
            current += ch
        i += 1
    if current.strip():
        statements.append(current.strip())
    return statements


def upload_documents():
    """Put the synthetic PDFs from docs/ on the documents stage."""
    stage = f"{config.DATABASE}.{config.KF}.{config.DOCS_STAGE}"
    session.sql(f"CREATE STAGE IF NOT EXISTS {stage} ENCRYPTION = (TYPE = 'SNOWFLAKE_SSE') "
                f"DIRECTORY = (ENABLE = TRUE)").collect()
    files = sorted(glob.glob(os.path.join(FOLDER, "docs", "*.pdf")))
    for path in files:
        session.file.put(path, f"@{stage}", auto_compress=False, overwrite=True)
    session.sql(f"ALTER STAGE {stage} REFRESH").collect()
    on_stage = session.sql(f"SELECT COUNT(*) AS N FROM DIRECTORY(@{stage}) WHERE RELATIVE_PATH ILIKE '%.pdf'").collect()[0]["N"]
    print(f"📄 {len(files)} PDFs uploaded, {on_stage} on the stage")
    if on_stage == 0:
        raise RuntimeError("No PDFs on the stage. Upload the 4 files in docs/ in Snowsight: Catalog -> "
                           f"{config.DATABASE} -> {config.KF} -> Stages -> {config.DOCS_STAGE} -> + Files, then run again "
                           "from 08: run.run(run.SQL_FILES[run.SQL_FILES.index('08_documents_and_search.sql'):])")


def run_statement(file, statement):
    try:
        session.sql(statement).collect()
        return True
    except Exception as error:
        # Semantic view: if the verified queries are rejected, create it without them and say so
        if "AI_VERIFIED_QUERIES" in statement:
            print(f"⚠️  {file}: verified queries rejected ({str(error)[:200]}). Creating the semantic view without them; "
                  "add them in the semantic view editor (Verified queries).")
            session.sql(statement[:statement.index("AI_VERIFIED_QUERIES")]).collect()
            return True
        # Agent: if the chosen model is not offered in this account / region, try the fallbacks in config.py
        if "CREATE OR REPLACE AGENT" in statement and "orchestration: " + config.AGENT_MODEL in statement:
            for model in config.AGENT_MODEL_FALLBACKS:
                try:
                    session.sql(statement.replace("orchestration: " + config.AGENT_MODEL, "orchestration: " + model)).collect()
                    print(f"⚠️  {file}: model {config.AGENT_MODEL} not available here ({str(error)[:120]}); agent created with {model}. "
                          f"Set AGENT_MODEL in config.py to {model} to make this the default.")
                    return True
                except Exception:
                    continue
        if file in SOFT_FILES:
            print(f"⚠️  {file}: skipped one statement ({str(error)[:160]})\n    {statement[:120]}")
            return False
        print(f"❌ {file} failed on:\n{statement[:600]}\n\n{error}")
        raise


def run(files=SQL_FILES):
    """Build everything. To run just some files: run(["09_semantic_view.sql", "10_agent.sql"])"""
    session.sql(f"USE ROLE {config.ADMIN_ROLE}").collect()
    for file in files:
        if file.startswith("08"):
            upload_documents()
        sql = fill_names(open(os.path.join(FOLDER, "sql", file)).read())
        ok = all([run_statement(file, s) for s in split_statements(sql)])
        print(f"{'✅' if ok else '🟡'} {file}")
        if file.startswith("07"):
            print("   " + session.sql(f"SELECT COUNT(*) AS N FROM {config.DATABASE}.{config.KF}.KF_COLUMNS")
                  .collect()[0]["N"].__str__() + " columns catalogued")
    print("\nDone. Next: run.check(), then open AI & ML -> Agents (or Snowflake Intelligence).")


SKILLS = ["new_requirement_assessment", "mapping_sheet_lookup", "data_dictionary_export"]


def add_skills():
    """Uploads skills/<name>/SKILL.md to a stage and recreates the agent with the skills attached
    (the long task rules then live in the skills, so the agent prompt gets shorter). Safe to repeat.
    If the account rejects skills, the agent is recreated without them and a warning is printed."""
    kf = f"{config.DATABASE}.{config.KF}"
    stage = f"{kf}.{config.SKILLS_STAGE}"
    session.sql(f"USE ROLE {config.ADMIN_ROLE}").collect()
    session.sql(f"CREATE STAGE IF NOT EXISTS {stage} DIRECTORY = (ENABLE = TRUE) "
                "COMMENT = 'Agent skills: one folder per skill with its SKILL.md'").collect()
    for name in SKILLS:
        session.file.put(os.path.join(FOLDER, "skills", name, "SKILL.md"), f"@{stage}/skills/{name}",
                         auto_compress=False, overwrite=True)
    session.sql(f"ALTER STAGE {stage} REFRESH").collect()
    print(f"📚 {len(SKILLS)} skills uploaded to @{stage}/skills/")

    base = fill_names(open(os.path.join(FOLDER, "sql", "10_agent.sql")).read())
    statement = [s for s in split_statements(base) if "CREATE OR REPLACE AGENT" in s][0]
    block = "  skills:\n" + "".join(
        f'    - name: "{n}"\n      source:\n        type: "STAGE"\n        path: "@{stage}/skills/{n}"\n' for n in SKILLS)
    with_skills = statement.replace("\n  tools:\n", "\n" + block + "  tools:\n", 1)
    start = with_skills.find("      NEW REQUIREMENT")
    end_marker = "quote the mapping exactly as stored; then follow the lineage upstream if asked.\n"
    end = with_skills.find(end_marker)
    if start > 0 and end > start:   # task rules move into the skills: thinner agent prompt
        with_skills = (with_skills[:start]
                       + "      Use your skills for task procedures: new_requirement_assessment (new requirements, reuse),\n"
                       + "      mapping_sheet_lookup (one field: logic, source, mapping, lineage), data_dictionary_export\n"
                       + "      (all fields of a table). For the load SQL behind a table use load_scripts.\n"
                       + with_skills[end + len(end_marker):])
    try:
        run_statement("10_agent.sql + skills", with_skills)
        print("✅ agent recreated with skills: " + ", ".join(SKILLS))
    except Exception as error:
        print(f"⚠️  skills not accepted here ({str(error)[:200]}); recreating the agent without skills")
        run_statement("10_agent.sql", statement)
    run(["12_access.sql", "13_snowflake_intelligence.sql"])
    session.sql(f"GRANT READ ON STAGE {stage} TO ROLE {config.BUSINESS_ROLE}").collect()


def add_app():
    """Creates the Streamlit app: chat with the agent, FAQ with usage counts, lineage / record / completeness /
    sources panel, metadata browser, and Draft & Approve (suggest -> approve / reject) for missing descriptions."""
    kf = f"{config.DATABASE}.{config.KF}"
    stage = f"{kf}.{config.APP_STAGE}"
    session.sql(f"USE ROLE {config.ADMIN_ROLE}").collect()
    session.sql(f"""CREATE TABLE IF NOT EXISTS {kf}.KF_QUESTION_LOG (
        QUESTION VARCHAR, ASKED_BY VARCHAR, APP_ROLE VARCHAR, ASKED_AT TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP())
        COMMENT = 'Questions asked in the app (FAQ usage counts)'""").collect()
    session.sql(f"""CREATE TABLE IF NOT EXISTS {kf}.KF_DESCRIPTION_APPROVALS (
        MODEL_NAME VARCHAR, FIELD_NAME VARCHAR, SUGGESTED_TEXT VARCHAR, FINAL_TEXT VARCHAR,
        STATUS VARCHAR COMMENT 'Draft, Approved or Rejected', EVIDENCE VARCHAR,
        SUGGESTED_BY VARCHAR, SUGGESTED_AT TIMESTAMP_LTZ, DECIDED_BY VARCHAR, DECIDED_AT TIMESTAMP_LTZ)
        COMMENT = 'Draft & Approve: AI-suggested business descriptions and the business owner decision'""").collect()
    session.sql(f"CREATE STAGE IF NOT EXISTS {stage} COMMENT = 'Streamlit app code'").collect()
    code = open(os.path.join(FOLDER, "streamlit", "app.py")).read()
    for name in ["DATABASE", "KF", "EDW", "DATAMART", "REPORTING", "LANDING", "AGENT", "AI_MODEL", "POWER_ROLE",
                 "BUSINESS_ROLE", "DOCS_SEARCH"]:
        code = re.sub(r'^(\w+ = )"[^"]*"(\s+# config\.' + name + r')$', lambda m: f'{m.group(1)}"{getattr(config, name)}"{m.group(2)}',
                      code, flags=re.M)
    tmp = os.path.join("/tmp", "app.py")
    open(tmp, "w").write(code)
    session.file.put(tmp, f"@{stage}", auto_compress=False, overwrite=True)
    # environment.yml pins the Streamlit version (the app needs 1.42 or newer; without it the runtime may use an old one)
    for extra in ["environment.yml", "pyproject.toml"]:
        path = os.path.join(FOLDER, "streamlit", extra)
        if os.path.exists(path):
            session.file.put(path, f"@{stage}", auto_compress=False, overwrite=True)
    app = f"{kf}.{config.APP}"
    common = f"MAIN_FILE = 'app.py' QUERY_WAREHOUSE = {config.WAREHOUSE} TITLE = 'AP Knowledge Co-worker'"
    # Warehouse runtime on purpose: new apps now default to the container runtime (needs a compute pool and a
    # pyproject.toml, no owner's rights). Accounts without that option reject RUNTIME_NAME, so fall back.
    attempts = [f"CREATE OR REPLACE STREAMLIT {app} FROM '@{stage}' {common} RUNTIME_NAME = 'SYSTEM$WAREHOUSE_RUNTIME'",
                f"CREATE OR REPLACE STREAMLIT {app} FROM '@{stage}' {common}",
                f"CREATE OR REPLACE STREAMLIT {app} ROOT_LOCATION = '@{stage}' {common}"]
    for i, statement in enumerate(attempts):
        try:
            session.sql(statement).collect()
            break
        except Exception as error:
            if i == len(attempts) - 1:
                raise
            print(f"   (retrying app creation: {str(error)[:120]})")
    for statement in [f"GRANT USAGE ON STREAMLIT {app} TO ROLE {config.BUSINESS_ROLE}",
                      f"GRANT SELECT, INSERT ON TABLE {kf}.KF_QUESTION_LOG TO ROLE {config.BUSINESS_ROLE}"]:
        try:
            session.sql(statement).collect()
        except Exception as error:
            print(f"⚠️  {statement[:60]}: {str(error)[:120]}")
    print(f"✅ app {app} created: Snowsight -> Projects -> Streamlit -> AP Knowledge Co-worker")


def update_personas():
    """Persona test questions (Data Engineer, Data Architect, Functional Owner): loads them, refreshes the agent
    instructions (10 + skills, 12, 13) and redeploys the app with the 3 roles. Safe to repeat."""
    run(["11_evaluation.sql", "11b_persona_questions.sql"])
    add_skills()
    add_app()
    print("\n✅ Persona questions loaded: KF_PERSONA_QUESTIONS (app starter questions) and KF_EVAL_DATASET P01-P23.")


def upgrade_v15():
    """Client demo feedback (v3 design) on top of an existing build, without rebuilding the data:
    business ontology, AP process context, metadata source transparency, 5 exportable reports (07d),
    uploaded Word documents in document search (08), ontology semantic view (09c), the agent with its new
    ontology tool (10 + skills, 12, 13) and the new app. Safe to repeat."""
    run(["07d_ontology_and_sources.sql", "08_documents_and_search.sql", "09c_ontology_semantic_view.sql"])
    add_skills()      # recreates the agent from 10_agent.sql (with skills if the account allows) and re-runs 12 and 13
    add_app()
    print("\n✅ v15 ready. Run run.test() (checks O01-O12 cover the new parts), then open the app.")


def parse_ai_json(raw):
    """AI_COMPLETE may return the JSON as an encoded string and inside ```json fences: unwrap both."""
    text = raw if isinstance(raw, str) else str(raw)
    for _ in range(2):
        t = text.strip()
        if t.startswith('"') and t.endswith('"'):
            try:
                text = __import__('json').loads(t)
                continue
            except Exception:
                pass
        break
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    match = re.search(r"\{.*\}", text, re.S)
    if match:
        try:
            return __import__('json').loads(match.group(0)), text
        except Exception:
            pass
    return {}, text


STEWARD_PROMPT = """You are a senior finance data steward writing the business data dictionary for an Accounts Payable data mart.
Your reader is a finance user (controller, AP manager), not an engineer.

Write for the column below:
- business_name: 2 to 5 words, Title Case, plain business wording (standard abbreviations such as AP, USD, GL are fine).
- description: 1 or 2 sentences, at most 40 words. Start with what the field represents (for example "Number of days...",
  "Aging band of...", "Name of..."). Mention the unit or currency for amounts and days, and the allowed values when the data
  shows a small fixed set. If many values are empty and the rule explains why, say when it is filled (for example
  "Empty for paid items."). No SQL, no technical column names, nothing that is not supported by the facts below.
- confidence: High (rule, source definition and data agree), Medium (rule or data only), Low (name only or conflicting facts).
- basis: one short sentence for the approver explaining what the draft is based on.

Reply with JSON only: {"business_name": "...", "description": "...", "confidence": "High|Medium|Low", "basis": "..."}

Table: AP global details data mart (one row per AP line item, open and paid; amounts in USD at month-end rate).
Column: <<COL>>
Source EDW table / view: <<SRC_TBL>>
Source field: <<SRC_FLD>>
Mapping rule: <<RULE>>
Source field business definition: <<SRC_DEF>>
Data profile: <<PROFILE>>"""



def suggest_from_data(model="DM_FIN_AP_GBL_DETAILS", limit=None):
    """For every column of `model` without a business definition in the mapping sheet: profile the data
    (rows, % empty, distinct, min / max, top values - not for masked columns), infer a description with
    AI_COMPLETE and store it as a Draft in KF_DESCRIPTION_APPROVALS (approve / reject in the app)."""
    import json as _json
    kf = f"{config.DATABASE}.{config.KF}"
    session.sql(f"""CREATE TABLE IF NOT EXISTS {kf}.KF_DESCRIPTION_APPROVALS (
        MODEL_NAME VARCHAR, FIELD_NAME VARCHAR, SUGGESTED_TEXT VARCHAR, FINAL_TEXT VARCHAR, STATUS VARCHAR, EVIDENCE VARCHAR,
        SUGGESTED_BY VARCHAR, SUGGESTED_AT TIMESTAMP_LTZ, DECIDED_BY VARCHAR, DECIDED_AT TIMESTAMP_LTZ)""").collect()
    for extra in ["BUSINESS_NAME VARCHAR", "CONFIDENCE VARCHAR", "BASIS VARCHAR", "PROFILE VARCHAR"]:
        session.sql(f"ALTER TABLE {kf}.KF_DESCRIPTION_APPROVALS ADD COLUMN IF NOT EXISTS {extra}").collect()
    rows = session.sql(f"""SELECT e.SCHEMA_NAME, e.MODEL_NAME, e.FIELD_NAME, e.SOURCE_EDW_TABLE, e.SOURCE_FIELD, e.MAPPING, e.SHEET_ROW,
                                  COALESCE(s.BUSINESS_NAME || ': ' || s.DEFINITION, 'none') AS SRC_DEF, COALESCE(c.IS_MASKED, FALSE) AS MASKED
                           FROM {kf}.KF_EXCEL_MAPPING_SHEET e
                           LEFT JOIN {kf}.KF_EXCEL_MAPPING_SHEET s ON s.MODEL_NAME = 'FACT_ACCOUNT_PAYABLE_GBL' AND s.FIELD_NAME = UPPER(e.SOURCE_FIELD)
                                AND s.DEFINITION <> ''
                           LEFT JOIN {kf}.KF_COLUMNS c ON c.OBJECT_NAME = e.MODEL_NAME AND c.COLUMN_NAME = e.FIELD_NAME
                           WHERE e.MODEL_NAME = '{model}' AND COALESCE(e.DEFINITION, '') = ''
                             AND e.FIELD_NAME NOT IN (SELECT FIELD_NAME FROM {kf}.KF_DESCRIPTION_APPROVALS
                                                      WHERE MODEL_NAME = '{model}' AND STATUS IN ('Draft', 'Approved'))
                           ORDER BY e.SHEET_ROW""").collect()
    rows = rows[:limit] if limit else rows
    done = 0
    for r in rows:
        col, t = r["FIELD_NAME"], f"{config.DATABASE}.{r['SCHEMA_NAME']}.{r['MODEL_NAME']}"
        try:
            p = session.sql(f"SELECT COUNT(*) N, COUNT_IF({col} IS NULL) NULLS, COUNT(DISTINCT {col}) D, "
                            f"MIN({col})::VARCHAR MINV, MAX({col})::VARCHAR MAXV FROM {t}").collect()[0]
            prof = (f"rows {p['N']}, empty {round(100 * p['NULLS'] / max(p['N'], 1), 1)}%, distinct {p['D']}, "
                    f"min {p['MINV']}, max {p['MAXV']}")
            if not r["MASKED"]:
                top = session.sql(f"SELECT {col}::VARCHAR V, COUNT(*) C FROM {t} WHERE {col} IS NOT NULL GROUP BY 1 ORDER BY 2 DESC LIMIT 5").collect()
                prof += "; top values " + ", ".join(f"{x['V']} ({x['C']})" for x in top)
            prompt = (STEWARD_PROMPT.replace("<<COL>>", col).replace("<<SRC_TBL>>", r["SOURCE_EDW_TABLE"] or "-")
                      .replace("<<SRC_FLD>>", r["SOURCE_FIELD"] or "-").replace("<<RULE>>", r["MAPPING"] or "-")
                      .replace("<<SRC_DEF>>", r["SRC_DEF"]).replace("<<PROFILE>>", prof))
            raw = session.sql("SELECT AI_COMPLETE(?, ?) AS T", params=[config.AI_MODEL, prompt]).collect()[0]["T"]
            d, plain = parse_ai_json(raw)
            text = (d.get("description") or plain).strip().strip('"')
            name = (d.get("business_name") or col.replace("_", " ").title()).strip()
            conf = d.get("confidence") if d.get("confidence") in ("High", "Medium", "Low") else "Medium"
            evidence = f"Mapping rule (AP DM Mapping row {r['SHEET_ROW']}) · data profile"
            values = [name, text, conf, d.get("basis", ""), prof, evidence]
            session.sql(f"""MERGE INTO {kf}.KF_DESCRIPTION_APPROVALS t USING (SELECT ? AS M, ? AS F) s
                            ON t.MODEL_NAME = s.M AND t.FIELD_NAME = s.F
                            WHEN MATCHED THEN UPDATE SET BUSINESS_NAME = ?, SUGGESTED_TEXT = ?, STATUS = 'Draft', CONFIDENCE = ?,
                                 BASIS = ?, PROFILE = ?, EVIDENCE = ?, SUGGESTED_BY = CURRENT_USER(), SUGGESTED_AT = CURRENT_TIMESTAMP()
                            WHEN NOT MATCHED THEN INSERT (MODEL_NAME, FIELD_NAME, BUSINESS_NAME, SUGGESTED_TEXT, STATUS, CONFIDENCE,
                                 BASIS, PROFILE, EVIDENCE, SUGGESTED_BY, SUGGESTED_AT)
                                 VALUES (s.M, s.F, ?, ?, 'Draft', ?, ?, ?, ?, CURRENT_USER(), CURRENT_TIMESTAMP())""",
                        params=[model, col] + values + values).collect()
            done += 1
            print(f"📝 {col} [{conf}] {name}: {text}")
        except Exception as error:
            print(f"⚠️  {col}: {str(error)[:150]}")
    print(f"\n{done} drafts written to {kf}.KF_DESCRIPTION_APPROVALS (status Draft). Approve or reject them in the app.")


def refresh(suggest_descriptions=False):
    """Re-read all Snowflake metadata into the Knowledge Fabric (after any change to the model)."""
    result = session.sql(f"CALL {config.DATABASE}.{config.KF}.REFRESH_KNOWLEDGE_FABRIC({suggest_descriptions})").collect()
    print(result[0][0])


def test():
    """End-to-end tests of the AP model against the mapping workbook: one row per check, PASS / FAIL."""
    statements = [x for x in split_statements(fill_names(open(os.path.join(FOLDER, "sql", "14_e2e_tests.sql")).read())) if x.strip()]
    rows = session.sql(statements[-1]).collect()
    failed = [r for r in rows if r["RESULT"] != "PASS"]
    for r in rows:
        print(f"{'✅' if r['RESULT'] == 'PASS' else '❌'} {r['TEST_ID']} {r['TEST']}  | expected {r['EXPECTED']} | actual {r['ACTUAL']}")
    print(f"\n{len(rows) - len(failed)} of {len(rows)} checks passed")
    return session.sql(statements[-1])


def check():
    """One row per component with its count."""
    db, kf = config.DATABASE, f"{config.DATABASE}.{config.KF}"
    return session.sql(f"""
        SELECT 'Landing: SAP_BSEG rows' AS ITEM, COUNT(*) AS N FROM {db}.{config.LANDING}.SAP_BSEG
        UNION ALL SELECT 'EDW: AP fact rows (vendor lines)', COUNT(*) FROM {db}.{config.EDW}.FACT_ACCOUNTS_PAYABLE_GLOBAL
        UNION ALL SELECT 'Datamart: open items', COUNT(*) FROM {db}.{config.DATAMART}.DM_AP_OPEN_ITEMS
        UNION ALL SELECT 'Datamart: aging buckets used', COUNT(DISTINCT AGING_BUCKET) FROM {db}.{config.DATAMART}.DM_AP_OPEN_ITEMS
        UNION ALL SELECT 'KF: objects', COUNT(*) FROM {kf}.KF_OBJECTS
        UNION ALL SELECT 'KF: columns', COUNT(*) FROM {kf}.KF_COLUMNS
        UNION ALL SELECT 'KF: masked columns (direct + inherited)', COUNT_IF(IS_MASKED) FROM {kf}.KF_COLUMNS
        UNION ALL SELECT 'KF: columns without description', COUNT_IF(NOT HAS_DESCRIPTION) FROM {kf}.KF_COLUMNS
        UNION ALL SELECT 'KF: AI description drafts', COUNT(*) FROM {kf}.KF_DESCRIPTION_SUGGESTIONS
        UNION ALL SELECT 'KF: objects with tags read', COUNT(DATA_DOMAIN) FROM {kf}.KF_OBJECTS
        UNION ALL SELECT 'KF: lineage steps (mapping sheet)', COUNT(*) FROM {kf}.KF_LINEAGE_PATHS
        UNION ALL SELECT 'KF: Snowflake lineage rows (may lag hours)', COUNT(*) FROM {kf}.KF_SYSTEM_LINEAGE
        UNION ALL SELECT 'KF: refresh jobs', COUNT(*) FROM {kf}.KF_REFRESH_SCHEDULE
        UNION ALL SELECT 'KF: impact rows (downstream)', COUNT(*) FROM {kf}.KF_IMPACT
        UNION ALL SELECT 'KF: requirements', COUNT(*) FROM {kf}.KF_REQUIREMENTS
        UNION ALL SELECT 'KF: requirement trace rows', COUNT(*) FROM {kf}.KF_REQUIREMENT_TRACE
        UNION ALL SELECT 'KF: mapping changes', COUNT(*) FROM {kf}.KF_MAPPING_CHANGE_LOG
        UNION ALL SELECT 'KF: reporting view cards', COUNT(*) FROM {kf}.KF_REPORTING_VIEWS
        UNION ALL SELECT 'KF: columns with a key role', COUNT(KEY_ROLE) FROM {kf}.KF_COLUMNS
        UNION ALL SELECT 'KF: SAP T-code mappings (phase 2 preview)', COUNT(*) FROM {kf}.KF_SAP_TCODE_MAP
        UNION ALL SELECT 'KF: SAP fields in reuse assessment', COUNT(*) FROM {kf}.KF_REUSE_ASSESSMENT
        UNION ALL SELECT 'KF: catalog entries (search)', COUNT(*) FROM {kf}.KF_CATALOG
        UNION ALL SELECT 'Docs: pages parsed', COUNT(*) FROM {kf}.KF_DOC_PAGES
        UNION ALL SELECT 'Docs: chunks', COUNT(*) FROM {kf}.KF_DOC_CHUNKS
        UNION ALL SELECT 'Ontology: business entities', COUNT(*) FROM {kf}.KF_ONTOLOGY_ENTITY
        UNION ALL SELECT 'Ontology: relationships supported by the workbook', COUNT_IF(EVIDENCE_STATUS = 'Supported by workbook') FROM {kf}.KF_ONTOLOGY_RELATIONSHIPS
        UNION ALL SELECT 'Ontology: entity -> object links found in Snowflake', COUNT_IF(IN_SNOWFLAKE) FROM {kf}.KF_ENTITY_OBJECTS
        UNION ALL SELECT 'Sources: uploaded Word documents', COUNT(*) FROM {kf}.KF_UPLOADED_DOCUMENTS
        UNION ALL SELECT 'Sources: fields with provenance', COUNT(*) FROM {kf}.KF_FIELD_PROVENANCE
    """).to_pandas()


def demo_masking():
    """The same reporting query as power user and as business user."""
    sql = (f"SELECT VENDOR_ID, VENDOR_NAME, VENDOR_COUNTRY, TAX_ID, BANK_ACCOUNT "
           f"FROM {config.DATABASE}.{config.REPORTING}.VW_AP_VENDOR ORDER BY VENDOR_ID LIMIT 3")
    out = {}
    for role in (config.POWER_ROLE, config.BUSINESS_ROLE):
        session.sql(f"USE ROLE {role}").collect()
        session.sql(f"USE WAREHOUSE {config.WAREHOUSE}").collect()
        out[role] = session.sql(sql).to_pandas()
    session.sql(f"USE ROLE {config.ADMIN_ROLE}").collect()
    for role, df in out.items():
        print(f"\n--- {role} ---\n{df.to_string(index=False)}")
    return out


def impact_preview(changed_column="LAND1", changed_object="SAP_LFA1"):
    """Everything downstream of a column: columns, dashboards, reports, extracts."""
    return session.sql(f"""
        SELECT DISTANCE, AFFECTED_LAYER, AFFECTED_TYPE, AFFECTED_OBJECT, AFFECTED_COLUMN, OWNER
        FROM {config.DATABASE}.{config.KF}.KF_IMPACT
        WHERE CHANGED_COLUMN = '{changed_column}' AND CHANGED_OBJECT ILIKE '%{changed_object}'
        ORDER BY DISTANCE, AFFECTED_OBJECT""").to_pandas()


def view_card(view="VW_AP_OPEN_ITEMS"):
    """The data dictionary card of one reporting view, one attribute per row."""
    df = session.sql(f"SELECT * FROM {config.DATABASE}.{config.KF}.KF_REPORTING_VIEWS WHERE VIEW_NAME = '{view}'").to_pandas()
    return df.T.rename(columns={0: view}) if not df.empty else df


def lineage_preview(report_column="VENDOR_COUNTRY", report_object="VW_AP_OPEN_ITEMS"):
    """Hop-by-hop lineage of a reporting field, straight from the Knowledge Fabric."""
    return session.sql(f"""
        SELECT HOP, TARGET_OBJECT || '.' || TARGET_COLUMN AS TARGET, SOURCE_OBJECT || '.' || SOURCE_COLUMN AS SOURCE,
               MAPPING_TYPE, TRANSFORMATION_RULE, IS_ORIGIN
        FROM {config.DATABASE}.{config.KF}.KF_LINEAGE_PATHS
        WHERE REPORT_COLUMN = '{report_column}' AND REPORT_OBJECT ILIKE '%{report_object}'
        ORDER BY HOP, SOURCE""").to_pandas()

-- =====================================================================
-- 09c SEMANTIC VIEW over the business ontology (Cortex Analyst)
--   Lets the agent answer business-entity questions with SQL: "Which tables hold AP Document?",
--   "How is a vendor invoice related to the AP document?", "Which process steps have no data?",
--   "Which metadata sources are connected?", "Which mart columns belong to Vendor and how are they documented?"
-- =====================================================================
USE WAREHOUSE {{WAREHOUSE}};

CREATE OR REPLACE SEMANTIC VIEW {{DATABASE}}.{{KF}}.{{ONTOLOGY_VIEW}}

TABLES (
  domains AS {{DATABASE}}.{{KF}}.KF_DOMAIN PRIMARY KEY (DOMAIN_ID)
    WITH SYNONYMS ('domains', 'business domains', 'portfolio')
    COMMENT = 'Business domains: Accounts Payable (live), Accounts Receivable, General Ledger, Procurement (planned).',
  entities AS {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITIES PRIMARY KEY (ENTITY_ID)
    WITH SYNONYMS ('business entities', 'business objects', 'ontology', 'entity')
    COMMENT = 'Business entities (Vendor, Purchase Order, Goods Receipt, Vendor Invoice, AP Document, Payment, GL Account, Legal Entity, ...) with type, domains, definition from the business glossary and owner role.',
  entity_objects AS {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECTS PRIMARY KEY (ENTITY_ID, OBJECT_NAME)
    WITH SYNONYMS ('entity tables', 'business to technical map', 'tables that hold an entity')
    COMMENT = 'Which tables, views and SAP tables hold each business entity, with workbook evidence counts and whether the object exists in Snowflake.',
  relationships AS {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIPS PRIMARY KEY (REL_ID)
    WITH SYNONYMS ('entity relationships', 'how entities relate', 'business relationships')
    COMMENT = 'Relationships between business entities (from, verb, to) with evidence: supported by workbook (with counts) or proposed.',
  process_steps AS {{DATABASE}}.{{KF}}.KF_PROCESS_COVERAGE PRIMARY KEY (STEP_NO)
    WITH SYNONYMS ('process', 'AP process', 'process steps', 'procure to pay')
    COMMENT = 'AP process context L1 Procure-to-Pay > L2 Accounts Payable > L3 Vendor to AP document, with the objects behind each step and gaps.',
  metadata_sources AS {{DATABASE}}.{{KF}}.KF_METADATA_SOURCES PRIMARY KEY (SOURCE_KEY)
    WITH SYNONYMS ('metadata sources', 'sources', 'where the metadata comes from')
    COMMENT = 'The four metadata sources (Snowflake Metadata, Uploaded Excel, Uploaded Word Document, Business Glossary) with live status and counts.',
  field_provenance AS {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE PRIMARY KEY (SHEET, SHEET_ROW)
    WITH SYNONYMS ('field provenance', 'field sources', 'definition status', 'field record')
    COMMENT = 'One row per fact field and data mart column: business entity, transformation type, SAP origin, definition and its status, data type from Snowflake, and which metadata sources hold it.',
  entity_narrative AS {{DATABASE}}.{{KF}}.KF_ENTITY_NARRATIVE PRIMARY KEY (DOC_ID, PARA_NO, ENTITY_ID)
    WITH SYNONYMS ('process narrative', 'Word document', 'SOP', 'what the document says')
    COMMENT = 'Paragraphs of uploaded Word documents linked to business entities.'
)

RELATIONSHIPS (
  objects_to_entities AS entity_objects (ENTITY_ID) REFERENCES entities,
  fields_to_entities AS field_provenance (ENTITY_ID) REFERENCES entities,
  steps_to_entities AS process_steps (ENTITY_ID) REFERENCES entities,
  narrative_to_entities AS entity_narrative (ENTITY_ID) REFERENCES entities
)

FACTS (
  entity_objects.obj_fields_in_workbook AS FIELDS_IN_WORKBOOK COMMENT = 'Fields of this object in the mapping workbook (fact 113, data mart 174)',
  entity_objects.obj_fact_fields_fed AS FACT_FIELDS_FED COMMENT = 'Fact fields whose workbook source is this object',
  entity_objects.obj_mart_columns_fed AS MART_COLUMNS_FED COMMENT = 'Data mart columns whose workbook source is this object',
  relationships.rel_evidence_rows AS EVIDENCE_ROWS COMMENT = 'Workbook rows (fields, columns, view columns) that support the relationship'
)

DIMENSIONS (
  domains.domain_id AS DOMAIN_ID COMMENT = 'Domain ID' SAMPLE_VALUES ('ap', 'ar', 'gl', 'proc'),
  domains.domain_name AS DOMAIN_NAME COMMENT = 'Domain name',
  domains.domain_status AS DOMAIN_STATUS COMMENT = 'Live, Planned or View' SAMPLE_VALUES ('Live', 'Planned'),

  entities.entity_id AS ENTITY_ID COMMENT = 'Entity ID' SAMPLE_VALUES ('vendor', 'po', 'gr', 'inv', 'apdoc', 'pay', 'gl', 'entity', 'org', 'fiscal', 'country', 'rpt'),
  entities.entity_name AS ENTITY_NAME WITH SYNONYMS = ('business entity', 'business object')
    COMMENT = 'Entity name' SAMPLE_VALUES ('Vendor', 'Purchase Order', 'Goods Receipt', 'Vendor Invoice', 'AP Document', 'Payment', 'Legal Entity'),
  entities.entity_type AS ENTITY_TYPE COMMENT = 'Master data, Transaction, Reference or Report' SAMPLE_VALUES ('Master data', 'Transaction', 'Reference', 'Report'),
  entities.entity_domains AS DOMAINS COMMENT = 'Comma-separated domain IDs; more than one means shared across domains',
  entities.entity_is_shared AS IS_SHARED COMMENT = 'TRUE when the entity is shared across domains',
  entities.entity_status AS ENTITY_STATUS COMMENT = 'Live or Planned' SAMPLE_VALUES ('Live', 'Planned'),
  entities.entity_definition AS BUSINESS_DEFINITION WITH SYNONYMS = ('definition', 'meaning') COMMENT = 'Business definition (business glossary)',
  entities.entity_definition_status AS DEFINITION_STATUS COMMENT = 'Sample, Draft or Approved',
  entities.entity_synonyms AS SYNONYMS COMMENT = 'Other words for the entity',
  entities.entity_owner AS OWNER_ROLE COMMENT = 'Accountable owner (role)',

  entity_objects.obj_entity_id AS ENTITY_ID COMMENT = 'Entity ID',
  entity_objects.obj_entity_name AS ENTITY_NAME COMMENT = 'Entity name',
  entity_objects.obj_role AS OBJECT_ROLE COMMENT = 'EDW object, Data mart, Reporting view or SAP table' SAMPLE_VALUES ('EDW object', 'Data mart', 'Reporting view', 'SAP table'),
  entity_objects.obj_object_name AS OBJECT_NAME WITH SYNONYMS = ('table', 'view') COMMENT = 'Object name as in the mapping workbook',
  entity_objects.obj_friendly_name AS FRIENDLY_NAME COMMENT = 'Business-friendly name of the object',
  entity_objects.obj_workbook_schema AS WORKBOOK_SCHEMA COMMENT = 'Schema named in the workbook',
  entity_objects.obj_snowflake_key AS SNOWFLAKE_KEY COMMENT = 'SCHEMA.OBJECT in this Snowflake database, when loaded',
  entity_objects.obj_in_snowflake AS IN_SNOWFLAKE COMMENT = 'TRUE when the object exists in Snowflake',
  entity_objects.obj_evidence AS EVIDENCE COMMENT = 'Uploaded Excel (named in the workbook) or Snowflake Metadata (account only)',

  relationships.rel_id AS REL_ID COMMENT = 'Relationship ID',
  relationships.rel_from_entity AS FROM_ENTITY COMMENT = 'From entity ID',
  relationships.rel_from_name AS FROM_NAME COMMENT = 'From entity name',
  relationships.rel_verb AS RELATIONSHIP COMMENT = 'Relationship verb, e.g. posts as, is owed to',
  relationships.rel_to_entity AS TO_ENTITY COMMENT = 'To entity ID',
  relationships.rel_to_name AS TO_NAME COMMENT = 'To entity name',
  relationships.rel_domain AS DOMAIN_ID COMMENT = 'Domain of the relationship',
  relationships.rel_evidence_status AS EVIDENCE_STATUS COMMENT = 'Supported by workbook, Proposed or Not found in loaded workbook'
    SAMPLE_VALUES ('Supported by workbook', 'Proposed'),
  relationships.rel_evidence_detail AS EVIDENCE_DETAIL COMMENT = 'Which objects and how many fields support the relationship',
  relationships.rel_evidence_objects AS EVIDENCE_OBJECTS COMMENT = 'Objects that carry the relationship',

  process_steps.step_no AS STEP_NO COMMENT = 'Order of the step',
  process_steps.step_l1 AS PROCESS_L1 COMMENT = 'Level 1 process',
  process_steps.step_l2 AS PROCESS_L2 COMMENT = 'Level 2 process',
  process_steps.step_l3 AS PROCESS_L3 COMMENT = 'Level 3 process',
  process_steps.step_name AS STEP_NAME COMMENT = 'Process step' SAMPLE_VALUES ('Vendor creation', 'Purchase order', 'Goods receipt', 'Vendor invoice', 'AP document'),
  process_steps.step_entity AS ENTITY_ID COMMENT = 'Entity of the step',
  process_steps.step_workbook_objects AS WORKBOOK_OBJECTS COMMENT = 'Workbook objects behind the step',
  process_steps.step_snowflake_objects AS SNOWFLAKE_OBJECTS COMMENT = 'Snowflake objects behind the step',
  process_steps.step_status AS STEP_STATUS COMMENT = 'Covered or Gap (not in loaded data)' SAMPLE_VALUES ('Covered', 'Gap'),
  process_steps.step_note AS NOTE COMMENT = 'Note, e.g. why the step is a gap',

  metadata_sources.src_key AS SOURCE_KEY COMMENT = 'sf, xls, doc, glo',
  metadata_sources.src_name AS SOURCE_NAME COMMENT = 'Metadata source name'
    SAMPLE_VALUES ('Snowflake Metadata', 'Uploaded Excel', 'Uploaded Word Document', 'Business Glossary'),
  metadata_sources.src_status AS SOURCE_STATUS COMMENT = 'Connected, Loaded, Sample or Not loaded',
  metadata_sources.src_detail AS DETAIL COMMENT = 'What is loaded, with counts',
  metadata_sources.src_provides AS PROVIDES COMMENT = 'What the source contributes',
  metadata_sources.src_owner AS OWNER_ROLE COMMENT = 'Who maintains the source (role)',
  metadata_sources.src_precedence AS PRECEDENCE COMMENT = '1 = most trusted when sources disagree',

  field_provenance.fp_sheet AS SHEET COMMENT = 'Mapping sheet name',
  field_provenance.fp_sheet_row AS SHEET_ROW COMMENT = 'Row in the mapping sheet',
  field_provenance.fp_model AS MODEL_NAME WITH SYNONYMS = ('table') COMMENT = 'FACT_ACCOUNT_PAYABLE_GBL or DM_FIN_AP_GBL_DETAILS'
    SAMPLE_VALUES ('FACT_ACCOUNT_PAYABLE_GBL', 'DM_FIN_AP_GBL_DETAILS'),
  field_provenance.fp_field AS FIELD_NAME WITH SYNONYMS = ('column', 'field') COMMENT = 'Field or column name',
  field_provenance.fp_business_name AS BUSINESS_NAME COMMENT = 'Business name',
  field_provenance.fp_entity AS ENTITY_ID COMMENT = 'Business entity of the field',
  field_provenance.fp_transformation_type AS TRANSFORMATION_TYPE COMMENT = 'Direct (pass-through), Direct with rule, Join / lookup, Join (multi-source), Calculated, Direct (from SAP), Rule / calculation',
  field_provenance.fp_sap_origin AS SAP_ORIGIN COMMENT = 'SAP table.field the value comes from',
  field_provenance.fp_mapping AS MAPPING COMMENT = 'Mapping rule as written in the workbook',
  field_provenance.fp_source_edw_table AS SOURCE_EDW_TABLE COMMENT = 'Source EDW table or view (data mart rows)',
  field_provenance.fp_definition AS BUSINESS_DEFINITION COMMENT = 'Business definition (approved, documented or inherited)',
  field_provenance.fp_definition_status AS DEFINITION_STATUS COMMENT = 'Approved, Documented in workbook, Draft (inherited from fact field), Draft (pending approval) or Missing'
    SAMPLE_VALUES ('Approved', 'Documented in workbook', 'Draft (inherited from fact field)', 'Missing'),
  field_provenance.fp_in_snowflake AS IN_SNOWFLAKE COMMENT = 'TRUE when the column exists in Snowflake',
  field_provenance.fp_data_type AS SNOWFLAKE_DATA_TYPE COMMENT = 'Data type with length from Snowflake',
  field_provenance.fp_sources AS METADATA_SOURCES COMMENT = 'Metadata sources that hold information about the field',
  field_provenance.fp_citation AS CITATION COMMENT = 'Sheet and row, e.g. AP_DM_Mapping row 3',

  entity_narrative.nar_entity AS ENTITY_ID COMMENT = 'Entity the paragraph is about',
  entity_narrative.nar_doc_id AS DOC_ID COMMENT = 'Document ID',
  entity_narrative.nar_para_no AS PARA_NO COMMENT = 'Paragraph number',
  entity_narrative.nar_file AS FILE_NAME COMMENT = 'Word file name',
  entity_narrative.nar_title AS DOC_TITLE COMMENT = 'Document title',
  entity_narrative.nar_status AS DOC_STATUS COMMENT = 'Loaded or Sample',
  entity_narrative.nar_text AS PARA_TEXT COMMENT = 'Paragraph text'
)

METRICS (
  entities.entity_count AS COUNT(ENTITY_ID) COMMENT = 'Number of business entities',
  relationships.relationship_count AS COUNT(REL_ID) COMMENT = 'Number of relationships',
  relationships.supported_relationship_count AS COUNT_IF(EVIDENCE_STATUS = 'Supported by workbook') COMMENT = 'Relationships supported by the workbook',
  field_provenance.field_count AS COUNT(FIELD_NAME) COMMENT = 'Number of fields',
  field_provenance.missing_definition_count AS COUNT_IF(DEFINITION_STATUS = 'Missing') WITH SYNONYMS = ('documentation gaps') COMMENT = 'Fields without a business definition'
)

COMMENT = 'Business ontology of the AP knowledge co-worker: domains, business entities, entity-to-table map, relationships with evidence, AP process steps, metadata sources and per-field provenance. Synthetic POC.'

AI_SQL_GENERATION 'Match entity names with ILIKE on entity_name or synonyms (for example AP Document = apdoc, invoice = inv, supplier = vendor, company code = entity). For "which tables hold <entity>" select from entity_objects filtered on obj_entity_id or obj_entity_name and show object role, object name, friendly name, Snowflake key, in Snowflake and evidence. For relationships of an entity select from relationships where rel_from_entity or rel_to_entity is the entity, and show from, relationship, to, evidence status and detail. For fields of an entity use field_provenance filtered on fp_entity (and fp_model if given). For metadata sources use metadata_sources ordered by src_precedence. For process questions use process_steps ordered by step_no. For what a Word document says use entity_narrative.'

AI_VERIFIED_QUERIES (
  vq_tables_for_entity AS (
    QUESTION 'Which tables hold AP Document?'
    VERIFIED_AT 1795046400
    ONBOARDING_QUESTION TRUE
    SQL 'SELECT obj_entity_name, obj_role, obj_object_name, obj_friendly_name, obj_snowflake_key, obj_in_snowflake, obj_evidence, obj_fields_in_workbook, obj_mart_columns_fed FROM entity_objects WHERE obj_entity_id = ''apdoc'' ORDER BY obj_role, obj_object_name'
  ),
  vq_entity_relationships AS (
    QUESTION 'How is a Vendor Invoice related to other business entities?'
    VERIFIED_AT 1795046400
    ONBOARDING_QUESTION TRUE
    SQL 'SELECT rel_from_name, rel_verb, rel_to_name, rel_evidence_status, rel_evidence_detail FROM relationships WHERE rel_from_entity = ''inv'' OR rel_to_entity = ''inv'' ORDER BY rel_id'
  ),
  vq_metadata_sources AS (
    QUESTION 'Which metadata sources are connected and what do they hold?'
    VERIFIED_AT 1795046400
    ONBOARDING_QUESTION TRUE
    SQL 'SELECT src_name, src_status, src_detail, src_provides, src_owner FROM metadata_sources ORDER BY src_precedence'
  ),
  vq_process_gaps AS (
    QUESTION 'Which AP process steps are not covered by the loaded data?'
    VERIFIED_AT 1795046400
    SQL 'SELECT step_no, step_name, step_workbook_objects, step_snowflake_objects, step_status, step_note FROM process_steps ORDER BY step_no'
  ),
  vq_vendor_fields AS (
    QUESTION 'Which data mart columns belong to the Vendor entity and how are they documented?'
    VERIFIED_AT 1795046400
    SQL 'SELECT fp_field, fp_business_name, fp_transformation_type, fp_source_edw_table, fp_definition_status, fp_sources FROM field_provenance WHERE fp_entity = ''vendor'' AND fp_model = ''DM_FIN_AP_GBL_DETAILS'' ORDER BY fp_sheet_row'
  ),
  vq_missing_definitions AS (
    QUESTION 'Which data mart columns still have no business definition?'
    VERIFIED_AT 1795046400
    SQL 'SELECT fp_field, fp_transformation_type, fp_source_edw_table, fp_mapping, fp_citation FROM field_provenance WHERE fp_model = ''DM_FIN_AP_GBL_DETAILS'' AND fp_definition_status = ''Missing'' ORDER BY fp_sheet_row'
  ),
  vq_payment_narrative AS (
    QUESTION 'What does the process document say about payments?'
    VERIFIED_AT 1795046400
    SQL 'SELECT nar_title, nar_status, nar_para_no, nar_text FROM entity_narrative WHERE nar_entity = ''pay'' ORDER BY nar_doc_id, nar_para_no'
  )
);

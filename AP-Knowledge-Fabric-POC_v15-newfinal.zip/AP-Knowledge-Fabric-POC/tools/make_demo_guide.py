"""Builds the demo guide PDF: run steps, 15-minute demo script, expected answers, likely questions, troubleshooting."""
import os

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (CondPageBreak, Image, PageBreak, Paragraph, Preformatted, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "AP_Knowledge_Fabric_POC_Demo_Guide.pdf")
ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontSize=18, spaceAfter=4, textColor=colors.HexColor("#0B2545"))
H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontSize=13, spaceBefore=10, spaceAfter=4, textColor=colors.HexColor("#13315C"))
H3 = ParagraphStyle("H3", parent=ss["Heading3"], fontSize=10.5, spaceBefore=6, spaceAfter=2)
P = ParagraphStyle("P", parent=ss["BodyText"], fontSize=9.6, leading=13, spaceAfter=4)
SM = ParagraphStyle("SM", parent=P, fontSize=8.5, textColor=colors.HexColor("#555555"))
CELL = ParagraphStyle("C", parent=P, fontSize=8.4, leading=10.8, spaceAfter=0)
CODE = ParagraphStyle("CODE", fontName="Courier", fontSize=8.2, leading=10.4, backColor=colors.HexColor("#F3F5F8"),
                      borderPadding=5, spaceBefore=3, spaceAfter=7)


def tbl(rows, widths, head=True):
    t = Table([[Paragraph(str(c), CELL) for c in r] for r in rows], colWidths=[w * cm for w in widths], repeatRows=1 if head else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#B8C2CF")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if head:
        st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E3ECF7")))
    t.setStyle(TableStyle(st))
    return t


def code(text):
    return Preformatted(text.strip("\n"), CODE)


def bullets(items):
    return [Paragraph("• " + i, P) for i in items]


def footer(c, d):
    c.saveState()
    c.setFont("Helvetica", 7.5)
    c.setFillColor(colors.HexColor("#777777"))
    c.drawString(2 * cm, 1.2 * cm, "AP Knowledge Fabric POC · synthetic data only · internal working document")
    c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"page {d.page}")
    c.restoreState()


s = []
s += [Paragraph("AP Knowledge Fabric POC: Run &amp; Demo Guide", H1),
      Paragraph("Cortex Agent over Snowflake metadata for an SAP-like Accounts Payable model · synthetic data, generic names", SM),
      Spacer(1, 6)]

s += [Paragraph("1. What the POC shows in one sentence", H2),
      Paragraph("A user asks in plain English how the AP data model works (objects, joins, field lineage, definitions, refresh, "
                "masking) and a Cortex Agent answers from <b>Snowflake's own metadata first</b> (comments, tags, masking policies, "
                "tasks, lineage), supported by a mapping sheet, a business glossary and project documents, with sources cited.", P),
      Image(os.path.join(ROOT, "assets", "architecture.png"), width=17 * cm, height=17 * cm * 595 / 2184),
      Spacer(1, 4),
      tbl([["Requirement question", "Where the answer comes from"],
           ["Which tables/views make up the AP model and how are they connected?",
            "KF_OBJECTS (INFORMATION_SCHEMA + tags) and KF_ASSET_RELATIONSHIPS (joins, load flows)"],
           ["Where does vendor country come from, back to source?",
            "KF_LINEAGE_PATHS (mapping sheet walked hop by hop) + FSD section 5.2 + Snowflake GET_LINEAGE"],
           ["How is AP aging defined, which buckets exist?",
            "KF_GLOSSARY (approved terms) + AP_AGING_BUCKETS + BRD section 3.2"],
           ["How often is the datamart refreshed, which fields are masked?",
            "REFRESH_FREQUENCY tag + live task schedule (KF_REFRESH_SCHEDULE); POLICY_REFERENCES + inherited masking"]],
          [7.5, 9.5])]

s += [CondPageBreak(8 * cm), Paragraph("2. Build it (about 10 minutes)", H2),
      Paragraph("Needs Enterprise edition, a role that can create a database/warehouse/roles and use Cortex (config.ADMIN_ROLE). "
                "Set the database name in <b>config.py</b> first (use the name agreed in the sandbox request).", P)]
s += bullets(["Snowsight → Projects → Workspaces → upload the whole <b>AP-Knowledge-Fabric-POC</b> folder (incl. docs/ PDFs).",
              "Create a notebook in that folder and run the cell below.",
              "Read the output: each file prints a green tick; a yellow circle means an optional statement was skipped (fine)."])
s += [code("""
import run
run.run()                        # 00 -> 13, ~5-10 min (AI_PARSE_DOCUMENT + search indexing are the slow parts)
run.check()                      # counts per component
run.demo_masking()               # same query as AP_KF_POWER_USER and AP_KF_BUSINESS_USER
run.lineage_preview("VENDOR_COUNTRY")
"""),
      tbl([["File", "Builds"],
           ["00 (optional)", "Cross-region Cortex models (ACCOUNTADMIN)"],
           ["01", "Warehouse (X-Small), database, 6 schemas, 2 persona roles"],
           ["02", "8 SAP-like landing tables, 300 vendors, 6,000 invoices (12,000 BSEG lines), ~4% one-time vendors"],
           ["03 / 04", "EDW fact + dims, datamart with aging; load procedures (INSERT OVERWRITE keeps tags/policies)"],
           ["05", "4 reporting views (rename / key filter only) + suspended daily tasks (02:00 UTC EDW, datamart after it)"],
           ["06 / 06b / 06c", "12 tags incl. data class, technical owner, key role; 4 masking policies; optional SYSTEM$CLASSIFY; primary / business key constraints"],
           ["07", "Mapping sheet, relationships, glossary, requirements + trace, mapping change log, report usage; key filters, KPIs, SAP T-code map (phase 2 preview); REFRESH_KNOWLEDGE_FABRIC (Python) reads metadata, builds lineage, impact and one data dictionary card per reporting view; AI_COMPLETE drafts"],
           ["08", "Uploads + parses 4 PDFs (BRD, FSD, governance, process &amp; EDW standards); 2 Cortex Search services"],
           ["09", "Semantic view KF_METADATA_MODEL (15 tables) with 17 verified queries"],
           ["10 / 11", "Agent AP_KNOWLEDGE_COWORKER (3 tools); evaluation dataset (26 questions)"],
           ["12 / 13", "Grants per persona; add the agent to Snowflake Intelligence (or do it in the UI)"]],
          [2.6, 14.4]),
      Paragraph("Expected <b>run.check()</b>: 19 objects (8 landing, 3 EDW, 4 datamart, 4 reporting) · 14 masked columns "
                "(10 direct + 4 inherited by views) · 4 reporting view cards · 22 T-code mappings · 6 undocumented columns + 1 undocumented table · ~1,300-1,400 open items "
                "spread over all 6 buckets · 3 refresh jobs · 12 requirements · 7 mapping changes · document pages/chunks &gt; 0. Snowflake lineage rows can be 0 right "
                "after the build: GET_LINEAGE fills in within a few hours; run <b>run.refresh()</b> before the demo to pick it up.", P)]

s += [PageBreak(), Paragraph("3. Demo script (15 minutes)", H2),
      tbl([["Min", "Show", "Say"],
           ["0-2", "Architecture slide (assets/architecture.png)",
            "The pilot question: can a co-worker explain the AP model to power users and new users from Snowflake metadata? "
            "Everything is synthetic; the structure mirrors a typical SAP → EDW → datamart → reporting flow."],
           ["2-4", "Snowsight Catalog: database → AP_DATAMART → DM_AP_OPEN_ITEMS: description, column comments, tags tab",
            "Metadata lives in Snowflake itself: comments as 'Business name: description', tags set once at database/schema "
            "level and inherited."],
           ["4-5", "Notebook: run.demo_masking()",
            "Same view, two roles: tax IDs and bank accounts masked for business users. The view has no policy of its own; "
            "it inherits from the datamart column."],
           ["5-11", "Snowflake Intelligence → AP Knowledge Co-worker: questions A-O below",
            "Point at the tool calls (analyst, catalog search, document search) and the Sources line in each answer."],
           ["11-13", "KF_COLUMNS where HAS_DESCRIPTION = FALSE, and KF_DESCRIPTION_SUGGESTIONS",
            "Gap detection: 6 columns lack descriptions; AI_COMPLETE drafted them, status 'awaiting steward approval'. "
            "AI suggests, people approve."],
           ["13-15", "Roadmap (section 5)", "What the real implementation needs and the next steps."]],
          [1.2, 6.3, 9.5])]

s += [Paragraph("Questions to ask, and what a good answer contains", H3),
      tbl([["#", "Ask", "Good answer contains"],
           ["A", "Which tables and views make up the AP model, and how are they connected?",
            "4 layers with the 18 objects; FACT → DIM_VENDOR on VENDOR_ID, → DIM_COMPANY_CODE on COMPANY_CODE; BSEG → BKPF on "
            "BUKRS/BELNR/GJAHR, BSEG → BSEC incl. BUZEI; reporting views read only the datamart."],
           ["B", "Where does vendor country in the AP open items report come from, back to the source?",
            "VW_AP_OPEN_ITEMS.VENDOR_COUNTRY ← DM_AP_OPEN_ITEMS.VENDOR_COUNTRY_NAME (rename) ← regular vendors: "
            "DIM_VENDOR.VENDOR_COUNTRY_NAME ← SAP_LFA1.LAND1 + SAP_T005T; one-time vendors: FACT.ONE_TIME_VENDOR_COUNTRY_NAME "
            "← SAP_BSEC.LAND1 + SAP_T005T. Cites mapping sheet and FSD 5.2."],
           ["C", "How is AP aging defined, and which aging buckets exist?",
            "Days past due = as-of date − net due date (baseline + term days); 6 buckets Not yet due, 1-30, 31-60, 61-90, "
            "91-180, Over 180; approved, BRD v1.2. Bonus: notes 90+ from v1.0 is superseded."],
           ["D", "How often is the AP datamart refreshed, and which fields are masked?",
            "Daily right after the 02:00 UTC EDW load (TASK_LOAD_AP_DATAMART), ~02:15, target 04:00; masked: DM_AP_VENDOR tax "
            "ID + bank account, DM_AP_OPEN_ITEMS.VENDOR_NAME (one-time payees only), inherited by the 3 view columns."],
           ["E", "I'm new to AP reporting. What does the AP open items view show and who owns it?",
            "Plain-English explanation, grain one row per open vendor line, owner AP Finance Data Owner (role), steward role, "
            "certified, refreshed daily."],
           ["F", "What is the total open amount owed to vendors in Germany?",
            "Declines politely (values out of scope for the metadata pilot) and points to VW_AP_AGING_SUMMARY.OPEN_AMOUNT_USD "
            "by VENDOR_COUNTRY."],
           ["H", "What is affected if the vendor master country field changes?",
            "EDW DIM_VENDOR country columns → datamart country columns in 3 tables → VENDOR_COUNTRY in 3 views → AP Aging "
            "Dashboard, AP Open Items Worklist, Vendor Master Audit Report (with owners). Not the treasury extract."],
           ["I", "Which requirements cover vendor payment terms? Which requirements trace to DM_AP_OPEN_ITEMS?",
            "AP-R08 and AP-R02. Trace to DM_AP_OPEN_ITEMS: AP-R01, R02, R03, R04, R07."],
           ["J", "What changed in the vendor country mapping, and why? How was it reviewed?",
            "CHG-002: one-time vendor country source corrected from BSEG to BSEC after a UAT defect; Gate 2 test sign-off by "
            "the steward, approved by the data owner."],
           ["K", "Is the open amount in USD the same in the AP Aging Dashboard and the treasury extract?",
            "Yes: both trace to DM_AP_OPEN_ITEMS.AMOUNT_USD (one definition); the dashboard reads the summarised version."],
           ["L", "What are the invoice-to-pay steps, and which naming standard applies to a new datamart table?",
            "Receipt, matching, exception/approval, posting, payment run, reconciliation; DM_ prefix, upper case, comments, tags."],
           ["M", "Show the data dictionary card for VW_AP_OPEN_ITEMS (then: list its columns with type, key and descriptions)",
            "All attributes in one answer: schema, description, transaction data, Finance / AP, owners, refresh + job, business "
            "key, masked columns, datamart source, upstream + SAP fields, consumers, key filters, KPIs, alternative view "
            "VW_AP_OVERDUE_ITEMS, requirements."],
           ["N", "A request asks for the data in T-code FBL1N. Do we already have it in EDW?",
            "Field by field: 6 validated in the AP fact (reuse); BSEG.ZUONR not ingested (new replication). Says it is a phase 2 preview."],
           ["O", "We need the vendor payment methods. Do we need new replication?",
            "No: LFB1.ZWELS is already in landing but not modelled; extend the EDW. Shows the AI draft description for the gap."],
           ["G", "What is the official definition of overdue amount?",
            "Says it is a Draft term, not yet official, and names the open question in the BRD."]],
          [0.7, 5.6, 10.7]),
      Paragraph("Rehearse A-O once before the call. If an answer is weak, check the tool trace (which tool, which SQL) "
                "before changing instructions: most fixes belong in metadata or verified queries, not in the prompt.", SM)]

s += [CondPageBreak(9 * cm), Paragraph("Coverage of the requirement list: attributes per reporting view", H3),
      tbl([["Requested attribute", "Where it comes from in the POC"],
           ["EDW database / schema, table and view names, column names", "INFORMATION_SCHEMA (live)"],
           ["Data type / character limit", "INFORMATION_SCHEMA: VARCHAR(n), NUMBER(p,s), character limit"],
           ["Primary and business keys", "Primary / unique key constraints on tables; KEY_ROLE tag on views"],
           ["Business-friendly name and description", "Column comment 'Business name: description'"],
           ["Technical description", "Built from type, key, SAP field, masking, source and rule"],
           ["Model / table description", "Object comment (source + grain); AI draft where missing"],
           ["Transaction / master data classification", "DATA_CLASS tag"],
           ["Transformation / business rules, lineage, S2T mappings", "Mapping sheet + lineage paths + Snowflake GET_LINEAGE"],
           ["Existing KPI definitions, KPI calculations", "Glossary terms of type KPI (5), with status"],
           ["Portfolio / domain, data / model owner, technical owner", "DATA_DOMAIN, DATA_PRODUCT, DATA_OWNER, TECHNICAL_OWNER tags"],
           ["Refresh frequency / schedule", "REFRESH_FREQUENCY tag + live task schedule"],
           ["Upstream / downstream dependencies", "Load flows, lineage, impact table, report usage"],
           ["Key filters in reports", "KF_KEY_FILTERS (EDW load, datamart load, view, report)"],
           ["Alternative reporting views on the same DM table", "Computed: VW_AP_OPEN_ITEMS and VW_AP_OVERDUE_ITEMS share DM_AP_OPEN_ITEMS"],
           ["Phase 2: T-code, description, process, SAP tables/fields + descriptions, related EDW tables/fields, "
            "mapping validation status and owner", "KF_SAP_TCODE_MAP preview: 7 T-codes, 22 fields (standard SAP names, synthetic status)"]],
          [7.5, 9.5]),
      Paragraph("Everything is in one row per view in KF_REPORTING_VIEWS (the data dictionary card); run.view_card() shows it.", SM)]

s += [CondPageBreak(9 * cm), Paragraph("Coverage of the phased question roadmap (AP versions of the example questions)", H3),
      tbl([["Roadmap stage", "Answered by the POC", "Not in the POC"],
           ["Finance documents", "Aging definition, requirements for payment terms, invoice-to-pay steps, period-end close, chart "
                                 "of accounts (synthetic documents)", "Real finance process documents"],
           ["EDW work", "Tables behind a report, field lineage to source, extract filter (account type K, open items), load "
                        "jobs and frequency, mapping changes and why", "-"],
           ["Semantic layer", "Definitions, difference between two vendor types, business term of a field, same measure in "
                              "two reports", "Measures over AP values (out of scope: metadata only)"],
           ["Context engineering", "Naming standards, release review gates, worked mapping example, masking rules, how a "
                                   "mapping was prepared and reviewed", "-"],
           ["Ontology / knowledge graph", "Impact of a change, reports depending on a field, requirements tracing to a table, "
                                         "systems involved (relational tables, not yet a graph)", "Graph store, cross-domain links "
                                                                                                 "(AP to GL postings)"]],
          [3.4, 9.2, 4.4])]

s += [CondPageBreak(10 * cm), Paragraph("4. Questions the client may ask", H2),
      tbl([["Question", "Answer"],
           ["Is this using our data?", "No. Synthetic data, generic names, synthetic documents. The structure is a generic "
                                       "SAP AP pattern so the approach transfers."],
           ["What is real Snowflake metadata vs curated?",
            "Real: comments, tags (incl. inheritance), masking policies, tasks/schedules, GET_LINEAGE, classification. Curated "
            "(as from project documents): mapping sheet with transformation rules, relationships, glossary."],
           ["Why not only Snowflake lineage?",
            "System lineage shows which columns feed which, but not conditions such as 'BSEC for one-time vendors, otherwise "
            "LFA1'. The mapping sheet adds the rule; both are shown and can be cross-checked."],
           ["How does it stay current?",
            "REFRESH_KNOWLEDGE_FABRIC re-reads metadata; a task runs it after the datamart load. Search services refresh daily."],
           ["What if documents and metadata disagree?",
            "Agent instruction: Snowflake metadata > approved glossary > mapping sheet > documents; it shows both and says so."],
           ["Can it see sensitive values?", "No. It reads metadata only; masking still applies to the user's role; the agent "
                                            "is told never to show or guess masked values."],
           ["Where does Business Ontology fit?",
            "The glossary already has owner, status and source per term, which is the shape an ontology needs. When the "
            "feature is available for the account, terms can move there; today everything uses GA features."],
           ["How is quality measured?", "26-question evaluation dataset (KF_EVAL_DATASET) for Snowsight agent evaluations, "
                                        "plus verified queries in the semantic view."],
           ["Is this a knowledge graph?", "Not yet a graph store: the same nodes and edges (objects, columns, mappings, "
                                          "requirements, reports, changes) are held as tables, which already answer impact and "
                                          "traceability. They can be loaded into an ontology / graph later without re-work."],
           ["Cost?", "X-Small warehouse, auto-suspend 60 s, tasks suspended; a handful of AI_COMPLETE calls; parsing 7 PDF pages."]],
          [4.6, 12.4])]

s += [Paragraph("5. Roadmap after the POC (suggested)", H2)]
s += bullets(["Run sql/optional/metadata_inventory.sql in the real account (by the account owner) to measure comment coverage, "
              "tags, policies, dependencies and classification for the finance domain.",
              "Replace the curated mapping sheet with the project's real mapping sheets; keep the same KF_FIELD_MAPPING shape.",
              "Steward workflow: approve AI drafts and write them back as comments (ALTER ... COMMENT).",
              "Phase 2 scope: more AP-adjacent models, document-only models, transaction-code questions.",
              "Evaluation in Snowsight on KF_EVAL_DATASET before and after each change."])

s += [Paragraph("6. Troubleshooting", H2),
      tbl([["Symptom", "Fix"],
           ["'Unsupported feature' on masking/tags", "Account is not Enterprise. Masking and tags need Enterprise or higher."],
           ["AI_COMPLETE / agent model not available", "Run 00_cortex_access.sql as ACCOUNTADMIN, or set config.AI_MODEL to a "
                                                       "model available in the region (e.g. mistral-large2) and rerun 07."],
           ["upload_documents error / 0 chunks", "Upload docs/*.pdf to KNOWLEDGE_FABRIC.KF_DOCUMENTS in the UI, then "
                                                 "run.run(run.SQL_FILES[9:])."],
           ["Semantic view: verified queries rejected", "run.py creates it without them and says so; add them in the semantic "
                                                         "view editor (Verified queries)."],
           ["KF objects have empty tags", "Tag functions failed for the role: run.refresh() and read the Notes in the output; "
                                          "layer still comes from the schema name."],
           ["Snowflake lineage rows = 0", "Normal right after the build; run.refresh() a few hours later."],
           ["Agent not in Snowflake Intelligence", "AI & ML → Agents → AP Knowledge Co-worker → add to Snowflake Intelligence; "
                                                   "make sure your role has USAGE on the agent."],
           ["Business user sees unmasked values", "Check CURRENT_ROLE(): policies use the current role, so run "
                                                  "USE ROLE AP_KF_BUSINESS_USER."]],
          [5.4, 11.6])]

SimpleDocTemplate(OUT, pagesize=A4, title="AP Knowledge Fabric POC - Run & Demo Guide", leftMargin=2 * cm, rightMargin=2 * cm,
                  topMargin=1.7 * cm, bottomMargin=2 * cm).build(s, onFirstPage=footer, onLaterPages=footer)
print("created", OUT)

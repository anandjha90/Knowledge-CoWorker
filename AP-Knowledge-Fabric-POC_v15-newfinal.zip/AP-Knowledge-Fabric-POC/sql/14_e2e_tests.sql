-- =====================================================================
-- 14 END-TO-END TESTS: the AP model against the mapping workbook (run: run.test())
--   Every row = one check with expected value, actual value and PASS / FAIL.
--   Structure (names, counts), metadata (mapping text = workbook), and data (each formula recomputed).
-- =====================================================================
WITH
f AS (SELECT * FROM {{DATABASE}}.{{EDW}}.FACT_ACCOUNT_PAYABLE_GBL),
d AS (SELECT * FROM {{DATABASE}}.{{DATAMART}}.DM_FIN_AP_GBL_DETAILS),
fd AS (
  SELECT d.*, f.AMT_USD_ME AS F_AMT_USD_ME, f.DAYS_TO_PAY AS F_DAYS_TO_PAY
  FROM d JOIN f ON f.COMPANY_CODE = d.COMPANY_CODE AND f.ACCOUNTING_DOC = d.ACCOUNTING_DOC
              AND f.FISCAL_YEAR = d.FISCAL_YEAR AND f.ACCOUNTING_DOC_LINE_ITEM = d.ACCOUNTING_DOC_LINE_ITEM
),
cols AS (
  SELECT TABLE_SCHEMA, TABLE_NAME, COUNT(*) AS N
  FROM {{DATABASE}}.INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME IN ('FACT_ACCOUNT_PAYABLE_GBL', 'DM_FIN_AP_GBL_DETAILS', 'VW_FIN_AP_INV_DETAILS',
                       'VW_FIN_AP_CLOSING_BALANCE', 'VW_FIN_AP_VENDOR_PAYMENT')
  GROUP BY 1, 2
),
xl AS (SELECT * FROM {{DATABASE}}.{{KF}}.KF_EXCEL_MAPPING_SHEET),
checks (TEST_ID, AREA, TEST, EXPECTED, ACTUAL) AS (
  -- ---------------- structure: same names as the workbook
  SELECT 'S01', 'Structure', 'FACT_ACCOUNT_PAYABLE_GBL has the 113 columns of the AP FACT sheet',
         '113', TO_VARCHAR((SELECT MAX(N) FROM cols WHERE TABLE_NAME = 'FACT_ACCOUNT_PAYABLE_GBL'))
  UNION ALL SELECT 'S02', 'Structure', 'DM_FIN_AP_GBL_DETAILS has the 174 columns of the AP DM sheet',
         '174', TO_VARCHAR((SELECT MAX(N) FROM cols WHERE TABLE_NAME = 'DM_FIN_AP_GBL_DETAILS'))
  UNION ALL SELECT 'S03', 'Structure', 'The 3 reporting views exist with 174 columns each',
         '3', TO_VARCHAR((SELECT COUNT(*) FROM cols WHERE TABLE_NAME LIKE 'VW_FIN_AP_%' AND N = 174))
  UNION ALL SELECT 'S04', 'Structure', 'Every field of both sheets exists as a physical column (missing)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM xl WHERE NOT EXISTS (
             SELECT 1 FROM {{DATABASE}}.INFORMATION_SCHEMA.COLUMNS c
             WHERE c.TABLE_SCHEMA = xl.SCHEMA_NAME AND c.TABLE_NAME = xl.MODEL_NAME AND c.COLUMN_NAME = xl.FIELD_NAME)))
  UNION ALL SELECT 'S05', 'Structure', 'Workbook rows loaded (113 FACT + 174 DM)', '287', TO_VARCHAR((SELECT COUNT(*) FROM xl))
  UNION ALL SELECT 'S06', 'Structure', 'DM rows = FACT rows (one DM row per AP line)',
         TO_VARCHAR((SELECT COUNT(*) FROM f)), TO_VARCHAR((SELECT COUNT(*) FROM fd))
  -- ---------------- metadata: what the agent reads = the workbook
  UNION ALL SELECT 'M01', 'Metadata', 'Data dictionary mapping text = workbook mapping text (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM xl JOIN {{DATABASE}}.{{KF}}.KF_BUSINESS_DATA_DICTIONARY dd
             ON dd.EDW_MODEL_NAME = xl.MODEL_NAME AND dd.EDW_FIELD_NAME = xl.FIELD_NAME WHERE dd.MAPPING IS DISTINCT FROM xl.MAPPING))
  UNION ALL SELECT 'M02', 'Metadata', 'DM AMT_USD_ME mapping is the DISBURSEMENTS rule from the sheet',
         'IFF(METRIC_TYPE = ''DISBURSEMENTS'', ...)', (SELECT LEFT(MAPPING, 40) || '...' FROM xl WHERE MODEL_NAME = 'DM_FIN_AP_GBL_DETAILS' AND FIELD_NAME = 'AMT_USD_ME')
  UNION ALL SELECT 'M03', 'Metadata', 'Lineage exists for VW_FIN_AP_INV_DETAILS.AMT_USD_ME (steps)',
         '>= 2', TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_LINEAGE_PATHS
             WHERE REPORT_OBJECT ILIKE '%VW_FIN_AP_INV_DETAILS' AND REPORT_COLUMN = 'AMT_USD_ME'))
  UNION ALL SELECT 'M04', 'Metadata', 'Load SQL of FACT and DM stored for the agent', '2',
         TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_LOAD_SCRIPTS WHERE SCRIPT_NAME IN ('LOAD_FACT_ACCOUNT_PAYABLE_GBL', 'LOAD_DM_FIN_AP_GBL_DETAILS')))
  UNION ALL SELECT 'M05', 'Metadata', 'KPI definitions AWPT and AWPOT in the glossary', '2',
         TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_GLOSSARY WHERE TERM ILIKE '%(AWPT)%' OR TERM ILIKE '%(AWPOT)%'))
  -- ---------------- FACT data follows the AP FACT sheet
  UNION ALL SELECT 'F01', 'FACT logic', 'AMT_DOC: IFF(SHKZG = H, WRBTR * -1, WRBTR) -> credit (H) lines negative (violations)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE (DEBIT_CREDIT_FLAG = 'H' AND AMT_DOC > 0) OR (DEBIT_CREDIT_FLAG = 'S' AND AMT_DOC < 0)))
  UNION ALL SELECT 'F02', 'FACT logic', 'AMT_USD_ME = NVL(AMT_DOC x month-end USD rate, 0) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f LEFT JOIN {{DATABASE}}.{{EDW}}.DIM_CURRENCY_RATE_MONTHLY r
             ON r.CURRENCY = f.DOC_CURR AND r.RATE_MONTH = DATE_TRUNC('month', f.POSTING_DATE)
             WHERE ABS(f.AMT_USD_ME - ROUND(NVL(f.AMT_DOC * r.USD_RATE_ME, 0), 2)) > 0.02))
  UNION ALL SELECT 'F03', 'FACT logic', 'AMT_USD_MA = NVL(AMT_DOC x monthly-average USD rate, 0) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f LEFT JOIN {{DATABASE}}.{{EDW}}.DIM_CURRENCY_RATE_MONTHLY r
             ON r.CURRENCY = f.DOC_CURR AND r.RATE_MONTH = DATE_TRUNC('month', f.POSTING_DATE)
             WHERE ABS(f.AMT_USD_MA - ROUND(NVL(f.AMT_DOC * r.USD_RATE_MA, 0), 2)) > 0.02))
  UNION ALL SELECT 'F04', 'FACT logic', 'AWPT_NUMERATOR = AMT_USD_MA x DAYS_TO_PAY (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE ABS(AWPT_NUMERATOR - AMT_USD_MA * DAYS_TO_PAY) > 0.05))
  UNION ALL SELECT 'F05', 'FACT logic', 'AWPOT_NUMERATOR = AMT_USD_MA x DAYS_OFFERED_TERMS (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE ABS(AWPOT_NUMERATOR - AMT_USD_MA * DAYS_OFFERED_TERMS) > 0.05))
  UNION ALL SELECT 'F06', 'FACT logic', 'AWPT_DENOMINATOR / AWPOT_DENOMINATOR = NVL(AMT_DOC x MA rate, 0) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE AWPT_DENOMINATOR <> AMT_USD_MA OR AWPOT_DENOMINATOR <> AMT_USD_MA))
  UNION ALL SELECT 'F07', 'FACT logic', 'CURRENT_STATUS = IFF(CLEARING_DATE IS NULL, Unpaid, Paid) (violations)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE CURRENT_STATUS <> IFF(CLEARING_DATE IS NULL, 'Unpaid', 'Paid')))
  UNION ALL SELECT 'F08', 'FACT logic', 'DAYS_TO_PAY = CASE open: CURRENT_DATE - DOCUMENT_DATE, paid: DATEDIFF(DAY, CLEARING_DATE, DOCUMENT_DATE) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE DAYS_TO_PAY <> CASE WHEN CLEARING_DATE IS NULL THEN CURRENT_DATE() - DOCUMENT_DATE
                                                                           ELSE DATEDIFF(DAY, CLEARING_DATE, DOCUMENT_DATE) END))
  UNION ALL SELECT 'F09', 'FACT logic', 'NET_DUE_DATE = BASELINE_PAYMENT_DATE + NET_PAY_TERMS_PERIOD (ZBD3T branch) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE NET_DUE_DATE <> DATEADD(day, NET_PAY_TERMS_PERIOD, BASELINE_PAYMENT_DATE)))
  UNION ALL SELECT 'F10', 'FACT logic', 'VENDOR_SK never empty (9999999999 rule) (violations)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM f WHERE VENDOR_SK IS NULL OR TRIM(VENDOR_SK) = ''))
  UNION ALL SELECT 'F11', 'FACT logic', 'SOURCE_SYSTEM = CONCAT(ARP, MANDT) (values)',
         'ARP900', (SELECT LISTAGG(DISTINCT SOURCE_SYSTEM, ', ') FROM f)
  -- ---------------- DM data follows the AP DM sheet
  UNION ALL SELECT 'D01', 'DM logic', 'METRIC_TYPE = IFF(PAID, DISBURSEMENTS, AP_SPEND_TYPE) (violations)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE (UPPER(CURRENT_STATUS) = 'PAID') <> (METRIC_TYPE = 'DISBURSEMENTS')))
  UNION ALL SELECT 'D02', 'DM logic', 'AMT_USD_ME = IFF(METRIC_TYPE = DISBURSEMENTS, FACT.AMT_USD_ME * -1, FACT.AMT_USD_ME) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE AMT_USD_ME <> IFF(METRIC_TYPE = 'DISBURSEMENTS', F_AMT_USD_ME * -1, F_AMT_USD_ME)))
  UNION ALL SELECT 'D03', 'DM logic', 'OPEN_CLOSE_FLAG = IFF(CLEARING_DATE IS NULL, OPEN, CLOSE) (violations)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE OPEN_CLOSE_FLAG <> IFF(CLEARING_DATE IS NULL, 'OPEN', 'CLOSE')))
  UNION ALL SELECT 'D04', 'DM logic', 'DAYS_LATE = IFF(UNPAID, DATEDIFF(DAY, NET_DUE_DATE, CURRENT_DATE), NULL) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE DAYS_LATE IS DISTINCT FROM
             IFF(UPPER(CURRENT_STATUS) = 'UNPAID', DATEDIFF('DAY', NET_DUE_DATE, CURRENT_DATE()), NULL)))
  UNION ALL SELECT 'D05', 'DM logic', 'AGING_FLAG bands from DAYS_LATE (1-30 ... 361+, CURRENT) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE AGING_FLAG IS DISTINCT FROM
             CASE WHEN DAYS_LATE > 0 AND DAYS_LATE <= 30 THEN '1-30' WHEN DAYS_LATE > 30 AND DAYS_LATE <= 60 THEN '31-60'
                  WHEN DAYS_LATE > 60 AND DAYS_LATE <= 90 THEN '60-90' WHEN DAYS_LATE > 90 AND DAYS_LATE <= 120 THEN '91-120'
                  WHEN DAYS_LATE > 120 AND DAYS_LATE <= 150 THEN '121-150' WHEN DAYS_LATE > 150 AND DAYS_LATE <= 180 THEN '151-180'
                  WHEN DAYS_LATE > 180 AND DAYS_LATE <= 360 THEN '181-360' WHEN DAYS_LATE > 360 THEN '361+'
                  WHEN DAYS_LATE <= 0 THEN 'CURRENT' END))
  UNION ALL SELECT 'D06', 'DM logic', 'CURRENT + PAST_DUE = ROUND(AMT_USD_ME, 2) for unpaid lines (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE UPPER(CURRENT_STATUS) = 'UNPAID'
             AND ABS(CURRENT_AMT_USD_ME + PAST_DUE_AMT_USD_ME - ROUND(AMT_USD_ME, 2)) > 0.01))
  UNION ALL SELECT 'D07', 'DM logic', 'Aging band amounts (1-30 ... 181-360 + over 360) = PAST_DUE (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE ABS(AGING_1_30_DAYS_AMT_USD_ME + AGING_31_60_DAYS_AMT_USD_ME + AGING_61_90_DAYS_AMT_USD_ME
             + AGING_91_120_DAYS_AMT_USD_ME + AGING_121_150_DAYS_AMT_USD_ME + AGING_151_180_DAYS_AMT_USD_ME
             + AGING_181_360_DAYS_AMT_USD_ME + OVER_360_DAYS_AMT_USD_ME - PAST_DUE_AMT_USD_ME) > 0.05))
  UNION ALL SELECT 'D08', 'DM logic', 'AWPT_DENOMINATOR never negative (sheet: negatives and credit pairs -> 0) (violations)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE AWPT_DENOMINATOR < 0))
  UNION ALL SELECT 'D09', 'DM logic', 'WEIGHTED_ACT_PAYMENT = DAYS_TO_PAY x AMT_USD_ME (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE ABS(WEIGHTED_ACT_PAYMENT - IFF(DAYS_TO_PAY IS NOT NULL, DAYS_TO_PAY * AMT_USD_ME, 0)) > 0.05))
  UNION ALL SELECT 'D10', 'DM logic', 'TERMS_DAYS = DATEDIFF(DAY, DOCUMENT_DATE, NET_DUE_DATE) (mismatches)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE TERMS_DAYS <> DATEDIFF('DAY', DOCUMENT_DATE, NET_DUE_DATE)))
  UNION ALL SELECT 'D11', 'DM logic', 'SCENARIO = IFF(PAID, Actual, Forecast) (violations)',
         '0', TO_VARCHAR((SELECT COUNT(*) FROM fd WHERE SCENARIO <> IFF(UPPER(CURRENT_STATUS) = 'PAID', 'Actual', 'Forecast')))
  -- ---------------- reporting views
  UNION ALL SELECT 'R01', 'Reporting', 'VW_FIN_AP_INV_DETAILS rows = DM rows',
         TO_VARCHAR((SELECT COUNT(*) FROM d)), TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{REPORTING}}.VW_FIN_AP_INV_DETAILS))
  UNION ALL SELECT 'R02', 'Reporting', 'VW_FIN_AP_CLOSING_BALANCE rows = open DM rows',
         TO_VARCHAR((SELECT COUNT(*) FROM d WHERE OPEN_CLOSE_FLAG = 'OPEN')), TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{REPORTING}}.VW_FIN_AP_CLOSING_BALANCE))
  UNION ALL SELECT 'R03', 'Reporting', 'VW_FIN_AP_VENDOR_PAYMENT rows = paid DM rows',
         TO_VARCHAR((SELECT COUNT(*) FROM d WHERE UPPER(CURRENT_STATUS) = 'PAID')), TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{REPORTING}}.VW_FIN_AP_VENDOR_PAYMENT))
  -- ---------------- business ontology, process context, metadata sources, reports (07d, client demo feedback)
  UNION ALL SELECT 'O01', 'Ontology', 'Business entities (12 live AP + 7 planned shells)', '19 / 12',
         (SELECT COUNT(*) || ' / ' || COUNT_IF(ENTITY_STATUS = 'Live') FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITIES)
  UNION ALL SELECT 'O02', 'Ontology', 'Relationships: total / supported by the workbook', '26 / 10',
         (SELECT COUNT(*) || ' / ' || COUNT_IF(EVIDENCE_STATUS = 'Supported by workbook') FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_RELATIONSHIPS)
  UNION ALL SELECT 'O03', 'Ontology', 'Live entities with no table in the workbook (only Goods Receipt)', 'gr',
         (SELECT LISTAGG(e.ENTITY_ID, ',') FROM {{DATABASE}}.{{KF}}.KF_ONTOLOGY_ENTITIES e
          WHERE e.ENTITY_STATUS = 'Live' AND NOT EXISTS (SELECT 1 FROM {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECTS o
                                                         WHERE o.ENTITY_ID = e.ENTITY_ID AND o.EVIDENCE = 'Uploaded Excel'))
  UNION ALL SELECT 'O04', 'Ontology', 'Objects mapped to Snowflake that are missing in the account', '0',
         TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_ENTITY_OBJECTS WHERE SNOWFLAKE_KEY IS NOT NULL AND NOT IN_SNOWFLAKE))
  UNION ALL SELECT 'O05', 'Ontology', 'Process steps with a gap (Goods receipt)', 'Goods receipt',
         (SELECT LISTAGG(STEP_NAME, ',') FROM {{DATABASE}}.{{KF}}.KF_PROCESS_COVERAGE WHERE STEP_STATUS = 'Gap')
  UNION ALL SELECT 'O06', 'Sources', 'Metadata source status: Snowflake / Excel', 'Connected / Loaded',
         (SELECT MAX(IFF(SOURCE_KEY = 'sf', SOURCE_STATUS, NULL)) || ' / ' || MAX(IFF(SOURCE_KEY = 'xls', SOURCE_STATUS, NULL))
          FROM {{DATABASE}}.{{KF}}.KF_METADATA_SOURCES)
  UNION ALL SELECT 'O07', 'Sources', 'Field provenance rows / fields without a business entity', '287 / 0',
         (SELECT COUNT(*) || ' / ' || COUNT_IF(ENTITY_ID IS NULL) FROM {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE)
  UNION ALL SELECT 'O08', 'Sources', 'Workbook fields found as Snowflake columns', '287',
         TO_VARCHAR((SELECT COUNT_IF(IN_SNOWFLAKE) FROM {{DATABASE}}.{{KF}}.KF_FIELD_PROVENANCE))
  UNION ALL SELECT 'O09', 'Reports', 'Source-to-target and column lineage reports: one row per mart column', '174 / 174',
         (SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_RPT_SOURCE_TO_TARGET) || ' / ' || (SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_RPT_COLUMN_LINEAGE)
  UNION ALL SELECT 'O10', 'Reports', 'Mart columns traced to all 3 reporting views', '174',
         TO_VARCHAR((SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_RPT_COLUMN_LINEAGE WHERE ARRAY_SIZE(SPLIT(REPORTING_VIEWS, ',')) = 3))
  UNION ALL SELECT 'O11', 'Reports', 'Entity map / relationship report rows', '19 / 26',
         (SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_RPT_ENTITY_OBJECT_MAP) || ' / ' || (SELECT COUNT(*) FROM {{DATABASE}}.{{KF}}.KF_RPT_ENTITY_RELATIONSHIPS)
  UNION ALL SELECT 'O12', 'Sources', 'Sample Word narrative linked to entities', '8',
         TO_VARCHAR((SELECT COUNT(DISTINCT ENTITY_ID) FROM {{DATABASE}}.{{KF}}.KF_ENTITY_NARRATIVE WHERE DOC_ID = 'SAMPLE_AP_PROCESS'))
  UNION ALL SELECT 'O13', 'Personas', 'Persona test questions: Data Engineer / Data Architect / Functional Owner', '7 / 8 / 8',
         (SELECT COUNT_IF(PERSONA = 'Data Engineer') || ' / ' || COUNT_IF(PERSONA = 'Data Architect') || ' / ' || COUNT_IF(PERSONA = 'Functional Owner')
          FROM {{DATABASE}}.{{KF}}.KF_PERSONA_QUESTIONS)
)
SELECT TEST_ID, AREA, TEST, EXPECTED, ACTUAL,
       CASE WHEN EXPECTED = ACTUAL THEN 'PASS'
            WHEN EXPECTED = '>= 2' AND TRY_TO_NUMBER(ACTUAL) >= 2 THEN 'PASS'
            WHEN EXPECTED LIKE '%...%' AND ACTUAL LIKE 'IFF(METRIC_TYPE = ''DISBURSEMENTS''%' THEN 'PASS'
            ELSE 'FAIL' END AS RESULT
FROM checks
ORDER BY TEST_ID;

-- =====================================================================
-- 11b PERSONA TEST QUESTIONS (Data Engineer, Data Architect, Functional Owner)
--   Anand's 18 questions (taken from the mapping workbook), 5 of them reworded where the question assumed
--   something the workbook does not say, plus 5 added questions for the v15 parts and for honest
--   "not in the loaded metadata" answers. Expected answers are checked against the AP mapping workbook.
--   * KF_PERSONA_QUESTIONS: the app shows these as starter questions per role (edit here, no redeploy).
--   * Also appended to KF_EVAL_DATASET (11) for Snowsight agent evaluations (QUESTION_ID P01-P23).
-- =====================================================================
USE WAREHOUSE {{WAREHOUSE}};

CREATE OR REPLACE TABLE {{DATABASE}}.{{KF}}.KF_PERSONA_QUESTIONS (
  QUESTION_ID     VARCHAR COMMENT 'P01-P23.',
  PERSONA         VARCHAR COMMENT 'Data Engineer, Data Architect or Functional Owner.',
  SORT_ORDER      NUMBER  COMMENT 'Order within the persona.',
  QUESTION        VARCHAR COMMENT 'Question as shown in the app.',
  EXPECTED_ANSWER VARCHAR COMMENT 'Facts a correct answer must contain (from the mapping workbook).',
  ORIGIN          VARCHAR COMMENT 'Anand, Anand (reworded) or Added.',
  NOTE            VARCHAR COMMENT 'Why it was reworded or added.'
) COMMENT = 'Persona test questions: starter questions in the app and agent evaluation set.';

INSERT INTO {{DATABASE}}.{{KF}}.KF_PERSONA_QUESTIONS VALUES
-- ---------------------------------------------------------------- Data Engineer
('P01', 'Data Engineer', 1,
 $$How is VENDOR_NAME populated in DM_FIN_AP_GBL_DETAILS, including all source tables, join conditions, and transformation logic?$$,
 $$VENDOR_NAME comes from CORP_MASTER.DIM_VENDOR_GEN, joined on SOURCE_SYSTEM and VENDOR_SK (no transformation, field exposed as is). VENDOR_SK is passed through from FACT_ACCOUNT_PAYABLE_GBL, where it is BSEG.LIFNR, or '9999999999' when LIFNR is empty. SOURCE_SYSTEM is CONCAT('ARP', BSEG.MANDT).$$,
 'Anand', NULL),
('P02', 'Data Engineer', 2,
 $$Which SAP source tables and fields contribute to INVOICE_CATEGORY in FACT_ACCOUNT_PAYABLE_GBL, and what logic classifies a line as Open Invoice, Paid Invoice, Open Credit Note, Paid Credit Note, Payment, Reversal or Other Clearing?$$,
 $$INVOICE_CATEGORY exists only in FACT_ACCOUNT_PAYABLE_GBL (not in the data mart or the views). Sources: BSEG (BKPF_XREVERSAL, AUGBL, BKPF_TCODE, NEBTR, SHKZG, BSCHL) and RBKP.STBLG. REVERSAL when BKPF_XREVERSAL or RBKP.STBLG is set, AUGBL starts with 26, or TCODE is MR8M or FB08. Otherwise PAYMENT when NEBTR <> 0. Otherwise, with AUGBL empty: OPEN INVOICE (SHKZG H) or OPEN CREDIT NOTE (SHKZG S). With AUGBL set: PAID INVOICE (H, posting key not 37/39), PAID CREDIT NOTE (S, posting key not 27/29), else OTHER CLEARING.$$,
 'Anand (reworded)', 'INVOICE_CATEGORY is in the fact table only, and the workbook has 7 categories, not 5.'),
('P03', 'Data Engineer', 3,
 $$I need supplier aging analysis, both current and as of past dates. Can DM_FIN_AP_GBL_DETAILS satisfy this with DAYS_LATE, AGING_FLAG, the aging amount columns and the snapshot fields, or is additional SAP replication required?$$,
 $$Yes for current aging, no extra SAP replication needed: DAYS_LATE = days from NET_DUE_DATE to the load date for unpaid items; AGING_FLAG buckets CURRENT, 1-30, 31-60, 60-90 (label as written in the workbook), 91-120, 121-150, 151-180, 181-360, 361+; amounts CURRENT_AMT_USD_ME, PAST_DUE_AMT_USD_ME, AGING_1_30 ... AGING_181_360, OVER_180 and OVER_360_DAYS_AMT_USD_ME. Past-date aging relies on the snapshot design (DATA_TYPE 'DAILY' or 'SNAPSHOT', SNAPSHOT_DATE = load date); how often snapshots are taken and kept is not in the workbook.$$,
 'Anand (reworded)', 'DAYS_LATE uses the load date, so aging as of past dates depends on the snapshot rows; added to the question.'),
('P04', 'Data Engineer', 4,
 $$Show the complete source-to-target mapping for PURCHASE_ORDER, PURCHASE_ORDER_ITEM, PLANT_SK and MATERIAL_NUM_SK from SAP into DM_FIN_AP_GBL_DETAILS, including which ones come through FACT_ACCOUNT_PAYABLE_GBL and which through another table.$$,
 $$PURCHASE_ORDER = RSEG.EBELN, PURCHASE_ORDER_ITEM = RSEG.EBELP, PLANT_SK = RSEG.WERKS: RSEG is joined to BSEG on MANDT, BELNR = BKPF_AWKEY and GJAHR into FACT_ACCOUNT_PAYABLE_GBL, then passed through to the data mart. MATERIAL_NUM_SK is different: in the data mart it comes from CORP_TRAN.FACT_PURCHASE_ORDER (joined on SOURCE_SYSTEM, PURCHASE_ORDER, PURCHASE_ORDER_ITEM), originally EKPO.MATNR, not from FACT_ACCOUNT_PAYABLE_GBL.$$,
 'Anand (reworded)', 'MATERIAL_NUM_SK reaches the data mart through FACT_PURCHASE_ORDER, not through the AP fact.'),
('P05', 'Data Engineer', 5,
 $$How is OPEN_CLOSE_FLAG derived, and which source attributes determine whether an invoice is considered OPEN or CLOSE?$$,
 $$Calculated in the data mart: IFF(CLEARING_DATE IS NULL, 'OPEN', 'CLOSE'). CLEARING_DATE comes from FACT_ACCOUNT_PAYABLE_GBL and is BSEG.AUGDT converted to a date ('00000000' becomes NULL).$$,
 'Anand', NULL),
('P06', 'Data Engineer', 6,
 $$Which reporting views consume DM_FIN_AP_GBL_DETAILS, and which reports would be impacted if the calculation logic for AGING_FLAG changes?$$,
 $$Three views read the data mart and all expose AGING_FLAG: VW_FIN_AP_CLOSING_BALANCE (open items), VW_FIN_AP_VENDOR_PAYMENT (paid items) and VW_FIN_AP_INV_DETAILS (all items). A change to AGING_FLAG affects all three. The Tableau workbooks built on them are not named in the loaded metadata.$$,
 'Anand', NULL),
('P07', 'Data Engineer', 7,
 $$Is BSEG or BSEC the source for AP line items in FACT_ACCOUNT_PAYABLE_GBL?$$,
 $$The workbook uses BSEG for AP line items (BSEG is the source for most fact fields, with BKPF for the header). BSEC (one-time vendor data) is not in the workbook. BSEG vs BSEC is an open decision to confirm with the customer data engineers.$$,
 'Added', 'Open decision from the BRD; tests that the co-worker flags it instead of deciding.'),
-- ---------------------------------------------------------------- Data Architect
('P08', 'Data Architect', 1,
 $$What is the purpose of FACT_ACCOUNT_PAYABLE_GBL versus DM_FIN_AP_GBL_DETAILS, and which reporting use cases are served by each model?$$,
 $$FACT_ACCOUNT_PAYABLE_GBL (CORP_TRAN, 113 fields) holds the AP line items from SAP (BSEG, BKPF, plus RSEG, BSET, PAYR and others) with amounts, currency conversion, dates and payment terms. DM_FIN_AP_GBL_DETAILS (CORP_DM_FIN, 174 columns) is the reporting mart: the fact plus vendor, entity, organization, fiscal calendar, country and purchase-order attributes and calculated aging and payment metrics. Reporting goes through the 3 views on the mart: closing balance (open items), vendor payment (paid items), invoice details (all items).$$,
 'Anand', NULL),
('P09', 'Data Architect', 2,
 $$What business rules support the calculation of Average Weighted Paid Terms (AWPT) and Average Weighted Purchase Order Terms (AWPOT) metrics?$$,
 $$AWPT = sum(AWPT_NUMERATOR) / sum(AWPT_DENOMINATOR), with AWPT_NUMERATOR = AMT_USD_MA x DAYS_TO_PAY. AWPOT = sum(AWPOT_NUMERATOR) / sum(AWPOT_DENOMINATOR), with AWPOT_NUMERATOR = AMT_USD_MA x DAYS_OFFERED_TERMS. In the fact the denominators are AMT_DOC x monthly-average rate. In the data mart AWPT_DENOMINATOR is AMT_USD_ME when DAYS_TO_PAY is not null, sign reversed for debit (S) lines and set to 0 for negatives or credit/invoice pairs; AWPOT_DENOMINATOR is AMT_USD_ME when DAYS_OFFERED_TERMS is not null.$$,
 'Anand', NULL),
('P10', 'Data Architect', 3,
 $$Which dimensions and reference datasets enrich the Accounts Payable model, including Vendor, Entity, Organization, Country, Fiscal Calendar, and Purchase Order data?$$,
 $$Vendor: CORP_MASTER.DIM_VENDOR_GEN (on SOURCE_SYSTEM, VENDOR_SK) and DIM_VENDOR_COMPANY (also on COMPANY_CODE). Entity: CORP_MASTER.DIM_ENTITY (on SOURCE_SYSTEM and SOURCE_ENTITY). Organization: CORP_REPORT.VW_DIM_ORG. Country: CORP_MASTER.TV_DIM_COUNTRY (vendor country to region). Fiscal calendar: CORP_REF.TV_TIME_FISCAL_DAY. Purchase order: CORP_TRAN.FACT_PURCHASE_ORDER (on SOURCE_SYSTEM, PURCHASE_ORDER, PURCHASE_ORDER_ITEM). Reference mappings: TV_XREF_OS_TRANSFORMATIONS, TV_XREF_VENDOR_MPO and the XREF tables used in the fact.$$,
 'Anand', NULL),
('P11', 'Data Architect', 4,
 $$A new BRD requests Vendor Payment Performance reporting. Which existing datasets, KPIs, and reporting views can be reused before creating a new model?$$,
 $$Reuse VW_FIN_AP_VENDOR_PAYMENT (paid items) on DM_FIN_AP_GBL_DETAILS with DAYS_TO_PAY, DAYS_OFFERED_TERMS, WEIGHTED_ACT_PAYMENT, WEIGHTED_PAYMENT_TERMS_USD_ME and the AWPT / AWPOT numerators and denominators, plus the vendor, entity and fiscal attributes. A new model is not needed for payment performance against terms.$$,
 'Anand', NULL),
('P12', 'Data Architect', 5,
 $$Which SAP source systems, tables, and transaction attributes contribute to the Accounts Payable reporting data product?$$,
 $$Source system ARP900 (SOURCE_SYSTEM = CONCAT('ARP', MANDT)); the workbook also mentions AEP900 for some fields. SAP tables: BSEG (most fields) and BKPF, then BSET, RSEG, RBKP, SKAT, EKKO, EKPO, T003T, PAYR, KNB1, LFB1, MARA, BFOK_A, plus EDW reference tables (XREF_*, VW_DIM_ORG, DIM_ENTITY). Key attributes: document and line, company code, vendor, posting key, debit/credit, amounts, dates, clearing, payment terms.$$,
 'Anand', NULL),
('P13', 'Data Architect', 6,
 $$Which attributes in the AP reporting model are derived through business logic rather than direct source mappings, and where is that logic documented?$$,
 $$25 data mart columns are calculated in the mart, among them DAYS_LATE, AGING_FLAG, OPEN_CLOSE_FLAG, CURRENT_AMT_USD_ME, PAST_DUE_AMT_USD_ME, the AGING_* and OVER_180 / OVER_360 amounts, WEIGHTED_ACT_PAYMENT, WEIGHTED_PAYMENT_TERMS_USD_ME, AWPT_DENOMINATOR, AWPOT_DENOMINATOR, METRIC, METRIC_TYPE, SCENARIO, SNAPSHOT_DATE and DATA_TYPE. The logic is in the mapping rule column of the AP DM Table Mapping Sheet; rule-based fact fields (for example INVOICE_CATEGORY, NET_DUE_DATE, DAYS_TO_PAY) are in the AP FACT Table Mapping Sheet.$$,
 'Anand', NULL),
('P14', 'Data Architect', 7,
 $$Which business entities relate to the AP Document, and which of those relationships are supported by the workbook?$$,
 $$9 relationships, all supported by the workbook: Vendor Invoice posts as AP Document; AP Document references Purchase Order, is owed to Vendor, is settled by Payment, posts to GL Account, is booked in Legal Entity, belongs to Organization, is dated in Fiscal Calendar, is reported in AP Reporting Views.$$,
 'Added', 'Tests the business ontology (v15).'),
('P15', 'Data Architect', 8,
 $$Which steps of the AP process have no data loaded?$$,
 $$Goods receipt: GR and GR/IR tables are not in the loaded data. Vendor creation, purchase order, vendor invoice and AP document are covered by the workbook.$$,
 'Added', 'Tests the process context and honest gaps (v15).'),
-- ---------------------------------------------------------------- Functional Owner
('P16', 'Functional Owner', 1,
 $$Which existing reporting views should I use to analyze Accounts Payable balances, invoice details, and vendor payment performance?$$,
 $$VW_FIN_AP_CLOSING_BALANCE for balances (open items), VW_FIN_AP_INV_DETAILS for invoice details (all items), VW_FIN_AP_VENDOR_PAYMENT for vendor payment performance (paid items). All three read DM_FIN_AP_GBL_DETAILS.$$,
 'Anand', NULL),
('P17', 'Functional Owner', 2,
 $$How is DAYS_LATE calculated, and how does it determine the Aging Buckets used in Accounts Payable reporting?$$,
 $$For unpaid items, DAYS_LATE is the number of days from the net due date to the load date; empty for paid items. AGING_FLAG then places it in CURRENT (0 or less), 1-30, 31-60, 60-90, 91-120, 121-150, 151-180, 181-360 or 361+; amounts above 0 days are past due (PAST_DUE_AMT_USD_ME), the rest current.$$,
 'Anand', NULL),
('P18', 'Functional Owner', 3,
 $$What is the difference between Open Invoice, Paid Invoice, Open Credit Note, Paid Credit Note, Payment, Reversal and Other Clearing in the AP model, and where is this category stored?$$,
 $$Stored as INVOICE_CATEGORY in FACT_ACCOUNT_PAYABLE_GBL only. Open invoice / open credit note: not yet cleared, credit (H) or debit (S) line. Paid invoice / paid credit note: cleared. Payment: a payment line. Reversal: a reversed or reversing document. Other clearing: cleared with posting keys 27/29 or 37/39.$$,
 'Anand (reworded)', 'The model has 7 categories, Reversal is just REVERSAL, and the category is only in the fact table.'),
('P19', 'Functional Owner', 4,
 $$Which business dimensions can I use to analyze Accounts Payable data, such as Vendor, Company Code, Entity, Country, Region, Plant, Profit Center, Purchasing Organization and Spend Type, and which exact columns hold each one?$$,
 $$Vendor: VENDOR_SK, VENDOR_NAME. Company code: COMPANY_CODE. Entity: ENTITY_CODE, SOURCE_ENTITY, HFM_ENTITY. Country: VENDOR_COUNTRY or ENTITY_COUNTRY (and HFM_COUNTRY). Region: VENDOR_REGION, ENTITY_GLOBAL_REGION or HFM_REGION (there is no single Region column). Plant: PLANT_SK only (no plant name). Profit center: PROFIT_CENTER, PROFIT_CENTER_NAME. Purchasing organization: PURCHASING_ORG. Spend type: SPEND_TYPE (purchase order) and AP_SPEND_TYPE.$$,
 'Anand (reworded)', 'Country and Region exist in several versions and Plant only as a key; the answer must say which column.'),
('P20', 'Functional Owner', 5,
 $$Which fields and KPIs should be used to monitor supplier payment performance and payment-term compliance? (DAYS_TO_PAY, DAYS_OFFERED_TERMS, WEIGHTED_ACT_PAYMENT, WEIGHTED_PAYMENT_TERMS_USD_ME)$$,
 $$DAYS_TO_PAY (days from document date to clearing) against DAYS_OFFERED_TERMS (BSEG.ZBD1T), weighted by amount: WEIGHTED_ACT_PAYMENT = DAYS_TO_PAY x AMT_USD_ME and WEIGHTED_PAYMENT_TERMS_USD_ME = DAYS_OFFERED_TERMS x AMT_USD_ME; AWPT and AWPOT summarise them. Use VW_FIN_AP_VENDOR_PAYMENT.$$,
 'Anand', NULL),
('P21', 'Functional Owner', 6,
 $$A business user wants a report of overdue invoices by Vendor, Country and Region. Can existing AP reporting assets satisfy this, which report should be used, and which country and region columns apply?$$,
 $$Yes: VW_FIN_AP_CLOSING_BALANCE (open items) with PAST_DUE_AMT_USD_ME or DAYS_LATE > 0, by VENDOR_NAME, VENDOR_COUNTRY and VENDOR_REGION. If the user means the company's region rather than the vendor's, use ENTITY_GLOBAL_REGION or HFM_REGION; the answer should ask or state which.$$,
 'Anand (reworded)', 'There is no single Region column (vendor, entity or HFM region).'),
('P22', 'Functional Owner', 7,
 $$Who is the owner or steward of AMT_USD_ME?$$,
 $$The field-level owner or steward is not in the loaded metadata, so the co-worker must not guess a name. At model level the accountable role is the AP Finance Data Owner (role); naming owners is an open decision routed via the Data Privacy Officer.$$,
 'Added', 'Tests that the co-worker says "not in the loaded metadata" instead of guessing.'),
('P23', 'Functional Owner', 8,
 $$Which data mart columns still have no business definition?$$,
 $$Lists the DM_FIN_AP_GBL_DETAILS columns whose definition status is Missing (for example ACCOUNT_CLERK, ACCOUNT_CLERK_NAME), points to Draft & Approve to close them, and says how many are left.$$,
 'Added', 'Tests documentation gaps and the Draft & Approve flow.');

-- add them to the agent evaluation dataset (11)
DELETE FROM {{DATABASE}}.{{KF}}.KF_EVAL_DATASET WHERE QUESTION_ID LIKE 'P%';
INSERT INTO {{DATABASE}}.{{KF}}.KF_EVAL_DATASET
SELECT QUESTION_ID, 'Persona: ' || PERSONA, QUESTION, OBJECT_CONSTRUCT('ground_truth_output', EXPECTED_ANSWER)
FROM {{DATABASE}}.{{KF}}.KF_PERSONA_QUESTIONS;

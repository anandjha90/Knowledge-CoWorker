"""Generates sql/07c_client_model.sql from the AP mapping workbook (FACT and DM mapping sheets).

    python3 tools/make_client_model.py <path to workbook.xlsx>

The generated file builds the transactional fact, the datamart table and the three reporting views with
exactly the table and column names, business names, definitions and mapping logic of the workbook.
All VALUES are synthetic: they are derived from the POC's synthetic AP data.
The workbook itself is not part of the package.
"""
import re
import sys

import openpyxl

LANDING_TABLES = {"BSEG", "BKPF", "BSEC", "LFA1", "LFB1", "LFBK", "T001", "T005T", "TCURX", "T003T"}
REPORT_VIEWS = [
    ("VW_FIN_AP_INV_DETAILS", "AP invoice details: every AP line of the datamart (open and closed).", None),
    ("VW_FIN_AP_CLOSING_BALANCE", "AP closing balance: open AP lines (OPEN_CLOSE_FLAG = OPEN).", "OPEN_CLOSE_FLAG = 'OPEN'"),
    ("VW_FIN_AP_VENDOR_PAYMENT", "AP vendor payments: paid AP lines (CURRENT_STATUS = Paid).", "UPPER(CURRENT_STATUS) = 'PAID'"),
]


def s(v):
    return "" if v is None else str(v).strip()


def lit(v):
    """Snowflake string literal (dollar quoted, so SQL inside the mapping text needs no escaping)."""
    v = s(v)
    assert "$$" not in v
    return "$$" + v + "$$" if v else "''"


def cmt(v):
    return "'" + s(v).replace("\\", "\\\\").replace("'", "''").replace("\n", " ") + "'"


def title(name):
    return name.replace("_", " ").title()


# ---------------------------------------------------------------- types and synthetic values
def infer_type(c):
    u = c.upper()
    if u.endswith("_TS"):
        return "TIMESTAMP_NTZ"
    if "AMT" in u or u.endswith(("NUMERATOR", "DENOMINATOR")) or u.startswith("WEIGHTED_"):
        return "NUMBER(18,2)"
    if u.endswith("_DATE") or u.endswith("_ST_DATE") or u.endswith("_FIN_DATE"):
        return "DATE"
    if u.endswith("_DATE_INT"):
        return "VARCHAR(8)"
    if "DAYS" in u or u.endswith("_COUNT") or "_DAY_IN_" in u or u.endswith("_PERIOD_DAYS") or u == "DAYS_LATE":
        return "NUMBER(6)"
    if u.endswith(("_YEAR", "_PERIOD", "_WEEK", "_QUARTER", "_WEEK_IN_PERIOD")) or u.startswith("FISCAL_"):
        return "VARCHAR(10)"
    if u.endswith(("_FLAG", "_YN", "_IND")):
        return "VARCHAR(5)"
    if u.endswith(("_NAME", "_DESC", "_DESCRIPTION", "_TEXT")) or "NAME" in u:
        return "VARCHAR(100)"
    return "VARCHAR(30)"


def synthetic(c, typ, key):
    h = f"ABS(HASH({key}, '{c}'))"
    if typ.startswith("NUMBER(18"):
        return f"ROUND(MOD({h}, 100000) / 10, 2)"
    if typ.startswith("NUMBER"):
        return f"MOD({h}, 60)"
    if typ == "DATE":
        return f"DATEADD(day, -MOD({h}, 365), CURRENT_DATE())"
    if typ.startswith("TIMESTAMP"):
        return "CURRENT_TIMESTAMP()"
    if typ == "VARCHAR(5)":
        return f"IFF(MOD({h}, 5) = 0, 'YES', 'NO')"
    if typ == "VARCHAR(10)":
        return f"LPAD(TO_VARCHAR(MOD({h}, 12) + 1), 2, '0')"
    if typ == "VARCHAR(100)":
        return f"'{title(c)} ' || TO_VARCHAR(MOD({h}, 25) + 1)"
    return f"'{re.sub('[^A-Z]', '', c.upper())[:4]}' || LPAD(TO_VARCHAR(MOD({h}, 500)), 3, '0')"


# Sheet: AMT_DOC = IFF(BSEG.SHKZG = 'H', BSEG.WRBTR * -1, BSEG.WRBTR) (+ TCURX); AMT_LCL the same with DMBTR
AMT_DOC = "IFF(f.DEBIT_CREDIT_INDICATOR = 'H', ABS(f.AMOUNT_DOC) * -1, ABS(f.AMOUNT_DOC))"
AMT_LCL = "IFF(f.DEBIT_CREDIT_INDICATOR = 'H', ABS(f.AMOUNT_LOCAL) * -1, ABS(f.AMOUNT_LOCAL))"
USD_MA = f"ROUND(NVL({AMT_DOC} * r.USD_RATE_MA, 0), 2)"
USD_ME = f"ROUND(NVL({AMT_DOC} * r.USD_RATE_ME, 0), 2)"
# Sheet: CASE WHEN CLEARING_DATE IS NULL THEN (CURRENT_DATE() - DOCUMENT_DATE) ELSE DATEDIFF(DAY, CLEARING_DATE, DOCUMENT_DATE) END
DTP = "CASE WHEN f.CLEARING_DATE IS NULL THEN (CURRENT_DATE() - f.DOCUMENT_DATE) ELSE DATEDIFF(DAY, f.CLEARING_DATE, f.DOCUMENT_DATE) END"
FACT_KNOWN = {
    "ACCOUNT_TYPE": ("VARCHAR(1)", "'K'"),
    "ACCOUNTING_DOC": ("VARCHAR(10)", "f.DOCUMENT_NUMBER"),
    "ACCOUNTING_DOC_LINE_ITEM": ("VARCHAR(3)", "f.LINE_ITEM"),
    "AMT_DOC": ("NUMBER(18,2)", AMT_DOC),
    "AMT_GRP": ("NUMBER(18,2)", f"ROUND({AMT_LCL} * c.USD_EXCHANGE_RATE, 2)"),
    "AMT_LCL": ("NUMBER(18,2)", AMT_LCL),
    "AMT_USD_MA": ("NUMBER(18,2)", USD_MA),
    "AMT_USD_ME": ("NUMBER(18,2)", USD_ME),
    "AWPOT_DENOMINATOR": ("NUMBER(18,2)", USD_MA),
    "AWPOT_NUMERATOR": ("NUMBER(18,2)", f"{USD_MA} * f.PAYMENT_TERMS_DAYS"),
    "AWPT_DENOMINATOR": ("NUMBER(18,2)", USD_MA),
    "AWPT_NUMERATOR": ("NUMBER(18,2)", f"{USD_MA} * ({DTP})"),
    "BASELINE_PAYMENT_DATE": ("DATE", "f.BASELINE_DATE"),
    "CLEARING_DATE": ("DATE", "f.CLEARING_DATE"),
    "CLEARING_DATE_INT": ("VARCHAR(8)", "TO_VARCHAR(f.CLEARING_DATE, 'YYYYMMDD')"),
    "CLEARING_DOC": ("VARCHAR(10)", "f.CLEARING_DOCUMENT"),
    "CLEARING_DOC_ENTRY_DATE": ("DATE", "f.CLEARING_DATE"),
    "CLEARING_DOC_TYPE": ("VARCHAR(2)", "IFF(f.CLEARING_DATE IS NULL, NULL, 'KZ')"),
    "CLEARING_DOC_TYPE_DESCRIPTION": ("VARCHAR(100)", "IFF(f.CLEARING_DATE IS NULL, NULL, 'Vendor payment')"),
    "CLEARING_FISCAL_PERIOD": ("VARCHAR(10)", "LPAD(TO_VARCHAR(MONTH(f.CLEARING_DATE)), 2, '0')"),
    "CLEARING_FISCAL_YEAR": ("VARCHAR(10)", "TO_VARCHAR(YEAR(f.CLEARING_DATE))"),
    "COMPANY_CODE": ("VARCHAR(4)", "f.COMPANY_CODE"),
    "CREDIT_INVOICE_PAIR_YN": ("VARCHAR(5)", "'NO'"),  # no reversal documents (BKPF_XREVERSAL empty) in the synthetic data
    "CURRENT_STATUS": ("VARCHAR(10)", "f.CURRENT_STATUS"),
    "DAYS_OFFERED_TERMS": ("NUMBER(6)", "f.PAYMENT_TERMS_DAYS"),
    "DAYS_TO_PAY": ("NUMBER(6)", DTP),
    "DEBIT_CREDIT_FLAG": ("VARCHAR(1)", "f.DEBIT_CREDIT_INDICATOR"),
    "DOC_CURR": ("VARCHAR(5)", "f.DOCUMENT_CURRENCY"),
    "DOC_TYPE": ("VARCHAR(2)", "f.DOCUMENT_TYPE"),
    "DOC_TYPE_DESCRIPTION": ("VARCHAR(100)", "f.DOCUMENT_TYPE_DESC"),
    "DOCUMENT_DATE": ("DATE", "f.DOCUMENT_DATE"),
    "DOCUMENT_TEXT": ("VARCHAR(100)", "f.DOCUMENT_TYPE_DESC || ' ' || f.INVOICE_REFERENCE"),
    "FISCAL_PERIOD": ("VARCHAR(10)", "LPAD(TO_VARCHAR(MONTH(f.POSTING_DATE)), 2, '0')"),
    "FISCAL_YEAR": ("NUMBER(4)", "f.FISCAL_YEAR"),
    "GL_ACCOUNT": ("VARCHAR(10)", "f.RECONCILIATION_ACCOUNT"),
    "GRP_CURR": ("VARCHAR(5)", "'USD'"),
    "LCL_CURR": ("VARCHAR(5)", "f.LOCAL_CURRENCY"),
    "LOAD_TS": ("TIMESTAMP_NTZ", "CURRENT_TIMESTAMP()"),
    "UPDATED_TS": ("TIMESTAMP_NTZ", "CURRENT_TIMESTAMP()"),
    "NET_DUE_DATE": ("DATE", "f.NET_DUE_DATE"),
    "NET_PAY_TERMS_PERIOD": ("NUMBER(6)", "f.PAYMENT_TERMS_DAYS"),
    "PAYMENT_BLOCK": ("VARCHAR(1)", "f.PAYMENT_BLOCK"),
    "PAYMENT_TERMS": ("VARCHAR(4)", "f.PAYMENT_TERMS"),
    "POSTING_DATE": ("DATE", "f.POSTING_DATE"),
    "REF_DOC_NUM": ("VARCHAR(16)", "f.INVOICE_REFERENCE"),
    "SOURCE_SYSTEM": ("VARCHAR(10)", "CONCAT('ARP', '900')"),  # sheet: CONCAT('ARP', BSEG.MANDT), client 900
    "VENDOR_SK": ("VARCHAR(10)", "f.VENDOR_ID"),
    "DOCDATE_NET_DUE_DATE": ("DATE", "f.NET_DUE_DATE"),
    "SCHEDULED_PAYMENT_DATE": ("DATE", "COALESCE(f.CLEARING_DATE, f.NET_DUE_DATE)"),
    "DOCDATE_SCHEDULED_PAYMENT_DATE": ("DATE", "COALESCE(f.CLEARING_DATE, f.NET_DUE_DATE)"),
    "INVOICE_CATEGORY": ("VARCHAR(30)", "CASE WHEN f.CLEARING_DOCUMENT IS NULL AND f.DEBIT_CREDIT_INDICATOR = 'H' THEN 'OPEN INVOICE' "
                                        "WHEN f.CLEARING_DOCUMENT IS NULL AND f.DEBIT_CREDIT_INDICATOR = 'S' THEN 'OPEN CREDIT NOTE' "
                                        "WHEN f.DEBIT_CREDIT_INDICATOR = 'H' THEN 'PAID INVOICE' ELSE 'PAID CREDIT NOTE' END"),
    "CASH_DISCOUNT_DAYS": ("NUMBER(6)", "IFF(f.PAYMENT_TERMS_DAYS = 0, 0, LEAST(10, f.PAYMENT_TERMS_DAYS))"),
    "PAYMENT_METHOD": ("VARCHAR(30)", "ARRAY_CONSTRUCT('T', 'C', '1', 'O', '#')[MOD(ABS(HASH(f.AP_LINE_ID, 'PMETH')), 5)]::VARCHAR"),
    "VENDOR_MPO_FLAG": ("VARCHAR(5)", "IFF(MOD(ABS(HASH(f.VENDOR_ID, 'MPO')), 10) = 0, 'YES', 'NO')"),
    "PO_PAYMENT_TERMS": ("VARCHAR(30)", "ARRAY_CONSTRUCT('JV00', 'JV15', 'JV35', 'N030', 'N060')[MOD(ABS(HASH(f.AP_LINE_ID, 'POT')), 5)]::VARCHAR"),
    "AP_SPEND_TYPE": ("VARCHAR(30)", "ARRAY_CONSTRUCT('DIRECT', 'INDIRECT', 'SERVICES', 'CAPEX')[MOD(ABS(HASH(f.AP_LINE_ID, 'SPEND')), 4)]::VARCHAR"),
    "INVOICE_REF": ("VARCHAR(16)", "f.INVOICE_REFERENCE"),
    "TRANSACTION_CODE": ("VARCHAR(10)", "IFF(f.DOCUMENT_TYPE = 'KG', 'FB65', 'FB60')"),
}

DL = "IFF(UPPER(x.CURRENT_STATUS) = 'UNPAID', ROUND(DATEDIFF('DAY', x.NET_DUE_DATE, CURRENT_DATE())), NULL)"
AMT = "IFF(UPPER(x.CURRENT_STATUS) = 'PAID', x.AMT_USD_ME * -1, x.AMT_USD_ME)"   # DM AMT_USD_ME (DISBURSEMENTS flipped)
CIP = "x.CREDIT_INVOICE_PAIR_YN"
AWPT1 = f"(CASE WHEN x.DEBIT_CREDIT_FLAG = 'S' THEN -1 * IFF(x.DAYS_TO_PAY IS NULL, 0, {AMT}) ELSE IFF(x.DAYS_TO_PAY IS NULL, 0, {AMT}) END)"
AWPT2 = f"(CASE WHEN ({AWPT1} < 0 OR {CIP} = 'YES') THEN 0 ELSE {AWPT1} END)"
AWPOT0 = f"IFF(x.DAYS_OFFERED_TERMS IS NULL, 0, {AMT})"
AWPOT1 = f"(CASE WHEN x.DEBIT_CREDIT_FLAG = 'S' THEN -1 * {AWPOT0} ELSE {AWPOT0} END)"
AWPOT2 = f"(CASE WHEN ({AWPOT1} < 0 OR {CIP} = 'YES') THEN 0 ELSE {AWPOT1} END)"
AWPT_DEN = (f"CASE WHEN (x.PAYMENT_METHOD IN ('%', '&', '1', '#', '@') OR (x.PAYMENT_METHOD = 'O' AND x.PO_PAYMENT_TERMS IN ('JV00', 'JV15', 'JV35'))) "
            f"AND x.VENDOR_MPO_FLAG = 'NO' THEN {AWPOT2} ELSE {AWPT2} END")
DM_KNOWN = {
    "AMT_USD_ME": ("NUMBER(18,2)", AMT),
    "METRIC_TYPE": ("VARCHAR(30)", "IFF(UPPER(x.CURRENT_STATUS) = 'PAID', 'DISBURSEMENTS', x.AP_SPEND_TYPE)"),
    "METRIC": ("VARCHAR(10)", "IFF(UPPER(x.CURRENT_STATUS) = 'PAID', '921839', '921800')"),
    "OPEN_CLOSE_FLAG": ("VARCHAR(5)", "IFF(x.CLEARING_DATE IS NULL, 'OPEN', 'CLOSE')"),
    "DATA_TYPE": ("VARCHAR(10)", "'DAILY'"),
    "SNAPSHOT_DATE": ("DATE", "CURRENT_DATE()"),
    "SCENARIO": ("VARCHAR(10)", "IFF(UPPER(x.CURRENT_STATUS) = 'PAID', 'Actual', 'Forecast')"),
    "TERMS_DAYS": ("NUMBER(6)", "DATEDIFF('DAY', x.DOCUMENT_DATE, x.NET_DUE_DATE)"),
    "DAYS_LATE": ("NUMBER(6)", DL),
    "AWPOT_DENOMINATOR": ("NUMBER(18,2)", AWPOT0),
    "AWPT_DENOMINATOR": ("NUMBER(18,2)", AWPT_DEN),
    "WEIGHTED_ACT_PAYMENT": ("NUMBER(18,2)", f"IFF(x.DAYS_TO_PAY IS NOT NULL, x.DAYS_TO_PAY * {AMT}, 0)"),
    "WEIGHTED_PAYMENT_TERMS_USD_ME": ("NUMBER(18,2)", f"IFF(x.DAYS_OFFERED_TERMS IS NOT NULL, x.DAYS_OFFERED_TERMS * {AMT}, 0)"),
    "CURRENT_AMT_USD_ME": ("NUMBER(18,2)", f"IFF({DL} <= 0, ROUND({AMT}, 2), 0)"),
    "PAST_DUE_AMT_USD_ME": ("NUMBER(18,2)", f"IFF({DL} > 0, ROUND({AMT}, 2), 0)"),
    "OVER_180_DAYS_AMT_USD_ME": ("NUMBER(18,2)", f"IFF({DL} > 180, ROUND({AMT}, 2), 0)"),
    "OVER_360_DAYS_AMT_USD_ME": ("NUMBER(18,2)", f"IFF({DL} > 360, ROUND({AMT}, 2), 0)"),
    "AGING_FLAG": ("VARCHAR(20)", f"CASE WHEN {DL} > 0 AND {DL} <= 30 THEN '1-30' WHEN {DL} > 30 AND {DL} <= 60 THEN '31-60' "
                                  f"WHEN {DL} > 60 AND {DL} <= 90 THEN '60-90' WHEN {DL} > 90 AND {DL} <= 120 THEN '91-120' "
                                  f"WHEN {DL} > 120 AND {DL} <= 150 THEN '121-150' WHEN {DL} > 150 AND {DL} <= 180 THEN '151-180' "
                                  f"WHEN {DL} > 180 AND {DL} <= 360 THEN '181-360' WHEN {DL} > 360 THEN '361+' "
                                  f"WHEN {DL} <= 0 THEN 'CURRENT' END"),
    "VENDOR_NAME": ("VARCHAR(100)", "v.VENDOR_NAME"),
    "VENDOR_COUNTRY": ("VARCHAR(3)", "v.VENDOR_COUNTRY_CODE"),
    "VENDOR_COUNTRY_NAME": ("VARCHAR(100)", "v.VENDOR_COUNTRY_NAME"),
    "VENDOR_ACCOUNT_GROUP": ("VARCHAR(4)", "v.VENDOR_ACCOUNT_GROUP"),
    "VENDOR_STATUS": ("VARCHAR(10)", "IFF(v.IS_DELETED, 'BLOCKED', 'ACTIVE')"),
    "INVOICE_TYPE": ("VARCHAR(30)", "x.INVOICE_CATEGORY"),
    "LINE_ITEM_TEXT": ("VARCHAR(100)", "x.DOCUMENT_TEXT"),
    "CREDIT_INVOICE_PAIR_FLAG": ("VARCHAR(5)", "x.CREDIT_INVOICE_PAIR_YN"),
    "MONTH_END_FISCAL_CLOSE_DATE": ("DATE", "LAST_DAY(COALESCE(x.CLEARING_DATE, x.SCHEDULED_PAYMENT_DATE))"),
}
for lo, hi in [(1, 30), (31, 60), (61, 90), (91, 120), (121, 150), (151, 180), (181, 360)]:
    DM_KNOWN[f"AGING_{lo}_{hi}_DAYS_AMT_USD_ME"] = ("NUMBER(18,2)", f"IFF({DL} >= {lo} AND {DL} <= {hi}, ROUND({AMT}, 2), 0)")

DATE_PREFIX = {"POSTING_": "x.POSTING_DATE", "CLEARING_": "x.CLEARING_DATE", "SPD_": "x.SCHEDULED_PAYMENT_DATE",
               "TODAY_": "CURRENT_DATE()"}


def fiscal(c):
    """Fiscal calendar columns derived from the matching date (synthetic calendar = calendar months)."""
    u = c.upper()
    if "FISCAL" not in u:
        return None
    base = "COALESCE(x.CLEARING_DATE, x.SCHEDULED_PAYMENT_DATE)"
    for p, d in DATE_PREFIX.items():
        if u.startswith(p):
            base = d
    if u.endswith("DAY_IN_PERIOD"):
        return "NUMBER(3)", f"DAY({base})"
    if u.endswith("DAY_IN_WEEK"):
        return "NUMBER(3)", f"DAYOFWEEKISO({base})"
    if u.endswith("DAY_IN_YEAR"):
        return "NUMBER(3)", f"DAYOFYEAR({base})"
    if u.endswith("WEEK_IN_PERIOD"):
        return "NUMBER(3)", f"CEIL(DAY({base}) / 7)"
    if u.endswith("_DATE"):
        return "DATE", base
    if u.endswith("YEAR") or u.endswith("YEAR_STR"):
        return "VARCHAR(10)", f"TO_VARCHAR(YEAR({base}))"
    if u.endswith("PERIOD") or u.endswith("PERIOD_STR"):
        return "VARCHAR(10)", f"LPAD(TO_VARCHAR(MONTH({base})), 2, '0')"
    if u.endswith("WEEK"):
        return "VARCHAR(10)", f"TO_VARCHAR(WEEKOFYEAR({base}))"
    return None


def source_from_rule(rule):
    m = re.search(r"\b(BSEG|BKPF|BSEC|LFB1|LFA1|T001|TCURX)\.([A-Z0-9_]+)", rule.upper())
    return (m.group(1), m.group(2)) if m else (None, None)


def mapping_type(rule):
    u = rule.upper()
    if u.startswith("DIRECT"):
        return "Direct"
    if "JOIN" in u:
        return "Lookup"
    if "CASE" in u or "IFF" in u:
        return "Conditional"
    return "Derived"


def main(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    fact = [r for r in list(wb["AP FACT Table Mapping Sheet"].iter_rows(values_only=True))[1:] if s(r[1])]
    dm = [r for r in list(wb["AP DM Table Mapping Sheet"].iter_rows(values_only=True))[1:] if s(r[2])]
    fact_model = s(fact[0][0]).upper()
    dm_model = s(dm[0][1]).upper()

    # FACT columns (first occurrence wins)
    fcols, seen = [], set()
    for r in fact:
        c = s(r[1]).upper()
        if c in seen:
            continue
        seen.add(c)
        typ, expr = FACT_KNOWN.get(c, (None, None))
        typ = typ or infer_type(c)
        expr = expr or synthetic(c, typ, "f.AP_LINE_ID")
        biz, dfn = s(r[2]) or title(c), s(r[3]) or "No business definition in the mapping sheet."
        fcols.append((c, typ, expr, f"{biz}: {dfn}", r))
    ftype = {c: t for c, t, _, _, _ in fcols}
    fbiz = {c: (s(r[2]), s(r[3])) for c, _, _, _, r in fcols}

    # DM columns
    dcols, seen = [], set()
    key = "x.COMPANY_CODE, x.ACCOUNTING_DOC, x.FISCAL_YEAR, x.ACCOUNTING_DOC_LINE_ITEM"
    for r in dm:
        c = s(r[2]).upper()
        if c in seen:
            continue
        seen.add(c)
        src_edw, src_field = s(r[3]).upper(), s(r[5]).upper()
        if c in DM_KNOWN:
            typ, expr = DM_KNOWN[c]
        elif "FACT_ACCOUNT_PAYABLE_GBL" in src_edw and src_field in ftype:
            typ, expr = ftype[src_field], f"x.{src_field}"
        elif c in ftype:
            typ, expr = ftype[c], f"x.{c}"
        elif fiscal(c):
            typ, expr = fiscal(c)
        else:
            typ = infer_type(c)
            expr = synthetic(c, typ, key)
        biz, dfn = fbiz.get(c, ("", ""))
        if not dfn:
            src = s(r[3]) + ("." + s(r[5]) if s(r[5]) else "")
            dfn = ("Calculated in the datamart load (see mapping information)." if s(r[3]).lower() == "calculated"
                   else f"Taken from {src} in the datamart load.")
        dcols.append((c, typ, expr, f"{biz or title(c)}: {dfn}", r))

    out = []
    w = out.append
    w(f"""-- =====================================================================
-- 07c AP MODEL AS DOCUMENTED IN THE MAPPING WORKBOOK (generated by tools/make_client_model.py)
--   {{{{EDW}}}}.{fact_model}        {len(fcols)} columns (AP FACT mapping sheet)
--   {{{{DATAMART}}}}.{dm_model}    {len(dcols)} columns (AP DM mapping sheet)
--   {{{{REPORTING}}}}.{', '.join(v for v, _, _ in REPORT_VIEWS)}
--   Same table / column names, business names, definitions and mapping logic as the workbook.
--   VALUES ARE SYNTHETIC (derived from the POC's synthetic AP data). Sandbox only, not for public repos.
-- =====================================================================
USE WAREHOUSE {{{{WAREHOUSE}}}};
""")
    # ---- FACT
    w(f"CREATE OR REPLACE TABLE {{{{DATABASE}}}}.{{{{EDW}}}}.{fact_model} (")
    w(",\n".join(f"  {c} {t} COMMENT {cmt(d)}" for c, t, _, d, _ in fcols))
    w(f") COMMENT = 'Accounts payable transactional fact (global). Source: SAP BSEG (vendor lines) + BKPF and lookups, as documented in the AP FACT mapping sheet. Grain: one row per accounting document line item. Synthetic values.';\n")
    w(f"""CREATE OR REPLACE PROCEDURE {{{{DATABASE}}}}.{{{{EDW}}}}.LOAD_{fact_model}()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Loads {fact_model} (synthetic values) following the AP FACT mapping sheet.'
EXECUTE AS OWNER
AS
$$
BEGIN
  INSERT OVERWRITE INTO {{{{DATABASE}}}}.{{{{EDW}}}}.{fact_model} ({', '.join(c for c, *_ in fcols)})
  SELECT
""")
    w(",\n".join(f"    {e}" for _, _, e, _, _ in fcols))
    w(f"""  FROM {{{{DATABASE}}}}.{{{{EDW}}}}.FACT_ACCOUNTS_PAYABLE_GLOBAL f
  JOIN {{{{DATABASE}}}}.{{{{EDW}}}}.DIM_COMPANY_CODE c ON c.COMPANY_CODE = f.COMPANY_CODE
  LEFT JOIN {{{{DATABASE}}}}.{{{{EDW}}}}.DIM_CURRENCY_RATE_MONTHLY r
    ON r.CURRENCY = f.DOCUMENT_CURRENCY AND r.RATE_MONTH = DATE_TRUNC('month', f.POSTING_DATE);
  RETURN '{fact_model} loaded';
END;
$$;

CALL {{{{DATABASE}}}}.{{{{EDW}}}}.LOAD_{fact_model}();
""")
    # ---- DM
    w(f"CREATE OR REPLACE TABLE {{{{DATABASE}}}}.{{{{DATAMART}}}}.{dm_model} (")
    w(",\n".join(f"  {c} {t} COMMENT {cmt(d)}" for c, t, _, d, _ in dcols))
    w(f") COMMENT = 'AP global details datamart. Source: {{{{EDW}}}}.{fact_model} + master / reference lookups, as documented in the AP DM mapping sheet. Grain: one row per AP line item. Synthetic values.';\n")
    w(f"""CREATE OR REPLACE PROCEDURE {{{{DATABASE}}}}.{{{{DATAMART}}}}.LOAD_{dm_model}()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Loads {dm_model} (synthetic values) following the AP DM mapping sheet.'
EXECUTE AS OWNER
AS
$$
BEGIN
  INSERT OVERWRITE INTO {{{{DATABASE}}}}.{{{{DATAMART}}}}.{dm_model} ({', '.join(c for c, *_ in dcols)})
  SELECT
""")
    w(",\n".join(f"    {e}" for _, _, e, _, _ in dcols))
    w(f"""  FROM {{{{DATABASE}}}}.{{{{EDW}}}}.{fact_model} x
  LEFT JOIN {{{{DATABASE}}}}.{{{{EDW}}}}.DIM_VENDOR v ON v.VENDOR_ID = x.VENDOR_SK;
  RETURN '{dm_model} loaded';
END;
$$;

CALL {{{{DATABASE}}}}.{{{{DATAMART}}}}.LOAD_{dm_model}();
""")
    # ---- views
    for view, desc, where in REPORT_VIEWS:
        w(f"CREATE OR REPLACE VIEW {{{{DATABASE}}}}.{{{{REPORTING}}}}.{view} (")
        w(",\n".join(f"  {c} COMMENT {cmt(d)}" for c, _, _, d, _ in dcols))
        w(f") COMMENT = '{desc} Reads {{{{DATAMART}}}}.{dm_model} only (no logic).'\nAS\nSELECT {', '.join(c for c, *_ in dcols)}\n"
          f"FROM {{{{DATABASE}}}}.{{{{DATAMART}}}}.{dm_model}" + (f"\nWHERE {where};\n" if where else ";\n"))
    # ---- tags + tasks
    w(f"""ALTER TABLE {{{{DATABASE}}}}.{{{{EDW}}}}.{fact_model} SET TAG {{{{DATABASE}}}}.{{{{GOVERNANCE}}}}.DATA_CLASS = 'Transaction data';
ALTER TABLE {{{{DATABASE}}}}.{{{{DATAMART}}}}.{dm_model} SET TAG {{{{DATABASE}}}}.{{{{GOVERNANCE}}}}.DATA_CLASS = 'Transaction data';""")
    for view, _, _ in REPORT_VIEWS:
        w(f"ALTER VIEW {{{{DATABASE}}}}.{{{{REPORTING}}}}.{view} SET TAG {{{{DATABASE}}}}.{{{{GOVERNANCE}}}}.DATA_CLASS = 'Transaction data';")
    w(f"""
ALTER TASK {{{{DATABASE}}}}.{{{{EDW}}}}.TASK_LOAD_EDW SUSPEND;
CREATE OR REPLACE TASK {{{{DATABASE}}}}.{{{{EDW}}}}.TASK_LOAD_{fact_model}
  WAREHOUSE = {{{{WAREHOUSE}}}}
  COMMENT = 'Runs after TASK_LOAD_AP_PAYMENT_TERMS (daily). Refreshes: {fact_model}'
  AFTER {{{{DATABASE}}}}.{{{{EDW}}}}.TASK_LOAD_AP_PAYMENT_TERMS
AS
  CALL {{{{DATABASE}}}}.{{{{EDW}}}}.LOAD_{fact_model}();
CREATE OR REPLACE TASK {{{{DATABASE}}}}.{{{{EDW}}}}.TASK_LOAD_{dm_model}
  WAREHOUSE = {{{{WAREHOUSE}}}}
  COMMENT = 'Runs after TASK_LOAD_{fact_model} (daily). Refreshes: {dm_model}'
  AFTER {{{{DATABASE}}}}.{{{{EDW}}}}.TASK_LOAD_{fact_model}
AS
  CALL {{{{DATABASE}}}}.{{{{DATAMART}}}}.LOAD_{dm_model}();
""")
    # ---- workbook rows as delivered
    w(f"DELETE FROM {{{{DATABASE}}}}.{{{{KF}}}}.KF_EXCEL_MAPPING_SHEET;")
    vals = []
    for i, r in enumerate(fact, 1):
        vals.append(f"('AP FACT Table Mapping Sheet', {i}, 'EDW', '{{{{EDW}}}}', {lit(s(r[0]).upper())}, {lit(s(r[1]).upper())}, {lit(r[2])}, {lit(r[3])}, "
                    f"{lit(r[4])}, '', {lit(r[5])}, {lit(r[6])}, {lit(r[7] if s(r[7]) else 'Direct Mapping')})")
    for i, r in enumerate(dm, 1):
        biz, dfn = fbiz.get(s(r[2]).upper(), ("", ""))
        vals.append(f"('AP DM Table Mapping Sheet', {i}, 'Datamart', '{{{{DATAMART}}}}', {lit(s(r[1]).upper())}, {lit(s(r[2]).upper())}, {lit(biz)}, {lit(dfn)}, "
                    f"'', {lit(r[3])}, {lit(r[4])}, {lit(r[5])}, {lit(r[6] if s(r[6]) else 'Direct Mapping')})")
    w(f"INSERT INTO {{{{DATABASE}}}}.{{{{KF}}}}.KF_EXCEL_MAPPING_SHEET\n  (SHEET, SHEET_ROW, LAYER, SCHEMA_NAME, MODEL_NAME, FIELD_NAME, BUSINESS_NAME, DEFINITION, SOURCE_SYSTEM, SOURCE_EDW_TABLE, SOURCE_TABLE, SOURCE_FIELD, MAPPING)\nVALUES\n" + ",\n".join(vals) + ";\n")

    # ---- mapping rows (lineage)
    w(f"""DELETE FROM {{{{DATABASE}}}}.{{{{KF}}}}.KF_FIELD_MAPPING
WHERE TARGET_OBJECT IN ('{{{{EDW}}}}.{fact_model}', '{{{{DATAMART}}}}.{dm_model}'{''.join(f", '{{{{REPORTING}}}}.{v}'" for v, _, _ in REPORT_VIEWS)});""")
    mrows = []
    for c, _, _, _, r in fcols:
        rule = s(r[7]) or "Direct Mapping"
        t, f_ = s(r[5]).upper(), s(r[6]).upper()
        if not t:
            t, f_ = source_from_rule(rule)
        if t:
            obj = f"{{{{LANDING}}}}.SAP_{t}" if t in LANDING_TABLES else t
        else:
            obj, f_ = "Calculated", c
        mrows.append(f"('EDW', '{{{{EDW}}}}.{fact_model}', '{c}', {lit(obj)}, {lit(f_ or c)}, '{mapping_type(rule)}', {lit(rule)}, 'AP FACT Table Mapping Sheet')")
    for c, _, _, _, r in dcols:
        rule = s(r[6]) or "Direct Mapping"
        src = s(r[3])
        if src.upper().endswith("." + fact_model) or src.upper() == fact_model:
            obj = f"{{{{EDW}}}}.{fact_model}"
        elif src.lower() == "calculated" or not src:
            obj = "Calculated"
        else:
            obj = src
        f_ = s(r[5]) if s(r[5]) and s(r[5]).lower() != "calculated" else c
        mrows.append(f"('Datamart', '{{{{DATAMART}}}}.{dm_model}', '{c}', {lit(obj)}, {lit(f_.upper())}, '{mapping_type(rule)}', {lit(rule)}, 'AP DM Table Mapping Sheet')")
    for view, _, _ in REPORT_VIEWS:
        for c, *_ in dcols:
            mrows.append(f"('Reporting', '{{{{REPORTING}}}}.{view}', '{c}', '{{{{DATAMART}}}}.{dm_model}', '{c}', 'Direct', 'Passed through (reporting view, no logic).', 'View definition')")
    w(f"INSERT INTO {{{{DATABASE}}}}.{{{{KF}}}}.KF_FIELD_MAPPING (TARGET_LAYER, TARGET_OBJECT, TARGET_COLUMN, SOURCE_OBJECT, SOURCE_COLUMN, MAPPING_TYPE, TRANSFORMATION_RULE, MAPPING_SOURCE)\nVALUES\n" + ",\n".join(mrows) + ";\n")

    # ---- KPIs from the sheets
    w(f"""DELETE FROM {{{{DATABASE}}}}.{{{{KF}}}}.KF_GLOSSARY WHERE SOURCE_DOCUMENT = 'AP mapping sheets';
INSERT INTO {{{{DATABASE}}}}.{{{{KF}}}}.KF_GLOSSARY (TERM, DEFINITION, CALCULATION, IMPLEMENTED_IN, SYNONYMS, OWNER, STATUS, APPROVED_ON, SOURCE_DOCUMENT, TERM_TYPE)
SELECT column1, column2, column3, column4, column5, 'Finance data owner (role)', 'Approved', NULL, 'AP mapping sheets', 'KPI' FROM VALUES
('Average Weighted Paid Terms (AWPT)', 'Average days taken to pay, weighted by the USD amount (month-end rate).',
 'SUM(WEIGHTED_ACT_PAYMENT) / SUM(AWPT_DENOMINATOR) in {dm_model}; in {fact_model}: SUM(AWPT_NUMERATOR) / SUM(AWPT_DENOMINATOR).',
 '{{{{DATAMART}}}}.{dm_model}.AWPT_DENOMINATOR', 'AWPT, weighted paid terms, average weighted paid terms'),
('Average Weighted Purchase Order Terms (AWPOT)', 'Average payment term days offered, weighted by the USD amount (month-end rate).',
 'SUM(WEIGHTED_PAYMENT_TERMS_USD_ME) / SUM(AWPOT_DENOMINATOR) in {dm_model}; in {fact_model}: SUM(AWPOT_NUMERATOR) / SUM(AWPOT_DENOMINATOR).',
 '{{{{DATAMART}}}}.{dm_model}.AWPOT_DENOMINATOR', 'AWPOT, weighted PO terms, average weighted purchase ordered terms'),
('Past Due Amount (USD ME)', 'Open AP amount past its net due date, in USD at month-end rate.',
 'SUM(PAST_DUE_AMT_USD_ME); PAST_DUE_AMT_USD_ME = IFF(DAYS_LATE > 0, ROUND(AMT_USD_ME, 2), 0).',
 '{{{{DATAMART}}}}.{dm_model}.PAST_DUE_AMT_USD_ME', 'past due, overdue amount USD'),
('Current Amount (USD ME)', 'Open AP amount not yet due, in USD at month-end rate.',
 'SUM(CURRENT_AMT_USD_ME); CURRENT_AMT_USD_ME = IFF(DAYS_LATE <= 0, ROUND(AMT_USD_ME, 2), 0).',
 '{{{{DATAMART}}}}.{dm_model}.CURRENT_AMT_USD_ME', 'current amount, not yet due'),
('Days Late', 'Days an unpaid item is past its net due date.',
 'IFF(CURRENT_STATUS = UNPAID, DATEDIFF(DAY, NET_DUE_DATE, CURRENT_DATE), NULL).',
 '{{{{DATAMART}}}}.{dm_model}.DAYS_LATE', 'days past due, lateness'),
('Aging Flag', 'Aging band of an unpaid item by days late: CURRENT, 1-30, 31-60, 60-90, 91-120, 121-150, 151-180, 181-360, 361+.',
 'CASE on DAYS_LATE; amounts per band in AGING_1_30_DAYS_AMT_USD_ME ... OVER_360_DAYS_AMT_USD_ME.',
 '{{{{DATAMART}}}}.{dm_model}.AGING_FLAG', 'aging band, aging bucket');
""")
    # ---- load scripts + refresh
    w(f"""DELETE FROM {{{{DATABASE}}}}.{{{{KF}}}}.KF_LOAD_SCRIPTS WHERE SCRIPT_NAME IN ('LOAD_{fact_model}', 'LOAD_{dm_model}');
INSERT INTO {{{{DATABASE}}}}.{{{{KF}}}}.KF_LOAD_SCRIPTS
SELECT 'LOAD_{fact_model}', '{{{{DATABASE}}}}.{{{{EDW}}}}.LOAD_{fact_model}()', 'EDW', '{fact_model}',
       'SAP BSEG, BKPF and lookups (synthetic: FACT_ACCOUNTS_PAYABLE_GLOBAL, DIM_COMPANY_CODE, DIM_CURRENCY_RATE_MONTHLY)', 'TASK_LOAD_{fact_model}',
       GET_DDL('PROCEDURE', '{{{{DATABASE}}}}.{{{{EDW}}}}.LOAD_{fact_model}()'), CURRENT_TIMESTAMP();
INSERT INTO {{{{DATABASE}}}}.{{{{KF}}}}.KF_LOAD_SCRIPTS
SELECT 'LOAD_{dm_model}', '{{{{DATABASE}}}}.{{{{DATAMART}}}}.LOAD_{dm_model}()', 'Datamart', '{dm_model}',
       '{fact_model}, DIM_VENDOR and master / reference lookups', 'TASK_LOAD_{dm_model}',
       GET_DDL('PROCEDURE', '{{{{DATABASE}}}}.{{{{DATAMART}}}}.LOAD_{dm_model}()'), CURRENT_TIMESTAMP();

CALL {{{{DATABASE}}}}.{{{{KF}}}}.REFRESH_KNOWLEDGE_FABRIC(FALSE);
""")
    open("sql/07c_client_model.sql", "w").write("\n".join(out))
    print(f"07c written: {fact_model} {len(fcols)} cols, {dm_model} {len(dcols)} cols, {len(mrows)} mapping rows")


if __name__ == "__main__":
    main(sys.argv[1])
